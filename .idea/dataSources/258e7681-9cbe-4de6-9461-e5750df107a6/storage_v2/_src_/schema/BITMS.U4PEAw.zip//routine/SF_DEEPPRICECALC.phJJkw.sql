CREATE function sf_deepPriceCalc(a_l_price   in number,
                                                                    a_l_factor  in number :=1,
                                                                    a_vc_jsfx   in varchar2,
                                                                    a_l_level in number:=0) return number is
/**********************************************************
  名  称：深度行情计算
  功  能：深度行情计算
  入  参：
      a_l_price     行情
      a_l_factor    推算因子
      a_vc_jsfx   计算方向(B. 买入；S. 卖出)
      a_l_level     深度级别
  创建者：Jiangsc
  描  述：
      深度0  原始委托价格，只是显示两位小数
      深度1  卖盘进位到整数并且尾数是a_l_factor的倍数        买盘截位到整数并且尾数是a_l_factor的倍数
      深度2  卖盘进位到整数并且尾数是2*a_l_factor的倍数    买盘截位到整数并且尾数是2*a_l_factor的倍数
      深度3  卖盘进位到整数并且尾数是3*a_l_factor的倍数    买盘截位到整数并且尾数是3*a_l_factor的倍数
      深度4  卖盘进位到整数并且尾数是4*a_l_factor的倍数    买盘截位到整数并且尾数是4*a_l_factor的倍数
      深度5  卖盘进位到整数并且尾数是5*a_l_factor的倍数   买盘截位到整数并且尾数是5*a_l_factor的倍数
  日  期：2017-09-14
***********************************************************/
  v_l_price number(16,8);
  v_l_tail    number;
begin
    v_l_price := round(a_l_price,8);
   -- 买入深度行情 = 截位后行情  - (截位后行情与深度计算因子取余)
   if  a_l_level  > 0 and a_vc_jsfx = 'B' then
      v_l_tail := mod(floor(a_l_price),a_l_level*a_l_factor);
      v_l_price := floor(a_l_price) -  v_l_tail;
      v_l_price := round(v_l_price,8);
  elsif a_l_level  > 0 and a_vc_jsfx = 'S' then
   -- 卖出深度行情 = 进位后行情  + (进位后情与深度计算因子取余)
       v_l_tail := mod(ceil(a_l_price),a_l_level*a_l_factor);
       select (ceil(a_l_price) +  decode(v_l_tail,0,0,a_l_level*a_l_factor-v_l_tail)) into v_l_price  from dual ; 
       v_l_price := round(v_l_price,8);
  end if;
  return v_l_price;
end sf_deepPriceCalc;
/

