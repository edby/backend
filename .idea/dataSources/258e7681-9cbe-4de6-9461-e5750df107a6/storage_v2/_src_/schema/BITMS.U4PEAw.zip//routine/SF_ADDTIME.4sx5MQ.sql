CREATE function sf_addTime(a_l_jgsj   in number,
                                                           a_l_jsfx   in number,
                                                           a_vc_dw in varchar2:='M') return timestamp is
/**********************************************************
  名  称：获取时间戳 
  功  能：向前或向后计算时间戳
  入  参：
      a_l_jgsj     间隔时间
      a_l_jsfx     计算方向(-1.向前推算；1. 向后推算)
      a_vc_dw   计算单位(M. 分钟；H. 小时；D. 天)
  创建者：Jiangsc
  描  述：
  日  期：2017-09-14
  版  本：2.6-20091128Patch2-A
***********************************************************/
  v_t_time timestamp;
begin
    v_t_time := sysdate;
 
   if  a_vc_dw  = 'M' then
      select (sysdate+(a_l_jsfx * a_l_jgsj/24/60)) into v_t_time from  dual;
  elsif a_vc_dw = 'H' then
      select (sysdate+(a_l_jsfx * a_l_jgsj/24)) into v_t_time from  dual;
  elsif a_vc_dw = 'D' then
      select (sysdate+(a_l_jsfx * a_l_jgsj)) into v_t_time from  dual;
  end if;
  
  return v_t_time;
end sf_addTime;
/

