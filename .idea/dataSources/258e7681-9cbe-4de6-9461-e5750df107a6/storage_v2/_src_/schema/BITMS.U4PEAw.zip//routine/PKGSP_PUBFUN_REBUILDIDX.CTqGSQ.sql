CREATE procedure pkgsp_pubfun_rebuildidx(a_vc_tabname in varchar2,
                                    return_code  out number,
                                    return_str   out varchar2)
  is
  /**********************************************************
    名  称：重建索引
    功  能：根据传入的表名重建索引,并重新生成统计信息
    入  参：
    出  参：
    创建者：sunbiao
    描  述：
    日  期：2018-02-12
  ***********************************************************/

  v_vc_user    varchar2(32);
  v_vc_sql     varchar2(400);
  v_vc_tabname varchar2(40);

  --所有索引
  cursor cur_indexes is select a.table_name,a.index_name,a.partitioned
                          from all_indexes a
                         where a.table_owner=v_vc_user       and
                               a.table_name =v_vc_tabname;

  v_vc_ycbz   varchar2(1);   --异常标志

  begin
    v_vc_ycbz := 'N';

    v_vc_tabname := upper(a_vc_tabname);

    ----------------------------------------------------
    --获取登陆用户
    ----------------------------------------------------
    v_vc_ycbz := 'Y';
    return_code := -101;
    return_str :='[pkg_pubfun.pkgsp_pubfun_rebuildidx]处理表【'||v_vc_tabname||'】,获取登陆用户时报错,请联系系统管理员';
    v_vc_sql := 'select sys.login_user from dual';
    execute immediate v_vc_sql into v_vc_user;
    v_vc_ycbz := 'N';

    ----------------------------------------------------
    --重建所有索引
    ----------------------------------------------------
    for v_cur_indexes in cur_indexes loop
      v_vc_ycbz := 'Y';
      return_code := -101;
      return_str :='[pkg_pubfun.pkgsp_pubfun_rebuildidx]重建表【'||v_vc_tabname||'】的【'||v_cur_indexes.index_name||'】索引时报错,请联系系统管理员';
      if v_cur_indexes.partitioned = 'YES' then
        for v_cur_parind in (select t.partition_name
                               from user_ind_partitions t
                              where t.index_name=v_cur_indexes.index_name) loop
          v_vc_sql := 'alter index '||v_cur_indexes.index_name||' rebuild partition '||v_cur_parind.partition_name;
          execute immediate v_vc_sql;
        end loop;
      else
        v_vc_sql := 'alter index '||v_cur_indexes.index_name||' rebuild ';
        execute immediate v_vc_sql;
      end if;
      v_vc_ycbz := 'N';
    end loop;

    v_vc_ycbz := 'Y';
    return_code := -101;
    return_str :='[pkg_pubfun.pkgsp_pubfun_rebuildidx]删除表:【'||v_vc_tabname||'】的统计信息时报错,请联系系统管理员';
    v_vc_sql := ' begin dbms_stats.delete_table_stats(ownname => '||chr(39)||v_vc_user||chr(39)||',tabname => '||chr(39)||v_vc_tabname||chr(39)||'); end;';
    execute immediate v_vc_sql;
    v_vc_ycbz := 'N';

    v_vc_ycbz := 'Y';
    return_code := -101;
    return_str :='[pkg_pubfun.pkgsp_pubfun_rebuildidx]生成表:【'||v_vc_tabname||'】的统计信息时报错,请联系系统管理员';
    v_vc_sql := ' begin dbms_stats.gather_table_stats(ownname => '||chr(39)||v_vc_user||chr(39)||',tabname => '||chr(39)||v_vc_tabname||chr(39)||',cascade => true,METHOD_OPT => ''FOR ALL INDEXED COLUMNS''); end;';
    execute immediate v_vc_sql;
    v_vc_ycbz := 'N';

    return_code :=0;
    return_str := '处理成功';
  exception when others then
    --系统自动异常捕捉
    if v_vc_ycbz = 'N' then
      return_code:=-1;
      return_str := '[pkg_pubfun.pkgsp_pubfun_rebuildidx]报异常错误:'||chr(13)||sqlerrm;
    end if;
    --人为考虑系统异常
    if v_vc_ycbz = 'Y' then
      return_str := return_str||chr(13)||sqlerrm;
    end if;
    --人为的制造了异常
    if v_vc_ycbz = 'H' then
      return_str := return_str;
    end if;
  end pkgsp_pubfun_rebuildidx;
/

