CREATE procedure sp_archive(return_code out int, return_str out varchar2) is
  v_interval number; --声明变量
  v_timestamp timestamp; --声明变量
  v_ycsl number; --声明变量
  v_sqlTxt VARCHAR2(2000); --声明变量 
BEGIN
  v_interval := 0; --给初值  
  v_timestamp := systimestamp; --给初值  
  v_sqlTxt := ' select systimestamp from dual '; 
   
  execute immediate v_sqlTxt into v_timestamp; 
  
  v_sqlTxt := ' select sum(ycsl) from 
	 (
	 select count(*) as ycsl from monitormatchfundcur a where a.chkresult < 0
	 union all
	 select count(*) as ycsl from monitormatchfundcur a where a.chkresult < 0
	 union all
	 select count(*) as ycsl from monitorplatbal a where a.chkresult < 0
	 )';
	 
  execute immediate v_sqlTxt into v_ycsl;  
  
  --外部行情记录归档(归档2小时之前)
  --select * from quotation a
  delete from quotation a
  where (v_timestamp - TO_TIMESTAMP(sf_formattime(a.datetime),  'YYYY-MM-DD HH24:MI:SS') ) >= numtodsinterval(2, 'hour')
  and a.stockid not in (133333333302, 144444444402, 155555555502, 166666666602, 188888888802);
  
  commit;
  
  
  --成交、委托归档 开始
  --基于委托ID成交记录归档(归档XX之前)
  insert into realdealvcoinmoney302his 
  select a.*
  from realdealvcoinmoney302 a,
	   (select id from realdealvcoinmoney302 
	    where id <(select  min(id) from (select id  from realdealvcoinmoney302  order by id desc) where rownum <= 20))b
  where a.id = b.id
	and not exists (select 1 from entrustvcoinmoney302 where status in ('init','noDeal','partialDeal') and (v_timestamp - entrusttime) >= numtodsinterval(30, 'minute') and a.buyentrustid = id )
    and not exists (select 1 from entrustvcoinmoney302 where status in ('init','noDeal','partialDeal') and (v_timestamp - entrusttime) >= numtodsinterval(30, 'minute') and a.sellentrustid = id );
  
  --select * from realdealvcoinmoney302his a
  delete from realdealvcoinmoney302 b
  where  exists( select 1 from realdealvcoinmoney302his where b.id = id );
  
  --委托记录归档(归档XX之前)
  insert into entrustvcoinmoney302His 
  select *
  from entrustvcoinmoney302 a
  where a.status not in ('init','noDeal','partialDeal')
  and (v_timestamp - a.entrusttime) >= numtodsinterval(30, 'minute');

  --select * from entrustvcoinmoney302His a
  delete from entrustvcoinmoney302 a
  where exists (select 1 from entrustvcoinmoney302His where a.id = id );

  commit;
  
  --基于委托ID成交记录归档(归档XX之前)
  insert into realdealvcoinmoney402his 
  select a.*
  from realdealvcoinmoney402 a,
	   (select id from realdealvcoinmoney402 
	    where id <(select  min(id) from (select id  from realdealvcoinmoney402  order by id desc) where rownum <= 20))b
  where a.id = b.id
	and not exists (select 1 from entrustvcoinmoney402 where status in ('init','noDeal','partialDeal') and (v_timestamp - entrusttime) >= numtodsinterval(30, 'minute') and a.buyentrustid = id )
    and not exists (select 1 from entrustvcoinmoney402 where status in ('init','noDeal','partialDeal') and (v_timestamp - entrusttime) >= numtodsinterval(30, 'minute') and a.sellentrustid = id );
  
  --select * from realdealvcoinmoney402his a
  delete from realdealvcoinmoney402 b
  where  exists( select 1 from realdealvcoinmoney402his where b.id = id );
  
  --委托记录归档(归档XX之前)
  insert into entrustvcoinmoney402His 
  select *
  from entrustvcoinmoney402 a
  where a.status not in ('init','noDeal','partialDeal')
  and (v_timestamp - a.entrusttime) >= numtodsinterval(30, 'minute');

  --select * from entrustvcoinmoney402His a
  delete from entrustvcoinmoney402 a
  where exists (select 1 from entrustvcoinmoney402His where a.id = id );

  commit;
  
  --基于委托ID成交记录归档(归档XX之前)
  insert into realdealvcoinmoney502his 
  select a.*
  from realdealvcoinmoney502 a,
	   (select id from realdealvcoinmoney502 
	    where id <(select  min(id) from (select id  from realdealvcoinmoney502  order by id desc) where rownum <= 20))b
  where a.id = b.id
	and not exists (select 1 from entrustvcoinmoney502 where status in ('init','noDeal','partialDeal') and (v_timestamp - entrusttime) >= numtodsinterval(30, 'minute') and a.buyentrustid = id )
    and not exists (select 1 from entrustvcoinmoney502 where status in ('init','noDeal','partialDeal') and (v_timestamp - entrusttime) >= numtodsinterval(30, 'minute') and a.sellentrustid = id );

  --select * from realdealvcoinmoney502his a
  delete from realdealvcoinmoney502 b
  where  exists( select 1 from realdealvcoinmoney502his where  b.id = id );
  
  --委托记录归档(归档XX之前)
  insert into entrustvcoinmoney502His 
  select *
  from entrustvcoinmoney502 a
  where a.status not in ('init','noDeal','partialDeal')
  and (v_timestamp - a.entrusttime) >= numtodsinterval(30, 'minute');

  --select * from entrustvcoinmoney502His a
  delete from entrustvcoinmoney502 a
  where exists (select 1 from entrustvcoinmoney502His where a.id = id);

  commit;
  --成交、委托归档 结束
  
  
  --根据监控是否正常来执行是否资金流水的归档
  --if true then
  if v_ycsl <= 0 then
      --监控正常进行归档
	  
	  --杠杆现货资金流水记录归档(归档XX之前)
	  --select * from monitorbalance
	  insert into monitorbalance
	  select v_timestamp-numtodsinterval(30, 'minute'), accountid, decode(accountassettype,'spotAccountAsset',2,'spotAccountDebit',3,0),
	  stockinfoId,100000000001,155555555502,
	  0,0,0,lastamt,forzenlastamt,0,systimestamp  
	  from                                                                        
	  (                                                                              
		 select a.accountid,a.accountassettype,a.businessflag,a.stockinfoid,a.relatedstockinfoid,a.currentdate,a.lastamt,a.forzenlastamt,rank() 
		 over(partition by a.accountid,a.accountassettype,a.stockinfoid order by a.currentdate desc) mm 
		 from accountfundcurrentspot a
		 where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute')
	  )                                                                              
	  where mm = 1;
	  
	  --更新monitorbalance业务日期
	  UPDATE monitorbalance b SET b.BUSINESSDATE = v_timestamp-numtodsinterval(30, 'minute')
	  where exists (
		select 1 from 
		  (select a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID, max(businessdate) businessdate
			 from monitorbalance a
			 group by a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID ) c
			 where c.businessdate =b.businessdate 
				 and c.ACCOUNTID = b.Accountid
				 and c.ACCTASSETTYPE = b.Acctassettype
				 and c.STOCKINFOID = b.Stockinfoid
				 and c.RELATEDSTOCKINFOID = b.RELATEDSTOCKINFOID
				 and c.BIZCATEGORYID = b.BIZCATEGORYID
				 and c.ACCTASSETTYPE in (2, 3)
			 );
	  
	  insert into accountfundcurrentspotHis
	  select *
	  from accountfundcurrentspot a
	  where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute');
	  
	  --select * from accountfundcurrentspotHis a
	  delete from accountfundcurrentspot a
	  where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute');

	  commit;
	  
	  
	  --纯正现货资金流水记录归档(归档v_interval小时之前)
	  --select * from monitorbalance
	  insert into monitorbalance
	  select v_timestamp-numtodsinterval(30, 'minute'), accountid, decode(accountassettype,'walletAccountAsset',1,0),
	  stockinfoId,stockinfoId,stockinfoId,
	  0,0,0,lastamt,forzenlastamt,0,systimestamp  
	  from                                                                        
	  (                                                                              
		 select a.accountid,a.accountassettype,a.businessflag,a.stockinfoid,a.relatedstockinfoid,a.currentdate,a.lastamt,a.forzenlastamt,rank() 
		 over(partition by a.accountid,a.accountassettype,a.stockinfoid order by a.currentdate desc) mm 
		 from accountfundcurrent a
		 where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute')
	  )                                                                              
	  where mm = 1;
	  
	  --更新monitorbalance业务日期
	  UPDATE monitorbalance b SET b.BUSINESSDATE = v_timestamp-numtodsinterval(30, 'minute')
	  where exists (
		select 1 from 
		  (select a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID, max(businessdate) businessdate
			 from monitorbalance a
			 group by a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID ) c
			 where c.businessdate =b.businessdate 
				 and c.ACCOUNTID = b.Accountid
				 and c.ACCTASSETTYPE = b.Acctassettype
				 and c.STOCKINFOID = b.Stockinfoid
				 and c.RELATEDSTOCKINFOID = b.RELATEDSTOCKINFOID
				 and c.BIZCATEGORYID = b.BIZCATEGORYID
				 and c.ACCTASSETTYPE in (1)
			 );
	  
	  insert into accountfundcurrentHis
	  select *
	  from accountfundcurrent a
	  where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute');
	  
	  --select * from accountfundcurrentHis a
	  delete from accountfundcurrent a
	  where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute');
	  
	  commit;

	  
	  --理财资金流水记录归档(归档v_interval小时之前)
	  --select * from monitorbalance
	  insert into monitorbalance
	  select v_timestamp-numtodsinterval(30, 'minute'), accountid, decode(accountassettype,'wealthAccountAsset',4,'wealthAccountDebit',5,0),
	  stockinfoId,stockinfoId,stockinfoId,
	  0,0,0,lastamt,forzenlastamt,0,systimestamp  
	  from                                                                        
	  (                                                                              
		 select a.accountid,a.accountassettype,a.businessflag,a.stockinfoid,a.relatedstockinfoid,a.currentdate,a.lastamt,a.forzenlastamt,rank() 
		 over(partition by a.accountid,a.accountassettype,a.stockinfoid order by a.currentdate desc) mm 
		 from accountwealthcurrent a
		 where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute')
	  )                                                                              
	  where mm = 1;
	  
	  --更新monitorbalance业务日期
	  UPDATE monitorbalance b SET b.BUSINESSDATE = v_timestamp-numtodsinterval(30, 'minute')
	  where exists (
		select 1 from 
		  (select a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID, max(businessdate) businessdate
			 from monitorbalance a
			 group by a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID ) c
			 where c.businessdate =b.businessdate 
				 and c.ACCOUNTID = b.Accountid
				 and c.ACCTASSETTYPE = b.Acctassettype
				 and c.STOCKINFOID = b.Stockinfoid
				 and c.RELATEDSTOCKINFOID = b.RELATEDSTOCKINFOID
				 and c.BIZCATEGORYID = b.BIZCATEGORYID
				 and c.ACCTASSETTYPE in (4, 5)
			 );
	  
	  insert into accountwealthcurrentHis
	  select *
	  from accountwealthcurrent a
	  where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute');
	  
	  --select * from accountwealthcurrentHis a
	  delete from accountwealthcurrent a
	  where (v_timestamp - a.currentdate) >= numtodsinterval(30, 'minute');
	  
	  commit;
	  
	  --更新monitorbalance业务日期
	  --update monitorbalance a set a.businessdate = v_timestamp-numtodsinterval(30, 'minute');
	  UPDATE monitorbalance b SET b.BUSINESSDATE = v_timestamp-numtodsinterval(30, 'minute')
	  where exists (
		select 1 from 
		  (select a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID, max(businessdate) businessdate
			 from monitorbalance a
			 group by a.ACCOUNTID, a.ACCTASSETTYPE, a.STOCKINFOID, a.RELATEDSTOCKINFOID, a.BIZCATEGORYID ) c
			 where c.businessdate =b.businessdate 
				 and c.ACCOUNTID = b.Accountid
				 and c.ACCTASSETTYPE = b.Acctassettype
				 and c.STOCKINFOID = b.Stockinfoid
				 and c.RELATEDSTOCKINFOID = b.RELATEDSTOCKINFOID
				 and c.BIZCATEGORYID = b.BIZCATEGORYID
			 );
	  
	  commit;
  else
	  --监控不正常不进行归档
	  commit; 
  end if;
  
  return_code := 1;
  return_str := '平台归档成功';
	
  exception when others then
    --系统自动异常捕捉
    return_code := -1;
    return_str := '平台归档失败'||chr(13)||sqlerrm;
    rollback;
	
END sp_archive;
/

