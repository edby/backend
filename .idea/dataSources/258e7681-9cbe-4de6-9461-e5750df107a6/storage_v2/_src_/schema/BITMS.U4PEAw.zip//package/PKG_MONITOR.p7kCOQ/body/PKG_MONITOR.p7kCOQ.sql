CREATE package body PKG_MONITOR is
/**********************************************************
  名  称：监控模块
  功  能：监控平台资金、交易数据的准确性
  创建者：jiangsc
  描  述：
  日  期：2017-08-24
  版  本：1.0
***********************************************************/
 /**********************************************************
  名  称： 保证金监控
  功  能： 监控保证金比例
  入  参：bizids           业务ID列表
  出  参：return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
          monitor_result   监控结果   (1.对账平衡; -1.对账不平)
          monitor_data     详细的监控结果
          return_str       返回信息
  创建者：jiangsc
  描  述：

  日  期：2017-11-17
***********************************************************/
 procedure sp_monitorMargin(bizids in varchar2,monitor_idx out int,return_code out int,monitor_result out int,monitor_data out resultcur,return_str out varchar2)
 is
     v_l_count                      number(8);                             -- 计数器
     v_t_createDate                 timestamp;                             -- 监控流水生成时间
     v_vc_ycbz                      varchar2(1);                           --异常标志
     v_vc_MonitorType               varchar2(32);                          -- 监控类型
     v_vc_Monitorsubtype            varchar2(32);                          -- 监控子类型
     v_vc_Monitorname               varchar2(200);                         -- 监控名称
     v_vc_TargetTable               varchar2(32);                          -- 监控记录表
     v_l_superAcctid                number(20);                            -- 超级用户ID
     v_sql_monitorMargin            varchar2(5000);                        -- 保证金监控SQL语句
     v_explosionPrice               number(20,8);
     v_riskRate                     number(20,8);
     v_lever                        number(20,8);
     v_warnRatio                    number(20,8);
     v_marginRatio                  number(20,8);
     v_criticalCPPercent            number(20,8);
     v_monitorDesc                  varchar2(500);
     v_l_id                         number(20);
     v_l_categoryId                 number(20);
     v_l_relatedstockinfoid         number(20);
     cur_monitor                    resultcur;
     v_cur_monitorMargin            MonitorMargin%rowtype;                 -- 注意：MonitorMargin字段增减，SQL语句也要相应调整，且保证字段顺序要一致

     cursor cur_stockinfo is
           select id,maxlonglever,maxshortlever,tableasset,tablerealdeal,tabledebitasset,preclosepositionratio,stocktype,
                  closePositionLongPrePercent, closePositionShortPrePercent,stockname,tradestockinfoid,capitalstockinfoid
             from stockinfo where id in (select * from table(sf_strsplit(bizids))) and stocktype in ('spotContract','leveragedSpot');
  v_cur_stockinfo                cur_stockinfo%rowtype;


 begin
     return_code := 1;
     monitor_result  := 1;
     v_t_createDate :=systimestamp;
     v_vc_MonitorType := 'MARGIN';
     v_vc_Monitorsubtype :='ACCT';
     v_vc_Monitorname := '保证金监控';
     v_vc_TargetTable := 'MonitorMargin';
     v_l_superAcctid := 200000000000;
     v_warnRatio := 0;
     v_lever := 0;
     v_explosionPrice := 0;
     v_riskRate := 0;
     v_criticalCPPercent := 0;
     v_marginRatio := 0;
     v_monitorDesc :='';
     monitor_idx := 0;
     
     select count(1)into v_l_count from monitorconfig where  monitorcode='MARGIN' and active = 1 and idxid1>0;
     if v_l_count > 0 then
        select idxid1 into monitor_idx from monitorconfig where  monitorcode='MARGIN' and active = 1 and idxid1>0;
     end if;
     
     v_vc_ycbz := 'N';
     return_code := -1;  
      --===========================
      -- 存在，执行保证金监控逻辑
      --===========================

      open cur_stockinfo;
      loop
      fetch cur_stockinfo into v_cur_stockinfo;
      exit when cur_stockinfo%notFound;

      return_str := '[PKG_MONITOR.SP_MonitorMargin] 保证金监控失败' ||v_cur_stockinfo.id;

      /**
       *     杠杆现货
       *     合约现货
       *   账户属性
       *      多 ：标的净资产 > 0 and 计价净资产 < 0
       *      空： 标的净资产 < 0 and 计价净资产 > 0
       *      无： 标的净资产 >= 0  and  计价净资产 >= 0
       *  ------------------------------------------------------
       *   风险率 = 交易价 / 强平价 = 交易价 * 标的净资产 /计价净资产
       *
       *   强平价 = 计价净资产 / 标的净资产
       */
      v_vc_Monitorsubtype := upper(v_cur_stockinfo.stocktype);
      v_l_relatedstockinfoid := v_cur_stockinfo.id;
      if v_cur_stockinfo.stocktype = 'leveragedSpot' then
         v_l_categoryId := v_cur_stockinfo.capitalstockinfoid;
      else
         v_l_categoryId := v_cur_stockinfo.id;
      end if;

      v_sql_monitorMargin :=  'select rownum id,'' '' MonitorType, '' '' MonitorSubType,a.accountid,
                    case when (a.amount - nvl(a.debitamt,0)) > 0 and (b.amount -nvl(b.debitamt,0)) < 0 then 1
                    when (a.amount - nvl(a.debitamt,0)) < 0 and (b.amount -nvl(b.debitamt,0)) > 0 then -1
                     else 0
                    end acctattr,
                    :1 stockinfoid,
                    b.stockinfoid capitalstockinfoId,a.stockinfoid targetStockinfoId,b.amount capitalBal,a.amount targetBal,
                    nvl(b.debitamt,0) capitalDebtBal,nvl(a.debitamt,0) targetDebtBal,
                    price.dealprice platPrice,0 explosionPrice,0 lever,0 warnRatio,0 marginRatio,
                    case when nvl(b.debitamt,0) = 0 and nvl(a.debitamt,0) = 0 then 0
                         when b.amount - nvl(b.debitamt,0) = 0 then 0
                       else round(-1 * price.dealprice * (a.amount - nvl(a.debitamt,0))*100/ (b.amount - nvl(b.debitamt,0)),6)
                       end riskRate,
                       0 criticalCPPercent, '''' monitorDesc,1 chkResult,systimestamp Chkdate
                  from (select asset.accountid,asset.stockinfoid,asset.amount,debit.debitamt
                  from '||v_cur_stockinfo.tableasset||' asset, '||v_cur_stockinfo.tabledebitasset||' debit
                   where  asset.accountid = debit.borroweraccountid(+)
                   and asset.stockinfoid = debit.stockinfoid(+)
                   and asset.relatedstockinfoid = debit.relatedstockinfoid(+)
                   and asset.stockinfoid in ( :2 )
                   and asset.relatedstockinfoid = :3 )a,
                   (select asset.accountid,asset.stockinfoid,asset.amount,debit.debitamt
                    from '||v_cur_stockinfo.tableasset||' asset, '||v_cur_stockinfo.tabledebitasset||' debit
                   where  asset.accountid = debit.borroweraccountid(+)
                   and asset.stockinfoid = debit.stockinfoid(+)
                   and asset.relatedstockinfoid = debit.relatedstockinfoid(+)
                   and asset.stockinfoid = :4
                   and asset.relatedstockinfoid = :5 )b, account c,
                   (select dealprice
                  from '||v_cur_stockinfo.tablerealdeal ||'
                   where  id = (select max(id) from '||v_cur_stockinfo.tablerealdeal ||'  where tradetype=''matchTrade'' )) price
                  where a.accountid = b.accountid and a.accountid = c.id
                  and c.status = 0 and c.delflag = 0 and c.id >:6 ';

    open cur_monitor for v_sql_monitorMargin
    using  v_l_categoryId,                           -- 业务品种ID
           v_cur_stockinfo.tradestockinfoid,         -- 标的ID
           v_l_categoryId,                           -- 业务品种ID
           v_cur_stockinfo.capitalstockinfoid,       -- 计价ID
           v_l_categoryId,                           -- 业务品种ID
           v_l_superAcctid ;                         -- 超级用户账号ID
    loop
    fetch cur_monitor into v_cur_monitorMargin;
    exit when cur_monitor%notFound;
         v_l_id := 1000000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitorMargin.id;

         if  v_cur_monitorMargin.Targetbal-v_cur_monitorMargin.Targetdebtbal !=0 then
           --强平价 = - 1 * 交易净资产/标的净资产
            v_explosionPrice := -1 * round((v_cur_monitorMargin.Capitalbal - v_cur_monitorMargin.Capitaldebtbal)/(v_cur_monitorMargin.Targetbal - v_cur_monitorMargin.Targetdebtbal),4) ;
         end if;

         if v_cur_monitorMargin.acctattr = 1 then
             --多头
             v_riskRate := v_cur_monitorMargin.Riskrate;
             -- 预警比例
             v_warnRatio := v_cur_stockinfo.preclosepositionratio * v_cur_stockinfo.maxLongLever * 100;
             -- 杠杆比例
             v_lever := v_cur_stockinfo.maxLongLever;
             -- 临界爆仓比例(乘以100)
             v_criticalCPPercent := 100+v_cur_stockinfo.closePositionLongPrePercent *100;
             -- 实时保证金比例 = 总净资产 * 多头杠杆 /总负债
             v_marginRatio := round((v_cur_monitorMargin.Targetbal - v_cur_monitorMargin.Targetdebtbal + (v_cur_monitorMargin.Capitalbal -v_cur_monitorMargin.Capitaldebtbal)/v_cur_monitorMargin.platPrice) *
                                        v_cur_stockinfo.maxLongLever  * 100/(v_cur_monitorMargin.Targetdebtbal + v_cur_monitorMargin.Capitaldebtbal/v_cur_monitorMargin.platPrice),2);

         elsif v_cur_monitorMargin.acctattr = -1 then
             --空头
              v_riskRate := v_cur_monitorMargin.Riskrate;
             -- 预警比例
              v_warnRatio := v_cur_stockinfo.preclosepositionratio * v_cur_stockinfo.maxShortLever * 100;
             -- 杠杆比例
              v_lever := v_cur_stockinfo.maxShortLever;
             -- 临界爆仓比例(乘以100)
              v_criticalCPPercent := 100 - v_cur_stockinfo.closePositionShortPrePercent *100;
             -- 实时保证金比例 = 总净资产 * 多头杠杆 /总负债
              v_marginRatio :=  round((v_cur_monitorMargin.Targetbal - v_cur_monitorMargin.Targetdebtbal + (v_cur_monitorMargin.Capitalbal -v_cur_monitorMargin.Capitaldebtbal)/v_cur_monitorMargin.platPrice) *
                                        v_cur_stockinfo.maxShortLever  * 100/(v_cur_monitorMargin.Targetdebtbal + v_cur_monitorMargin.Capitaldebtbal/v_cur_monitorMargin.platPrice),2);

         else
             v_explosionPrice := 0;
             v_riskRate := 0;
         end if;

         if (v_cur_monitorMargin.acctattr = 1 and v_cur_monitorMargin.riskRate > 0 and v_cur_monitorMargin.riskRate <= v_criticalCPPercent)  or
            (v_cur_monitorMargin.acctattr = -1 and v_cur_monitorMargin.riskRate > 0 and v_cur_monitorMargin.riskRate >= v_criticalCPPercent) then

            monitor_result := -2;
            v_monitorDesc := '[账户ID：'||v_cur_monitorMargin.accountid||',证券名称：'||v_cur_stockinfo.stockname||'],触发爆仓,触发时间:['||v_t_createDate||']，当前交易价格为['||to_char(v_cur_monitorMargin.Platprice,'fm999999999990.099999999999')||'],强平价格为['||
                                             to_char(v_explosionPrice,'fm999999999990.099999999999')||']，风险率为['||to_char(v_cur_monitorMargin.Riskrate,'fm999999999990.0000')||'%]，临界爆仓比例为['||to_char(v_criticalCPPercent,'fm999999999990.0000')||'%]';

               insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                                values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_monitorDesc,v_cur_stockinfo.id,v_l_relatedstockinfoid);

         elsif  (v_cur_monitorMargin.acctattr = 1 and v_cur_monitorMargin.riskRate > 0 and  v_cur_monitorMargin.riskRate <= (100+v_cur_stockinfo.preclosepositionratio*100))  or
                 (v_cur_monitorMargin.acctattr = -1 and v_cur_monitorMargin.riskRate > 0 and  v_cur_monitorMargin.riskRate >= (100 -v_cur_stockinfo.preclosepositionratio*100)) then
               if v_marginRatio <= v_warnRatio then
                    monitor_result := -1;
                    v_monitorDesc := '[账户ID：'||v_cur_monitorMargin.accountid||',证券名称：'||v_cur_stockinfo.stockname||'],触发保证金监控比例预警,触发时间:['||v_t_createDate||']，当前交易价格为['||to_char(v_cur_monitorMargin.Platprice,'fm999999999990.099999999999')||'],强平价格为['||
                                                 to_char(v_explosionPrice,'fm999999999990.099999999999')||']，风险率为['||to_char(v_cur_monitorMargin.Riskrate,'fm999999999990.0000')||'%]';

                      insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                                       values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_monitorDesc,v_cur_stockinfo.id,v_l_relatedstockinfoid);
               end if;
         end if;


         if v_riskRate > 0  then
              merge into MonitorMargin a
              using (select v_cur_monitorMargin.Accountid accountId,v_cur_monitorMargin.Targetstockinfoid Targetstockinfoid,v_cur_monitorMargin.Capitalstockinfoid Capitalstockinfoid from dual) b
                 on (a.accountId = b.accountId and a.Targetstockinfoid = b.Targetstockinfoid and a.Capitalstockinfoid = b.Capitalstockinfoid)
              when matched then
                    update set Capitalbal = v_cur_monitorMargin.Capitalbal,
                               acctattr = v_cur_monitorMargin.Acctattr,
                               targetBal = v_cur_monitorMargin.Targetbal,
                               Capitaldebtbal = v_cur_monitorMargin.Capitaldebtbal,
                               targetDebtBal = v_cur_monitorMargin.Targetdebtbal,
                               platPrice =v_cur_monitorMargin.Platprice ,
                               explosionPrice = v_explosionPrice,
                               lever = v_lever,
                               warnRatio = v_warnRatio,
                               marginRatio = v_marginRatio,
                               riskRate = v_riskRate,
                               criticalCPPercent = v_criticalCPPercent,
                               monitorDesc = v_monitorDesc,
                               Chkdate = v_t_createDate,
                               chkResult = monitor_result
              when not matched then
                    insert (id,MonitorType,MonitorSubType,accountId,acctattr,stockinfoId,capitalstockinfoId,targetStockinfoId,
                            capitalBal,targetBal,capitalDebtBal,targetDebtBal,
                            platPrice,explosionPrice,lever,warnRatio,marginRatio,riskRate,criticalCPPercent,
                            monitorDesc,Chkdate,chkResult)
                    values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitorMargin.Accountid,v_cur_monitorMargin.Acctattr,
                            v_cur_stockinfo.id,v_cur_monitorMargin.Capitalstockinfoid,v_cur_monitorMargin.Targetstockinfoid,v_cur_monitorMargin.Capitalbal,
                            v_cur_monitorMargin.Targetbal,v_cur_monitorMargin.Capitaldebtbal,v_cur_monitorMargin.Targetdebtbal,
                            v_cur_monitorMargin.Platprice,v_explosionPrice,v_lever,v_warnRatio,v_marginRatio,v_riskRate,
                            v_criticalCPPercent,v_monitorDesc,v_t_createDate,monitor_result);
         end if;
     end loop;
     close cur_monitor;
    end loop;
    close cur_stockinfo;
    commit;

    select count(1) into v_l_count
    from  MonitorMargin
    where  chkResult = -1 ;

    if v_l_count > 0 then
       monitor_result := -1;
    else
       monitor_result :=1;
    end if;

    open monitor_data for
      select  -1 accountid,  -- 保证金监控不做账户冻结，所以这里将账户ID直接置为-1
              monitordesc
      from MonitorMargin a
      where chkResult in (-1,-2);

    return_code :=1;
    return_str := '保证金监控成功';
    exception when others then
    --系统自动异常捕捉
    if v_vc_ycbz = 'N' then
       return_code:=-1;
       return_str := '[PKG_MONITOR.SP_MonitorMargin]异常:'||chr(13)||sqlerrm;
    end if;
    --人为考虑系统异常
    if v_vc_ycbz = 'Y' then
       return_str := return_str;
    end if;
    --人为的制造了异常
    if v_vc_ycbz = 'H' then
       return_str := return_str;
    end if;
    rollback;
    sp_monitorRunLogs(v_vc_MonitorType,return_str);
 end sp_monitorMargin;

   /**********************************************************
    名  称： 平台内部总账实时监控
    功  能： 监控平台平台内部资金总账是否对平
    入  参： bizids                业务品种ID
    出  参：return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
               monitor_result   监控结果   (1.对账平衡; -1.对账不平)
               monitor_data     详细的监控结果
               return_str       返回信息
    创建者：jiangsc
    描  述：

    日  期：2017-11-20
  ***********************************************************/
  procedure sp_monitorInternalPlatFundCur(bizids in varchar2,monitor_idx out int,return_code out int,monitor_result out int,monitor_data out resultcur,return_str out varchar2)
  is
     v_l_count                                      number(8);
     v_vc_ycbz                                      varchar2(1);    --异常标志
  begin
     v_vc_ycbz := 'N';
     monitor_result := 1;
     return_code:=-1;
     return_str :='总账监控异常';
     monitor_idx := 0;
     
     select count(1)into v_l_count from monitorconfig where  monitorcode='INTERNALPLATFUNDCUR' and active = 1 and idxid1>0;
     if v_l_count > 0 then
        select idxid1 into monitor_idx from monitorconfig where  monitorcode='INTERNALPLATFUNDCUR' and active = 1 and idxid1>0;
     else
        v_vc_ycbz := 'H';
        return_code:=-1;
        return_str :='总账监控服务未配置或者总账监控指标未配置';
        raise_application_error(v_vc_ycbz, return_str);
     end if;
     
     sp_monitorWalletAsset(return_code,monitor_result,return_str);
     if return_code > 0 then
        sp_monitorSpotAsset(bizids,return_code,monitor_result,return_str);
     end if;

     if return_code < 0 then
        raise_application_error(v_vc_ycbz, return_str);
     end if;

     select count(1) into v_l_count
       from  MonitorMatchFundCur
     where  chkResult = -1 ;

     if v_l_count > 0 then
       monitor_result := -1;
     else
       monitor_result :=1;
     end if;

     open monitor_data for
      select
         case
           when a.acctassettype = 1 then
               '<strong>【时间：'||to_char(a.chkdate, 'yyyy-mm-dd hh24:mi:ss')||'，钱包资产 '||b.stockname||'】</strong>总账不平！资产差额为'||to_char(a.differenceassetbal,'fm999999999990.099999999999')||'，冻结余额差额为'||to_char(a.differencefrozenbal,'fm999999999990.099999999999')||'。'
           when a.acctassettype = 2 and b.canwealth = 'no' then
              '<strong>【时间：'||to_char(a.chkdate, 'yyyy-mm-dd hh24:mi:ss')||'，杠杆资产 '||b.stockname||'】</strong>总账不平！资产差额为'||to_char(a.differenceassetbal,'fm999999999990.099999999999')||' ，负债差额为'||to_char(a.differencedebetbal,'fm999999999990.099999999999')||' ，冻结余额差额为'||to_char(a.differencefrozenbal,'fm999999999990.099999999999')||' 。'
           when a.acctassettype = 2 and b.canwealth = 'yes' then
              '<strong>【时间：'||to_char(a.chkdate, 'yyyy-mm-dd hh24:mi:ss')||'，杠杆资产 '||b.stockname||'】</strong>总账不平！资产为'||to_char(a.assetbal,'fm999999999990.099999999999')||'，负债为'||to_char(a.debetbal,'fm999999999990.099999999999')||'，差额为：'||to_char(a.differenceassetbal,'fm999999999990.099999999999')||'，冻结余额差额为：'||to_char(a.differencefrozenbal,'fm999999999990.099999999999')||'。'
         end monitordesc,
          a.chkresult
        from MonitorMatchFundCur a,stockinfo b
      where a.stockinfoid = b.id
          and a.chkResult < 0 ;

    return_code :=1;
    return_str := '内部资金总账监控成功';
    exception when others then
     --系统自动异常捕捉
     if v_vc_ycbz = 'N' then
        return_code:=-1;
        return_str := '[PKG_MONITOR.sp_monitorInternalPlatFundCur]报异常错误:'||chr(13)||sqlerrm;
     end if;
     --人为考虑系统异常
     if v_vc_ycbz = 'Y' then
        return_str := return_str;
     end if;
     --人为的制造了异常
     if v_vc_ycbz = 'H' then
        return_str := return_str;
     end if;
  end sp_monitorInternalPlatFundCur;

  /**********************************************************
    名  称： 钱包资产总账实时监控
    功  能： 监控币对维度钱包资产总额与钱包资金流水总额
    入  参：  bizids           业务品种ID
    出  参：  return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
              monitor_result   监控结果   (1.对账平衡; -1.对账不平)
              monitor_data     详细的监控结果
              return_str       返回信息
    创建者：jiangsc
    描  述：

    日  期：2017-11-20
  ***********************************************************/
   procedure sp_monitorWalletAsset(return_code out int,monitor_result out int,return_str out varchar2)
   is

     v_vc_ycbz                             varchar2(1);                              --异常标志
     v_vc_MonitorType                      varchar2(32);
     v_vc_Monitorsubtype                   varchar2(32);
     v_vc_Monitorname                      varchar2(200);
     v_vc_TargetTable                      varchar2(32);

     v_l_id                                number(20);
     v_t_initQueryTime                     timestamp;                               --查询起始化日期
     v_t_startDate                         timestamp;
     v_differenceassetbal                  number(24, 12);
     v_differencefrozenbal                 number(24, 12);
     v_monitorDesc                         varchar2(500);
     v_sql_monitor                         varchar2(4000);
     cur_monitor                           resultcur;
     v_cur_monitor                         monitorMatchFundCur%rowtype;
   begin
     --=======================================
     -- 初始化变量值
     --=======================================
   v_t_initQueryTime :=to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
     monitor_result := 1;
     v_vc_MonitorType := 'INTERNALPLATFUNDCUR';
   v_vc_Monitorsubtype :='PLAT';
     v_vc_Monitorname := '内部资金总账';
     v_vc_TargetTable := 'monitorMatchFundCur';

     --=======================================
     -- 增量监控，取上一个结算结束日期作为本次监控起始日期
     --=======================================
     select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 1 ;

     v_vc_ycbz := 'N';
     return_code := -1;
     return_str := '[PKG_MONITOR.sp_monitorWalletAsset] 钱包资产总账监控成功';
     v_sql_monitor :='select rownum id,'''' monitorType,'''' monitorSubType,1 acctassettype,asset.stockinfoid bizcategoryid,asset.stockinfoid,asset.stockinfoid relatedstockinfoid,
                             nvl(assetbal,0) assetbal,nvl(assetfrozenbal,0) assetfrozenbal,0 debetbal,
                             nvl(curbal,0)+asset.beginbal curassetbal,nvl(curfrozenbal,0)+asset.beginfrozenbal curfrozenbal,0 curdebetbal,
                             0 inbal, 0 outbal, 0 borrowdebetbal,0 feebal,0 closepositiondebetbal,0 closepositionassetbal, 0 closepositionreturnbal,
                             0 differencedebetbal,0 differenceassetbal,0 differencefrozenbal,'''' monitordesc,0 chkresult, systimestamp chkdate
                        from (select stockinfoid, sum(amount) assetbal,sum(frozenamt)assetfrozenbal,sum(beginbal) beginbal,sum(beginfrozenbal) beginfrozenbal
                                from (select a.accountid,a.stockinfoid,a.amount,a.frozenamt,nvl(b.endbal, 0) beginbal,nvl(b.endfrozenbal, 0) beginfrozenbal
                                        from accountWalletAsset a,
                                             (select accountid, stockinfoid, endbal, endfrozenbal,endfeebal from monitorbalance where acctassettype = 1 and businessdate = :1) b
                                       where a.accountid = b.accountid(+) and a.stockinfoid = b.stockinfoid(+))
                                group by stockinfoid)asset,
                             (select stockinfoid, sum((occuramt-fee) * decode(occurdirect, ''increase'', 1, -1)) curBal,sum(occurforzenamt * decode(occurdirect, ''frozen'', 1, -1)) curFrozenBal
                                from accountFundCurrent
                               where currentdate > :2
                               group by stockinfoid)cur
                        where asset.stockinfoid= cur.stockinfoid(+)';
     open cur_monitor for v_sql_monitor
     using v_t_startDate,v_t_startDate;
     loop
     fetch cur_monitor into v_cur_monitor;
     exit when cur_monitor%notFound;

         v_l_id := 1100000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;

         v_differenceassetbal := abs(v_cur_monitor.assetbal - v_cur_monitor.curassetbal);
         v_differencefrozenbal := abs(v_cur_monitor.assetfrozenbal - v_cur_monitor.curfrozenbal);

         if v_differenceassetbal = 0   and  v_differencefrozenbal =0   then
            monitor_result := 1;
            v_monitorDesc :='';
         else
           monitor_result := -1;
           v_monitorDesc := '[时间：'||to_char(v_cur_monitor.chkdate, 'yyyy-mm-dd hh24:mi:ss')||' 钱包账户 证券ID:'||v_cur_monitor.stockinfoid||' 总账不平！资产差额为：'||to_char(v_differenceassetbal,'fm999999999990.099999999999')||
                                       ',冻结余额差额为：'||to_char(v_differencefrozenbal,'fm999999999990.099999999999')||' 。';
           insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                            values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid);
         end if;

         merge into MonitorMatchFundCur a
         using (select 1 acctassettype,v_cur_monitor.stockinfoid stockinfoid from dual) b
            on (a.acctassettype = b.acctassettype and a.stockinfoid = b.stockinfoid)
         when matched then
               update set assetbal = v_cur_monitor.assetbal,
                          assetfrozenbal = v_cur_monitor.assetfrozenbal,
                          curassetbal = v_cur_monitor.curassetbal,
                          curfrozenbal = v_cur_monitor.curfrozenbal,
                          differenceassetbal = v_differenceassetbal,
                          differencefrozenbal = v_differencefrozenbal,
                          monitordesc = v_monitorDesc,
                          chkresult = monitor_result,
                          chkdate = v_cur_monitor.chkdate
         when not matched then
               insert (id,monitortype,monitorsubtype,bizcategoryid,stockinfoid,relatedstockinfoid,
                       assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                       inbal,outbal,borrowdebetbal,feebal,
                       closepositiondebetbal,closepositionassetbal,closepositionreturnbal,
                       differencedebetbal,differenceassetbal,differencefrozenbal,
                       monitordesc,chkresult,chkdate,acctassettype)
               values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,
                       v_cur_monitor.assetbal,v_cur_monitor.assetfrozenbal,v_cur_monitor.debetbal,v_cur_monitor.curassetbal,v_cur_monitor.curfrozenbal,v_cur_monitor.curdebetbal,
                       v_cur_monitor.inbal,v_cur_monitor.outbal,v_cur_monitor.borrowdebetbal,v_cur_monitor.feebal,
                       v_cur_monitor.closepositiondebetbal,v_cur_monitor.closepositionassetbal,v_cur_monitor.closepositionreturnbal,
                       0,v_differenceassetbal,v_differencefrozenbal,
                       v_monitorDesc,monitor_result,v_cur_monitor.chkdate,1);
     end loop;
     close cur_monitor;
     commit;

     return_code :=1;
     return_str := '钱包资产总账监控成功';
     exception when others then
        --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := '[PKG_MONITOR.sp_monitorWalletAsset]报异常错误:'||chr(13)||sqlerrm;
        end if;
         --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
        rollback;
    sp_monitorRunLogs(v_vc_MonitorType,return_str);
   end sp_monitorWalletAsset;

   /**********************************************************
    名  称： 钱包资产总账实时监控
    功  能： 监控币对维度钱包资产总额与钱包资金流水总额
    入  参：  bizids           业务品种ID
    出  参：  return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
              monitor_result   监控结果   (1.对账平衡; -1.对账不平)
              monitor_data     详细的监控结果
              return_str       返回信息
    创建者：jiangsc
    描  述：

    日  期：2017-11-20
   ***********************************************************/
   procedure sp_monitorWalletAcctAsset(return_code out int,monitor_result out int,return_str out varchar2)
   is

     v_vc_ycbz                                varchar2(1);              --异常标志
     v_vc_MonitorType                         varchar2(32);
     v_vc_Monitorsubtype                      varchar2(32);
     v_vc_Monitorname                         varchar2(200);
     v_vc_TargetTable                         varchar2(32);

     v_sql_monitor                            varchar2(3000);
     cur_monitor                              resultcur;
     v_cur_monitor                            MonitorAcctFundCur%rowtype;
     v_l_id                                   number(20);
     v_l_datasource                           number(1);
     v_t_initQueryTime                        timestamp;                  --查询起始化日期
     v_t_bizDate                              timestamp;
     v_t_startDate                            timestamp;
     v_MonitorDesc                            varchar2(500);
     v_differenceassetbal                     number(24, 12);
     v_differencefrozenbal                    number(24, 12);
   begin
     monitor_result := 1;
     v_vc_MonitorType := 'ACCTFUNDCUR';
     v_vc_Monitorsubtype :='ACCT';
         v_vc_Monitorname := '账户资金监控';
         v_vc_TargetTable := 'MonitorAcctFundCur';
         v_t_initQueryTime := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
     v_t_bizDate := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
     --=======================================
     -- 增量监控，取上一个结算结束日期作为本次监控起始日期
     --=======================================
     select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 1 ;
     v_vc_ycbz := 'N';
     return_code := -1;
     return_str := '[PKG_MONITOR.sp_monitorWalletAcctAsset] 钱包账户资产监控异常';
     v_l_datasource :=1;
     v_sql_monitor := 'select rownum id,'''' monitorType,'''' monitorSubType,asset.accountid,1 acctassettype,asset.stockinfoid bizcategoryID,asset.stockinfoid,asset.stockinfoid relatedstockinfoid,asset.amount assetbal,asset.frozenamt assetfrozenbal,0 debetBal,
                              nvl(cur.curbal,0)+asset.beginbal curAssetBal ,nvl(cur.curfrozenbal,0)+asset.beginfrozenbal curfrozenbal ,0 curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                              '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                         from (select a.accountid,a.stockinfoid,a.amount,a.frozenamt,nvl(b.endbal,0) beginbal,nvl(b.endfrozenbal,0) beginfrozenbal
                                 from accountWalletAsset a,
                                      (select accountid,stockinfoid,endbal,endfrozenbal,endfeebal from monitorbalance where acctassettype = 1 and businessdate=:1)b
                                where a.accountid = b.accountid(+)
                                  and a.stockinfoid = b.stockinfoid(+))asset,
                              (select accountid,stockinfoid,sum((occuramt-fee) * decode(occurdirect,''increase'',1,-1))curbal,sum(occurforzenamt * decode(occurdirect,''frozen'',1,-1))curfrozenbal
                                 from accountFundCurrent
                                where currentdate > :2
                                group by accountid,stockinfoid)cur
                         where asset.accountid = cur.accountid(+)
                           and asset.stockinfoid = cur.stockinfoid(+)';
     open cur_monitor for v_sql_monitor
     using v_t_startDate,v_t_startDate;
     loop
     fetch cur_monitor into v_cur_monitor;
     exit when cur_monitor%notFound;
        v_monitorDesc :='';
        v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;
        v_differencefrozenbal :=v_cur_monitor.assetfrozenbal - v_cur_monitor.curfrozenbal;
        if  v_differenceassetbal = 0 and v_differencefrozenbal = 0 then
           monitor_result := 1;
        else
           monitor_result := -1;
           v_monitorDesc :='[钱包资产账户:'||v_cur_monitor.accountid||' 数字货币:'||v_cur_monitor.stockinfoid||'] 资产与资金流水对不上,资产差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999')||'，冻结余额差额:'||to_char(v_differencefrozenbal,'fm999999999990.099999999999');
        end  if;

        v_l_id := 1200000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;

        if monitor_result < 1 then
           insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                            values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
        end if;
        merge into MonitorAcctFundCur a
        using (select v_cur_monitor.accountid accountid,v_cur_monitor.stockinfoid stockinfoid,v_cur_monitor.acctassettype  acctassettype from dual) b
           on (a.accountid = b.accountid and a.stockinfoid = b.stockinfoid and a.acctassettype = b.acctassettype)
        when matched then
              update set assetbal = v_cur_monitor.assetbal,
                                    assetfrozenbal = v_cur_monitor.assetfrozenbal,
                                    curassetbal = v_cur_monitor.curassetbal,
                                    curfrozenbal = v_cur_monitor.curfrozenbal,
                                    differenceassetbal = v_differenceassetbal,
                                    differencefrozenbal = v_differencefrozenbal,
                                    monitordesc = v_monitorDesc,
                                    chkresult = monitor_result,
                                    chkdate = v_cur_monitor.chkdate
        when not matched then
              insert (id,monitorType,monitorSubType,accountId,bizcategoryid,relatedstockinfoid,stockinfoid,
                      assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                      differencedebetbal,differenceassetbal,differencefrozenbal,
                      monitordesc,chkresult,bizDate,chkdate)
              values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,
                      v_cur_monitor.assetbal,v_cur_monitor.assetfrozenbal,v_cur_monitor.debetbal,v_cur_monitor.curassetbal,v_cur_monitor.curfrozenbal,v_cur_monitor.curdebetbal,
                      0,v_differenceassetbal,v_differencefrozenbal,
                      v_monitorDesc,monitor_result,v_t_bizDate,v_cur_monitor.chkdate);
   end loop;
     close cur_monitor;
     commit;
   return_code :=1;
     return_str := '钱包账户资产监控成功';
     exception when others then
        --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := '[PKG_MONITOR.sp_monitorWalletAcctAsset]报异常错误:'||chr(13)||sqlerrm;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
        rollback;
    sp_monitorRunLogs(v_vc_MonitorType,return_str);
   end sp_monitorWalletAcctAsset;

   /**********************************************************
      名  称： 钱包资产总账实时监控
      功  能： 监控币对维度钱包资产总额与钱包资金流水总额
      入  参：  bizids                业务品种ID
      出  参：  return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
                monitor_result   监控结果   (1.对账平衡; -1.对账不平)
                monitor_data     详细的监控结果
                return_str       返回信息
      创建者：jiangsc
      描  述：

      日  期：2017-11-20
   ***********************************************************/
   procedure sp_monitorSpotAsset(bizids in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
   is

       v_vc_ycbz                              varchar2(1);                  --异常标志
       v_vc_MonitorType                       varchar2(32);
       v_vc_Monitorsubtype                    varchar2(32);
       v_vc_Monitorname                       varchar2(200);
       v_vc_TargetTable                       varchar2(32);

       v_l_id                                 number(20);
       v_l_relatedstockinfoid                 number(20);
       v_t_initQueryTime                      timestamp;                     --查询起始化日期
       v_t_startDate                          timestamp;
       v_l_bizCategoryId                      number(20);                    --  业务品种ID
       v_l_targetStockInfoId                  number(20);                    --  标的证券ID
       v_l_capitalStockInfoId                 number(20);                    --  标的证券ID
       v_differencedebetbal                   number(24, 12);
       v_differenceassetbal                   number(24, 12);
       v_differencefrozenbal                  number(24, 12);
       v_monitorDesc                          varchar2(500);
       v_sql_targetMonitor                    varchar2(6500);                -- 标的总额监控SQL
       v_sql_capitalMonitor                   varchar2(6500);                -- 计价总额监控SQL
       cur_monitor                            resultcur;
       v_cur_monitor                          monitorMatchFundCur%rowtype;

       cursor cur_stockinfo is
              select id,maxlonglever,maxshortlever,tableasset,tablerealdeal,tablefundcurrent,tabledebitasset,preclosepositionratio,
                            closePositionLongPrePercent, closePositionShortPrePercent,stockname,tradestockinfoid,capitalstockinfoid
                from stockinfo
               where id in (select * from table(sf_strsplit(bizids))) and stocktype = 'leveragedSpot';
       v_cur_stockinfo                        cur_stockinfo%rowtype;
   begin
      --=======================================
      -- 初始化变量值
      --=======================================
      v_t_initQueryTime := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
      monitor_result := 1;
      v_vc_MonitorType := 'INTERNALPLATFUNDCUR';
    v_vc_Monitorsubtype :='PLAT';
      v_vc_Monitorname := '内部资金总账';
      v_vc_TargetTable := 'monitorMatchFundCur';


      v_vc_ycbz := 'N';
      return_code := -1;
      return_str := '[PKG_MONITOR.sp_monitorSpotAsset] 现货总账监控成功';
      open cur_stockinfo;
      loop
      fetch cur_stockinfo into v_cur_stockinfo;
      exit when cur_stockinfo%notFound;

         --=======================================
         -- 增量监控，取上一个结算结束日期作为本次监控起始日期
         --=======================================
         select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 2 ;
            /**
             *    杠杆现货特点：
             *       钱包资产  专区 - 账户 - 币
             *       负债资产  专区- 账户 - 品种 - 币
             *       流水        专区- 账户 - 品种 - 币
             *       业务表区分品种，所以查询时不加品种的过滤条件
             *
             */
         v_sql_targetMonitor :='select rownum id,'''' monitorType,'''' monitorSubType,2 acctassettype,0 bizcategoryid,0 stockinfoid,0 relatedstockinfoid,
                                       nvl(assetbal,0) assetbal,nvl(assetfrozenbal,0) assetfrozenbal,nvl(debtBal,0) debetbal,
                                       nvl(curbal,0)+beginbal curassetbal,nvl(curfrozenbal,0)+beginfrozenbal curfrozenbal,nvl(curDebt,0)+begindebitBal curdebetbal,
                                       0 inbal, 0 outbal, 0 borrowdebetbal,0 feebal,0 closepositiondebetbal,0 closepositionassetbal, 0 closepositionreturnbal,
                                       0 differencedebetbal,0 differenceassetbal,0 differencefrozenbal,'''' monitordesc,0 chkresult, systimestamp chkdate
                                 from  (select sum(amount)assetbal,sum(frozenamt)assetfrozenbal,sum(beginbal) beginbal,sum(beginfrozenbal) beginfrozenbal
                                          from  (select a.stockinfoid,a.amount,a.frozenamt,nvl(b.endbal,0)beginbal,nvl(b.endfrozenbal,0)beginfrozenbal
                                                   from '||v_cur_stockinfo.tableasset||' a ,
                                                        (select accountid,stockinfoid, endbal, endfrozenbal from monitorbalance a  where acctassettype = 2  and businessdate = :1 )b
                                                  where a.accountid = b.accountid(+) and a.stockinfoid = b.stockinfoid(+) and a.stockinfoid =:2 ) group by stockinfoid )asset,
                                                (select sum((b.occuramt - b.fee)*decode(b.occurdirect,''increase'',1,''decrease'',-1,''unfrozenDecrease'',-1)) curbal,
                                                        sum((b.occurforzenamt)*decode(b.occurdirect,''frozen'',1,''unfrozen'',-1,''unfrozenDecrease'',-1,0))  curfrozenbal,
                                                        sum(decode(businessflag,''matchTradeSpotClosePositionAssetTransfer'',occuramt,0)) closePositionAssetBal,
                                                        sum(decode(businessflag,''matchTradeSpotReturnVCOIN'',occuramt,0)) closePositionReturnBal,
                                                        sum(decode(businessflag,''matchTradeSpotFeeVCOIN'',occuramt,0)) feebal
                                                   from '||v_cur_stockinfo.tableasset||' a, '||v_cur_stockinfo.tablefundcurrent||' b
                                                where a.accountid = b.accountid and a.stockinfoid = b.stockinfoid
                                                  and a.stockinfoid =:3
                                                  and accountassettype = ''spotAccountAsset''
                                                  and b.currentdate > :4
                                                  and b.businessflag in(''wallet2Spot'', ''spot2Wallet'',''spot2Wealth'',''wealth2Spot'',
                                                                        ''matchTradeSpotAutoDebit'',''matchTradeSpotAutoDebitInterest'',
                                                                        ''matchTradeSpotBuyEntrustDeal'', ''matchTradeSpotFeeVCOIN'',
                                                                        ''matchTradeSpotClosePositionAssetTransfer'',''matchTradeSpotReturnVCOIN'',
                                                                        ''matchTradeSpotSellEntrust'', ''matchTradeSpotSellEntrustDeal'',''matchTradeSpotSellEntrustWithdraw'',
                                                                        ''matchTradeSpotAutoDebit'',''matchTradeSpotAutoDebitRepayment''))curasset,
                                                (select sum(debitamt) debtBal,sum(begindebitBal) begindebitBal
                                                   from (select a.debitamt,a.stockinfoid,nvl(b.endbal,0)begindebitBal
                                                          from '||v_cur_stockinfo.tabledebitasset||' a,
                                                               (select accountid,stockinfoid, endbal from monitorbalance a  where acctassettype = 3  and businessdate = :5 )b
                                                         where a.borroweraccountid = b.accountid(+) and a.stockinfoid = b.stockinfoid(+) and a.stockinfoid =:6)
                                                         group by stockinfoid )debt,
                                                (select sum((b.occuramt)*decode(b.occurdirect,''increase'',1,''decrease'',-1,''unfrozenDecrease'',-1,0)) curDebt ,
                                                        sum(decode(businessflag,''matchTradeSpotAutoDebit'',occuramt,''matchTradeSpotAutoDebitRepayment'',-occuramt,0)) borrowDebetBal,
                                                        sum(decode(businessflag,''matchTradeSpotClosePositionDebitTransfer'',occuramt,0)) closePositionDebetBal
                                                   from '||v_cur_stockinfo.tabledebitasset||' a,'||v_cur_stockinfo.tablefundcurrent||' b
                                                where a.borroweraccountid = b.accountid and a.stockinfoid = b.stockinfoid
                                                  and a.stockinfoid = :7
                                                  and accountassettype=''spotAccountDebit''
                                                  and b.currentdate > :8
                                                  and b.businessflag in(''matchTradeSpotAutoDebit'',''matchTradeSpotAutoDebitRepayment'',
                                                                        ''matchTradeSpotClosePositionDebitTransfer'',''matchTradeSpotAutoDebitInterest''))curdebt';
         open cur_monitor for v_sql_targetMonitor
         using v_t_startDate,v_cur_stockinfo.tradestockinfoid,
               v_cur_stockinfo.tradestockinfoid,v_t_startDate,
               v_t_startDate,v_cur_stockinfo.tradestockinfoid,
               v_cur_stockinfo.tradestockinfoid, v_t_startDate;
         loop
         fetch cur_monitor into v_cur_monitor;
         exit when cur_monitor%notFound;
             v_l_id := 1300000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;

             v_l_bizCategoryId := v_cur_stockinfo.capitalstockinfoid; -- 专区代码
             v_l_relatedstockinfoid := v_cur_stockinfo.id;            -- 币对代码
             v_l_targetStockInfoId := v_cur_stockinfo.tradestockinfoid;
             v_vc_Monitorsubtype :='TARGET';
             v_differencedebetbal := abs(v_cur_monitor.debetbal - v_cur_monitor.curdebetbal);
             v_differenceassetbal := abs(v_cur_monitor.assetbal - v_cur_monitor.curassetbal);
             v_differencefrozenbal := abs(v_cur_monitor.assetfrozenbal - v_cur_monitor.curfrozenbal);

             if  v_differencedebetbal = 0  and
                 v_differenceassetbal = 0   and
                 v_differencefrozenbal = 0
             then
                monitor_result := 1;
                v_monitorDesc :='';
             else
               monitor_result := -1;
               v_monitorDesc := '[时间：'||to_char(v_cur_monitor.chkdate, 'yyyy-mm-dd hh24:mi:ss')||' 业务品种ID：'||v_l_bizCategoryId||' 标的证券ID:'||v_l_targetStockInfoId||' 现货总账不平！资产差额为：'||to_char(v_differenceassetbal,'fm999999999990.099999999999')||
                                           ' ，负债差额为：'||to_char(v_differencedebetbal,'fm999999999990.099999999999')||',冻结余额差额为：'||to_char(v_differencefrozenbal,'fm999999999990.099999999999')||' 。';

               insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                                values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_l_bizCategoryId,v_l_relatedstockinfoid);

             end if;

             merge into MonitorMatchFundCur a
             using (select v_l_bizCategoryId bizcategoryid,v_l_targetStockInfoId stockinfoid ,v_l_relatedstockinfoid relatedstockinfoid,v_cur_monitor.acctassettype acctassettype from dual) b
                on (a.bizcategoryid = b.bizcategoryid and a.stockinfoid = b.stockinfoid and a.relatedstockinfoid = b.relatedstockinfoid and a.acctassettype = b.acctassettype)
             when matched then
                   update set assetbal = v_cur_monitor.assetbal,
                              assetfrozenbal = v_cur_monitor.assetfrozenbal,
                              debetbal = v_cur_monitor.debetbal,
                              curassetbal = v_cur_monitor.curassetbal,
                              curfrozenbal = v_cur_monitor.curfrozenbal,
                              curdebetbal = v_cur_monitor.curdebetbal,
                              inbal = v_cur_monitor.inbal,
                              outbal = v_cur_monitor.outbal,
                              borrowdebetbal = v_cur_monitor.borrowdebetbal,
                              feebal = v_cur_monitor.feebal,
                              closepositiondebetbal = v_cur_monitor.closepositiondebetbal,
                              closepositionassetbal = v_cur_monitor.closepositionassetbal,
                              closepositionreturnbal = v_cur_monitor.closepositionreturnbal,
                              differencedebetbal = v_differencedebetbal,
                              differenceassetbal = v_differenceassetbal,
                              differencefrozenbal = v_differencefrozenbal,
                              monitordesc = v_monitorDesc,
                              chkresult = monitor_result,
                              chkdate = v_cur_monitor.chkdate
             when not matched then
                   insert (id,monitortype,monitorsubtype,bizcategoryid,stockinfoid,relatedstockinfoid,
                           assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                           inbal,outbal,borrowdebetbal,feebal,
                           closepositiondebetbal,closepositionassetbal,closepositionreturnbal,
                           differencedebetbal,differenceassetbal,differencefrozenbal,
                           monitordesc,chkresult,chkdate,acctassettype)
                    values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_l_bizCategoryId,v_l_targetStockInfoId,v_l_relatedstockinfoid,
                            v_cur_monitor.assetbal,v_cur_monitor.assetfrozenbal,v_cur_monitor.debetbal,v_cur_monitor.curassetbal,v_cur_monitor.curfrozenbal,v_cur_monitor.curdebetbal,
                            v_cur_monitor.inbal,v_cur_monitor.outbal,v_cur_monitor.borrowdebetbal,v_cur_monitor.feebal,
                            v_cur_monitor.closepositiondebetbal,v_cur_monitor.closepositionassetbal,v_cur_monitor.closepositionreturnbal,
                            v_differencedebetbal,v_differenceassetbal,v_differencefrozenbal,
                            v_monitorDesc,monitor_result,v_cur_monitor.chkdate,2);

                end loop;
               close cur_monitor;

                v_sql_capitalMonitor :=  'select rownum id,'''' monitorType,'''' monitorSubType,2 acctassettype,0 bizcategoryid,0 stockinfoid,0 relatedstockinfoid,
                                                              nvl(assetbal,0) assetbal,nvl(assetfrozenbal,0) assetfrozenbal,nvl(debtBal,0) debetbal,
                                                              0 curassetbal,nvl(cur.curfrozenbal,0)+nvl(bal.beginfrozenbal,0) curfrozenbal,0 curdebetbal,0 inbal, 0 outbal, 0 borrowdebetbal,0 feebal,
                                                              0 closepositiondebetbal,0 closepositionassetbal, 0 closepositionreturnbal,
                                                              0 differencedebetbal,0 differenceassetbal,0 differencefrozenbal,'''' monitordesc,0 chkresult, systimestamp chkdate from
                                                    (select stockinfoid ,sum(bal) assetbal,sum(frozenbal) assetfrozenbal,sum(debitbal)debtBal
                                                     from (select stockinfoid,sum(amount) bal,sum(frozenamt)frozenbal,0 debitbal from '||v_cur_stockinfo.tableasset||'   where stockinfoid = :1 group by stockinfoid
                                                            union all
                                                        select stockinfoid,sum(wealthamt)bal,0 frozenbal,0 debitbal  from accountwealthasset where stockinfoid = :2 group by stockinfoid
                                                        union all
                                                        select stockinfoid,0 bal,0 frozenbal,sum(debitamt) debitbal from  '||v_cur_stockinfo.tabledebitasset||'  where  stockinfoid = :3 group by stockinfoid
                                                        union all
                                                        select stockinfoid,0 bal,0 frozenbal,sum(debitamt) debitbal  from accountwealthdebitasset  where  stockinfoid = :4 group by stockinfoid)
                                                        group by stockinfoid)asset,
                                                          (select stockinfoid,sum((b.occurforzenamt) * decode(b.occurdirect,''frozen'',1,-1)) curfrozenbal
                                                           from '||v_cur_stockinfo.tablefundcurrent||' b
                                                         where accountassettype = ''spotAccountAsset''
                                                             and stockinfoid = :5 group by  stockinfoid)cur,
                                                          (select stockinfoid,sum(endfrozenbal)beginfrozenbal from monitorbalance a  where acctassettype = 2  and stockinfoid =:6 and businessdate = :7  group by stockinfoid)bal
                                                          where asset.stockinfoid = cur.stockinfoid(+) and asset.stockinfoid =bal.stockinfoid(+)';

               open cur_monitor for v_sql_capitalMonitor
                using  v_cur_stockinfo.capitalstockinfoid,            -- 标的ID
                          v_cur_stockinfo.capitalstockinfoid,            -- 标的ID
                          v_cur_stockinfo.capitalstockinfoid,            -- 标的ID
                          v_cur_stockinfo.capitalstockinfoid,            -- 标的ID
                          v_cur_stockinfo.capitalstockinfoid,
                          v_cur_stockinfo.capitalstockinfoid,
                          v_t_startDate;
                loop
                   fetch cur_monitor into v_cur_monitor;
                   exit when cur_monitor%notFound;
                   v_l_id := 1400000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;
                   v_l_bizCategoryId := v_cur_stockinfo.capitalstockinfoid;
                   v_l_relatedstockinfoid := v_cur_stockinfo.id;
                   v_l_capitalStockInfoId := v_cur_stockinfo.capitalstockinfoid;
                   v_vc_Monitorsubtype :='CAPITAL';

                   v_differencefrozenbal := abs(v_cur_monitor.assetfrozenbal - v_cur_monitor.curfrozenbal);
                   v_differenceassetbal := abs(v_cur_monitor.assetbal - v_cur_monitor.debetbal);
                   v_differencedebetbal :=0;
                   -- 说明：杠杆现货计价对账结合理财比对 ： USD总负债 = USD 总持仓； 杠杆总负债 + 理财应付利息 = 杠杆总持仓 + 理财资产+理财应收利息
                   if  v_differenceassetbal = 0  and v_differencefrozenbal = 0  then
                      monitor_result := 1;
                      v_monitorDesc :='';
                   else
                     monitor_result := -1;
                     v_monitorDesc := '[时间：'||to_char(v_cur_monitor.chkdate, 'yyyy-mm-dd hh24:mi:ss')||' 业务品种ID：'||v_l_bizCategoryId||' 计价证券ID:'||v_l_capitalStockInfoId||' 现货总账不平！资产为：'||to_char(v_cur_monitor.assetbal,'fm999999999990.099999999999')||
                                                 ' ，负债为：'||to_char(v_cur_monitor.debetbal,'fm999999999990.099999999999')||',差额为：'||to_char(v_differenceassetbal,'fm999999999990.099999999999')||',冻结余额差额为：'||to_char(v_differencefrozenbal,'fm999999999990.099999999999');

                     insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                         values(v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_l_bizCategoryId,v_l_relatedstockinfoid);

                   end if;

                    merge into MonitorMatchFundCur a
                     using (select v_l_bizCategoryId bizcategoryid,v_l_capitalStockInfoId stockinfoid,v_l_relatedstockinfoid relatedstockinfoid ,v_cur_monitor.acctassettype acctassettype  from dual) b
                         on (a.bizcategoryid = b.bizcategoryid and a.stockinfoid = b.stockinfoid and a.relatedstockinfoid = b.relatedstockinfoid and a.acctassettype = b.acctassettype)
                     when matched then
                                 update
                                       set  assetbal = v_cur_monitor.assetbal,
                                              assetfrozenbal = v_cur_monitor.assetfrozenbal,
                                              debetbal = v_cur_monitor.debetbal,
                                              curassetbal = v_cur_monitor.curassetbal,
                                              curfrozenbal = v_cur_monitor.curfrozenbal,
                                              curdebetbal = v_cur_monitor.curdebetbal,
                                              inbal = v_cur_monitor.inbal,
                                              outbal = v_cur_monitor.outbal,
                                              borrowdebetbal = v_cur_monitor.borrowdebetbal,
                                              feebal = v_cur_monitor.feebal,
                                              closepositiondebetbal = v_cur_monitor.closepositiondebetbal,
                                              closepositionassetbal = v_cur_monitor.closepositionassetbal,
                                              closepositionreturnbal = v_cur_monitor.closepositionreturnbal,
                                              differencedebetbal = v_differencedebetbal,
                                              differenceassetbal = v_differenceassetbal,
                                              differencefrozenbal = v_differencefrozenbal,
                                              monitordesc = v_monitorDesc,
                                              chkresult = monitor_result,
                                              chkdate = v_cur_monitor.chkdate
                     when not matched then
                                     insert (id,monitortype,monitorsubtype,bizcategoryid,stockinfoid,relatedstockinfoid,
                                                assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                                                inbal,outbal,borrowdebetbal,feebal,
                                                closepositiondebetbal,closepositionassetbal,closepositionreturnbal,
                                                differencedebetbal,differenceassetbal,differencefrozenbal,
                                                monitordesc,chkresult,chkdate,acctassettype)
                                     values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_l_bizCategoryId,v_l_capitalStockInfoId,v_l_relatedstockinfoid,
                                                v_cur_monitor.assetbal,v_cur_monitor.assetfrozenbal,v_cur_monitor.debetbal,v_cur_monitor.curassetbal,v_cur_monitor.curfrozenbal,v_cur_monitor.curdebetbal,
                                                v_cur_monitor.inbal,v_cur_monitor.outbal,v_cur_monitor.borrowdebetbal,v_cur_monitor.feebal,
                                                v_cur_monitor.closepositiondebetbal,v_cur_monitor.closepositionassetbal,v_cur_monitor.closepositionreturnbal,
                                                v_differencedebetbal,v_differenceassetbal,v_differencefrozenbal,
                                                v_monitorDesc,monitor_result,v_cur_monitor.chkdate,2);

         end loop;
         close cur_monitor;

      end loop;
      close cur_stockinfo;
      commit;
      return_code :=1;
      return_str := '杠杆现货总账监控成功';
      exception when others then
        --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := '[PKG_MONITOR.sp_monitorSpotAsset]报异常错误:'||chr(13)||sqlerrm;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
        rollback;
        sp_monitorRunLogs(v_vc_MonitorType,return_str);
   end sp_monitorSpotAsset;

   /**********************************************************
      名  称： 钱包资产总账实时监控
      功  能： 监控币对维度钱包资产总额与钱包资金流水总额
      入  参：  bizids                业务品种ID
      出  参：  return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
                   monitor_result   监控结果   (1.对账平衡; -1.对账不平)
                   monitor_data     详细的监控结果
                  return_str       返回信息
      创建者：jiangsc
      描  述：

      日  期：2017-11-20
    ***********************************************************/
  procedure sp_monitorSpotAcctAsset(bizids in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
  is
    v_vc_ycbz                         varchar2(1);
    v_vc_MonitorType                  varchar2(32);
    v_vc_Monitorsubtype               varchar2(32);
    v_vc_Monitorname                  varchar2(200);
    v_vc_TargetTable                  varchar2(32);

    v_l_id                            number(20);
    v_l_relatedstockinfoid            number(20);
    v_t_startDate                     timestamp;
    v_t_bizDate                       timestamp;
    v_l_bizcategoryid                 number(20);
    v_t_initQueryTime                 timestamp;
    v_differencedebetbal              number(24, 12);
    v_differenceassetbal              number(24, 12);
    v_differencefrozenbal             number(24, 12);
    v_debitDesc                       varchar2(500);
    v_assetDesc                       varchar2(500);
    v_monitorDesc                     varchar2(500);
    v_sql_query                       varchar2(5000);
    cur_monitor                       resultcur;
    v_cur_monitor                     MonitorAcctFundCur%rowtype;
    cursor cur_stockinfo is
              select id,tableasset,tablerealdeal,tabledebitasset,tablefundcurrent,tradestockinfoid,capitalstockinfoid
                from stockinfo where id in (select * from table(sf_strsplit(bizids))) and stocktype = 'leveragedSpot';
    v_cur_stockinfo                   cur_stockinfo%rowtype;
  begin

    v_vc_MonitorType := 'ACCTFUNDCUR';
    v_vc_Monitorname := '账户资金监控';
    v_vc_TargetTable := 'MonitorAcctFundCur';
    v_t_initQueryTime := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
    v_t_bizDate := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');

    v_vc_ycbz := 'N';
    return_code := -1;
    return_str := '[PKG_MONITOR.sp_monitorSpotAcctAsset] open cur_stockinfo 现货账户资金循环账户时监控异常！';
    open cur_stockinfo;
    loop
    fetch cur_stockinfo into v_cur_stockinfo;
    exit when cur_stockinfo%notFound;

     --=======================================
       -- 增量监控，取上一个结算结束日期作为本次监控起始日期
       --=======================================
       select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 2 ;

       v_sql_query :='select rownum id,'''' monitorType,'''' monitorSubType,asset.accountid,2 acctassettype,0 bizcategoryID,asset.stockinfoid,0 relatedstockinfoid,asset.assetbal,asset.frozenassetbal assetfrozenbal,nvl(debet.debtBal,0) debetBal,
                             nvl(cur.curbal,0)+nvl(asset.beginbal,0) curAssetBal ,nvl(cur.curfrozenbal,0)+nvl(asset.beginFrozenbal,0) curfrozenbal,nvl(cur.curDebt,0)+nvl(debet.beginDebitbal,0) curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                             '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                        from (select a.accountid,a.stockinfoid,a.amount assetbal,a.frozenamt frozenassetbal,nvl(endbal,0)beginbal,nvl(endfrozenbal,0)beginFrozenbal
                                from '||v_cur_stockinfo.tableasset||' a,
                                      (select accountid,stockinfoid, endbal, endfrozenbal from monitorbalance where acctassettype = 2 and businessdate = :1 )b
                                        where a.accountid=b.accountid(+) and a.stockinfoid = b.stockinfoid(+)
                                          and a.stockinfoid in (:2,:3))asset,
                                      (select a.borroweraccountid accountid,a.stockinfoid, a.debitamt debtBal,nvl(endbal,0)beginDebitbal
                                         from '||v_cur_stockinfo.tabledebitasset||' a,
                                      (select accountid,stockinfoid, endbal from monitorbalance where acctassettype = 3 and businessdate = :4 )b
                                        where a.borroweraccountid=b.accountid(+) and a.stockinfoid = b.stockinfoid(+)
                                          and a.stockinfoid in (:5,:6)  and a.relatedstockinfoid =:7 )debet,
                                      (select accountid,stockinfoid,sum(curbal) curbal,sum(curfrozenbal) curfrozenbal ,sum(curDebt) curDebt
                                         from (select accountid,stockinfoid,sum((b.occuramt - b.fee) * decode(b.occurdirect,''increase'',1,''decrease'',-1,''unfrozenDecrease'',-1)) curbal,
                                                      sum((b.occurforzenamt) * decode(b.occurdirect,''frozen'',1,''unfrozen'',-1,''unfrozenDecrease'',-1,0)) curfrozenbal,0 curDebt
                                                 from '||v_cur_stockinfo.tablefundcurrent||' b
                                                where accountassettype = ''spotAccountAsset'' group by accountid, stockinfoid
                                                union all
                                               select b.accountid,b.stockinfoid,0 curbal,0 curfrozenbal,sum((b.occuramt)*decode(b.occurdirect,''increase'',1,''decrease'',-1,''unfrozenDecrease'',-1,0)) curDebt
                                                 from '||v_cur_stockinfo.tablefundcurrent||' b
                                                where accountassettype=''spotAccountDebit'' group by b.accountid,b.stockinfoid )group by accountid,stockinfoid) cur
                                where asset.accountid = debet.accountid(+)
                                  and asset.stockinfoid = debet.stockinfoid(+)
                                  and asset.accountid = cur.accountid(+)
                                  and asset.stockinfoid = cur.stockinfoid(+)';

      -- 循环账户-币对
    v_vc_ycbz := 'N';
      return_code := -1;
      return_str := '[PKG_MONITOR.sp_monitorSpotAcctAsset] open cur_monitor for v_sql_query 现货账户资金执行监控查询异常！';
      open cur_monitor for v_sql_query
      using  v_t_startDate,v_cur_stockinfo.tradestockinfoid,v_cur_stockinfo.capitalstockinfoid,
             v_t_startDate,v_cur_stockinfo.tradestockinfoid,v_cur_stockinfo.capitalstockinfoid,v_cur_stockinfo.capitalstockinfoid;
      loop
      fetch cur_monitor into v_cur_monitor;
      exit when cur_monitor%notFound;
           v_debitDesc:='';
           v_assetDesc:='';
           v_monitorDesc:='';
           v_differencedebetbal :=v_cur_monitor.debetbal - v_cur_monitor.curdebetbal;
           v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;
           v_differencefrozenbal :=v_cur_monitor.assetfrozenbal - v_cur_monitor.curfrozenbal;
           -- ID 生成策略，时间戳+业务+序号
           v_l_id := 1500000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;
           v_l_bizcategoryid := v_cur_stockinfo.capitalstockinfoid;
           v_l_relatedstockinfoid := v_cur_stockinfo.id;
           if v_cur_stockinfo.tradestockinfoid =v_cur_monitor.stockinfoid then
               v_vc_Monitorsubtype :='TARGET';
           else
              v_vc_Monitorsubtype :='CAPITAL';
           end if;

           if v_differencedebetbal = 0 and  v_differenceassetbal = 0 and v_differencefrozenbal = 0 then
              monitor_result := 1;
           else
              monitor_result := -1;
              v_monitorDesc :='[现货钱包账户:'||v_cur_monitor.accountid||'品种代码:'||v_l_relatedstockinfoid||'，货币代码:'||v_cur_monitor.stockinfoid||'] 资金流水对不上,资产差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999')||'，冻结余额差额:'||to_char(v_differencefrozenbal,'fm999999999990.099999999999')||'，负债差额:'||to_char(v_differencedebetbal,'fm999999999990.099999999999');
           end  if;

           if monitor_result < 1 then
          v_vc_ycbz := 'N';
              return_code := -1;
              return_str := '[PKG_MONITOR.sp_monitorSpotAcctAsset] insert into MonitorLogs  现货账户资金监控异常，插入监控日志异常！';
              insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                               values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_l_bizCategoryId,v_l_relatedstockinfoid);

           end if;

       v_vc_ycbz := 'N';
           return_code := -1;
           return_str := '[PKG_MONITOR.sp_monitorSpotAcctAsset]  merge into  现货账户资金监控异常，更新异常！';
           merge into MonitorAcctFundCur a
           using (select v_cur_monitor.accountid accountid, v_l_bizcategoryid bizcategoryid,v_cur_monitor.stockinfoid stockinfoid,v_l_relatedstockinfoid relatedstockinfoid,2 acctassettype from dual) b
              on (a.accountid = b.accountid and a.bizcategoryID = b.bizcategoryid and a.stockinfoid = b.stockinfoid and a.relatedstockinfoid = b.relatedstockinfoid and a.acctassettype = b.acctassettype)
           when matched then
                 update set assetbal = v_cur_monitor.assetbal,
                            assetfrozenbal = v_cur_monitor.assetfrozenbal,
                            debetbal = v_cur_monitor.debetbal,
                            curassetbal = v_cur_monitor.curassetbal,
                            curfrozenbal = v_cur_monitor.curfrozenbal,
                            curdebetbal = v_cur_monitor.curdebetbal,
                            differencedebetbal = v_differencedebetbal,
                            differenceassetbal = v_differenceassetbal,
                            differencefrozenbal = v_differencefrozenbal,
                            monitordesc = v_monitorDesc,
                            chkresult = monitor_result,
                            chkdate = v_cur_monitor.chkdate
           when not matched then
                 insert (id,monitorType,monitorSubType,accountId,acctassettype,bizcategoryid,relatedstockinfoid,stockinfoid,
                         assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                         differencedebetbal,differenceassetbal,differencefrozenbal,
                         monitordesc,chkresult,bizDate,chkdate)
                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,2,v_l_bizCategoryId,v_l_relatedstockinfoid,v_cur_monitor.stockinfoid,
                         v_cur_monitor.assetbal,v_cur_monitor.assetfrozenbal,v_cur_monitor.debetbal,v_cur_monitor.curassetbal,v_cur_monitor.curfrozenbal,v_cur_monitor.curdebetbal,
                         v_differencedebetbal,v_differenceassetbal,v_differencefrozenbal,
                         v_monitorDesc,monitor_result,v_t_bizDate,v_cur_monitor.chkdate);

      end loop;
      close cur_monitor;
    end loop;
    close cur_stockinfo;
    commit;

    return_code :=1;
    return_str := '现货账户资金监控成功';
    exception when others then
      --系统自动异常捕捉
      if v_vc_ycbz = 'N' then
         return_code:=-1;
         return_str := return_str||chr(13)||sqlerrm;
      end if;
      --人为考虑系统异常
      if v_vc_ycbz = 'Y' then
         return_str := return_str;
      end if;
      --人为的制造了异常
      if v_vc_ycbz = 'H' then
         return_str := return_str;
      end if;
      rollback;
      sp_monitorRunLogs(v_vc_MonitorType,return_str);
  end sp_monitorSpotAcctAsset;

  procedure sp_monitorSpotWealthAcctAsset(return_code out int,monitor_result out int,return_str out varchar2)
  is
     v_vc_ycbz                         varchar2(1);
     v_vc_MonitorType                  varchar2(32);
     v_vc_Monitorsubtype               varchar2(32);
     v_vc_Monitorname                  varchar2(200);
     v_vc_TargetTable                  varchar2(32);
     cur_monitor                       resultcur;
     v_cur_monitor                     MonitorAcctFundCur%rowtype;
     v_sql_assetMonitor                varchar2(3000);
     v_sql_debitMonitor                varchar2(3000);

     v_l_id                            number(20);
     v_l_bizCategoryId                 number(20);
     v_l_relatedstockinfoid            number(20);
     v_l_datasource                    number(1);
     v_t_initQueryTime                 timestamp;
     v_t_bizDate                       timestamp;
     v_t_startDate                     timestamp;
     v_MonitorDesc                     varchar2(500);
     v_differenceassetbal              number(24, 12);
  begin
      v_vc_MonitorType := 'ACCTFUNDCUR';
      v_vc_Monitorsubtype :='ACCT';
      v_vc_Monitorname := '理财账户资产监控';
      v_vc_TargetTable := 'MonitorAcctFundCur';
      v_t_initQueryTime := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
      v_t_bizDate :=to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
      --=======================================
      -- 增量监控，取上一个结算结束日期作为本次监控起始日期
      --=======================================
      select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 4 ;
      v_l_datasource :=1;
      v_sql_assetMonitor := 'select rownum id,'''' monitorType,'''' monitorSubType,asset.accountid,3 acctassettype,asset.stockinfoid bizcategoryID,asset.stockinfoid,asset.stockinfoid relatedstockinfoid,asset.amount assetbal,asset.frozenamt assetfrozenbal,0 debetBal,
                                    nvl(cur.curbal,0)+nvl(asset.beginbal,0) curAssetBal ,nvl(cur.curfrozenbal,0)+nvl(asset.beginfrozenbal,0) curfrozenbal ,0 curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                                    '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                               from (select a.wealthaccountid accountid,a.stockinfoid,a.wealthamt amount,0 frozenamt,nvl(b.endbal,0) beginbal,nvl(b.endfrozenbal,0) beginfrozenbal
                                       from accountwealthasset a,
                                            (select accountid,stockinfoid,endbal,endfrozenbal from monitorbalance where acctassettype = 4 and businessdate=:1)b
                                              where a.wealthaccountid = b.accountid(+)
                                                and a.stockinfoid = b.stockinfoid(+))asset,
                                            (select accountid,stockinfoid,sum(occuramt * decode(occurdirect,''increase'',1,-1))curbal,0 curfrozenbal
                                               from accountWealthCurrent
                                              where accountassettype=''wealthAccountAsset''
                                                and currentdate >:2
                                              group by accountid,stockinfoid)cur
                                       where asset.accountid = cur.accountid(+)
                                         and asset.stockinfoid = cur.stockinfoid(+)';
      v_vc_ycbz := 'N';
      return_code := -1;
      return_str := '[PKG_MONITOR.sp_monitorSpotWealthAcctAsset] 理财账户资产监控异常';
      open cur_monitor for v_sql_assetMonitor
      using  v_t_startDate,v_t_startDate;
      loop
      fetch cur_monitor into v_cur_monitor;
      exit when cur_monitor%notFound;
         v_l_bizCategoryId := v_cur_monitor.stockinfoid;
         v_l_relatedstockinfoid := v_cur_monitor.stockinfoid;
         v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;
         if v_differenceassetbal = 0  then
             monitor_result := 1;
         else
             monitor_result := -1;
             v_monitorDesc :='[账户:'||v_cur_monitor.accountid||'理财资产的数字货币:'||v_cur_monitor.stockinfoid||'] 资产与资金流水对不上,资产差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999');
         end  if;

         v_l_id := 1600000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;

         if monitor_result < 1 then
                insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
         end if;
         merge into MonitorAcctFundCur a
         using (select v_cur_monitor.accountid accountid,v_cur_monitor.stockinfoid stockinfoid,v_cur_monitor.acctassettype  acctassettype from dual) b
            on (a.accountid = b.accountid and a.stockinfoid = b.stockinfoid and a.acctassettype = b.acctassettype)
         when matched then
               update set assetbal = v_cur_monitor.assetbal,
                          curassetbal = v_cur_monitor.curassetbal,
                          differenceassetbal = v_differenceassetbal,
                          monitordesc = v_monitorDesc,
                          chkresult = monitor_result,
                          chkdate = v_cur_monitor.chkdate
         when not matched then
               insert (id,monitorType,monitorSubType,accountId,acctassettype,bizcategoryid,relatedstockinfoid,stockinfoid,
                       assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                       differencedebetbal,differenceassetbal,differencefrozenbal,
                       monitordesc,chkresult,bizDate,chkdate)
               values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,v_cur_monitor.acctassettype,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,
                       v_cur_monitor.assetbal,0,0,v_cur_monitor.curassetbal,0,0,
                       0,v_differenceassetbal,0,
                       v_monitorDesc,monitor_result,v_t_bizDate,v_cur_monitor.chkdate);
      end loop;
      close cur_monitor;

     v_sql_debitMonitor := 'select rownum id,'''' monitorType,'''' monitorSubType,debit.accountid,3 acctassettype,debit.stockinfoid bizcategoryID,debit.stockinfoid,debit.stockinfoid relatedstockinfoid,debit.amount assetbal,debit.frozenamt assetfrozenbal,0 debetBal,
                                   nvl(cur.curbal,0)+nvl(debit.beginbal,0) curAssetBal ,nvl(cur.curfrozenbal,0)+nvl(debit.beginfrozenbal,0) curfrozenbal ,0 curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                                   '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                              from (select a.wealthaccountid accountid,a.stockinfoid,a.debitamt amount,0 frozenamt,nvl(b.endbal,0) beginbal,nvl(b.endfrozenbal,0) beginfrozenbal
                                      from accountwealthdebitasset a,
                                           (select accountid,stockinfoid,endbal,endfrozenbal from monitorbalance where acctassettype = 5 and businessdate=:1)b
                                             where a.wealthaccountid = b.accountid(+)
                                               and a.stockinfoid = b.stockinfoid(+))debit,
                                           (select accountid,stockinfoid,sum(nvl(occuramt,0) * decode(occurdirect,''increase'',1,-1))curbal,0 curfrozenbal
                                              from accountWealthCurrent
                                             where accountassettype=''wealthAccountDebit''
                                               and currentdate >:2
                                             group by accountid,stockinfoid)cur
                                      where debit.accountid = cur.accountid(+)
                                        and debit.stockinfoid = cur.stockinfoid(+)';
        v_vc_ycbz := 'N';
        return_code := -1;
        return_str := '[PKG_MONITOR.sp_monitorSpotWealthAcctAsset] 理财账户应付利息监控异常';
        open cur_monitor for v_sql_debitMonitor
        using  v_t_startDate,v_t_startDate;
        loop
        fetch cur_monitor into v_cur_monitor;
        exit when cur_monitor%notFound;
           v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;
           if v_differenceassetbal = 0  then
               monitor_result := 1;
           else
               monitor_result := -1;
               v_monitorDesc :='[理财资产账户:'||v_cur_monitor.accountid||' 数字货币为'||v_cur_monitor.stockinfoid||'] 应付利息与资金流水对不上,差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999');
           end  if;

           v_l_id := 1700000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;
           if monitor_result < 1 then
              insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                               values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
           end if;
           merge into MonitorAcctFundCur a
           using (select v_cur_monitor.accountid accountid,v_cur_monitor.stockinfoid stockinfoid,v_cur_monitor.acctassettype  acctassettype from dual) b
              on (a.accountid = b.accountid and a.stockinfoid = b.stockinfoid and a.acctassettype = b.acctassettype)
           when matched then
                 update set assetbal = v_cur_monitor.assetbal,
                            curassetbal = v_cur_monitor.curassetbal,
                            differenceassetbal = v_differenceassetbal,
                            monitordesc = v_monitorDesc,
                            chkresult = monitor_result,
                            chkdate = v_cur_monitor.chkdate
           when not matched then
                 insert (id,monitorType,monitorSubType,accountId,acctassettype,bizcategoryid,relatedstockinfoid,stockinfoid,
                         assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                         differencedebetbal,differenceassetbal,differencefrozenbal,
                         monitordesc,chkresult,bizDate,chkdate)
                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,v_cur_monitor.acctassettype,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,
                         v_cur_monitor.assetbal,0,0,v_cur_monitor.curassetbal,0,0,
                         0,v_differenceassetbal,0,
                         v_monitorDesc,monitor_result,v_t_bizDate,v_cur_monitor.chkdate);
    end loop;
    close cur_monitor;
    commit;

    return_code :=1;
    return_str := '理财账户资产监控成功';
    exception when others then
        --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := '[PKG_MONITOR.sp_monitorSpotWealthAcctAsset]报异常错误:'||chr(13)||sqlerrm;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
        rollback;
        sp_monitorRunLogs(v_vc_MonitorType,return_str);
  end sp_monitorSpotWealthAcctAsset;

  /**********************************************************
    名  称： 账户级别资金流水监控
    功  能： 监控平台账户级别资金流水是否对平
    入  参： bizids                业务品种ID
    出  参：return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
               monitor_result   监控结果   (1.对账平衡; -1.对账不平)
               monitor_data     详细的监控结果
               return_str       返回信息
    创建者：jiangsc
    描  述：

    日  期：2017-11-20
   ***********************************************************/
   procedure sp_monitorAccountFundCur(bizids in varchar2,monitor_idx out int,return_code out int,monitor_result out int,monitor_data out resultcur,return_str out varchar2)
   is
     v_vc_ycbz                           varchar2(1);
     v_l_count                           number(8);
   begin
     v_vc_ycbz := 'N';
     monitor_result := 1;
     return_code:=-1;
     return_str :='账户级别资金流水监控异常';
     
     monitor_idx := 0;
     
     select count(1)into v_l_count from monitorconfig where  monitorcode='ACCTFUNDCUR' and active = 1 and idxid1>0;
     if v_l_count > 0 then
        select idxid1 into monitor_idx from monitorconfig where  monitorcode='ACCTFUNDCUR' and active = 1 and idxid1>0;
     else
        v_vc_ycbz := 'H';
        return_code:=-1;
        return_str :='账户级别资金流水监控服务未配置或者监控指标未配置';
        raise_application_error(v_vc_ycbz, return_str);
     end if;
     
     -- 钱包资产账户监控
     sp_monitorWalletAcctAsset(return_code,monitor_result,return_str);
     -- 理财账户监控
     if (return_code > 0 ) then
        sp_monitorSpotWealthAcctAsset(return_code,monitor_result,return_str);
     end if;
     -- 现货资产监控
      if (return_code > 0 ) then
          sp_monitorSpotAcctAsset(bizids,return_code,monitor_result,return_str );
      end if;

      sp_monitorCurOneByOne(return_code,monitor_result,return_str);

       if return_code < 0 then
          raise_application_error(v_vc_ycbz, return_str);
       end if;

      select count(1) into v_l_count
        from  monitoracctfundcur
      where  chkResult in (-1,-2) ;

     if v_l_count > 0 then
       monitor_result := -1;
     else
       monitor_result :=1;
     end if;

     open monitor_data for
       select
          case
             when a.acctassettype = 1 then
                 '<strong>【账户:'||acct.accountname||' 钱包资产：'||stk.stockname||'】</strong>'||substrb(a.monitordesc,instrb(a.monitordesc,']')+1)
             when a.acctassettype = 2 then
                  '<strong>【账户:'||acct.accountname||' 杠杆现货资产：'||stk.stockname||'】</strong>'||substrb(a.monitordesc,instrb(a.monitordesc,']')+1)
             when a.acctassettype = 3 then
                  '<strong>【账户:'||acct.accountname||' 理财资产：'||stk.stockname||'】</strong>'||substrb(a.monitordesc,instrb(a.monitordesc,']')+1)
          end monitordesc,
           a.chkresult
  from MonitorAcctFundCur a,account acct,stockinfo stk
 where a.accountid = acct.id
    and a.stockinfoid = stk.id
    and a.chkResult< 0 ;

   return_code :=1;
     return_str := '账户资金监控成功';
   exception when others then
       --系统自动异常捕捉
      if v_vc_ycbz = 'N' then
        return_code:=-1;
        return_str := '[PKG_MONITOR.sp_monitorAccountFundCur]报异常错误:'||chr(13)||sqlerrm;
      end if;
      --人为考虑系统异常
      if v_vc_ycbz = 'Y' then
        return_str := return_str;
      end if;
      --人为的制造了异常
      if v_vc_ycbz = 'H' then
        return_str := return_str;
      end if;
      rollback;
   end sp_monitorAccountFundCur;

  /**********************************************************
    名  称： 资金逐笔流水监控
    功  能： 监控平台账户级别资金流水是否对平
    出  参：return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
            monitor_result   监控结果   (1.对账平衡; -1.对账不平)
            return_str       返回信息
     创建者：jiangsc
    描  述：

     日  期：2017-11-20
    ***********************************************************/
  procedure sp_monitorCurOneByOne(return_code out int,monitor_result out int,return_str out varchar2)
  is
     v_vc_ycbz                         varchar2(1);                  --异常标志

     v_vc_MonitorType                  varchar2(32);
     v_vc_Monitorsubtype               varchar2(32);
     v_vc_Monitorname                  varchar2(200);
     v_vc_TargetTable                  varchar2(32);
     v_t_createDate                    timestamp;
     v_l_datasource                    number(1);

  begin
     v_t_createDate := systimestamp; -- 监控时间
     v_l_datasource := 1;  -- 监控类型
     v_vc_MonitorType := 'ACCTFUNDCUR';
     v_vc_Monitorsubtype :='ACCT';
     v_vc_Monitorname := '资金逐笔监控';
     v_vc_TargetTable := 'MonitorAcctFundCur';
     monitor_result :=1;

     v_vc_ycbz := 'N';
     return_code := -1;
     return_str := '[PKG_MONITOR.sp_monitorCurOneByOne] 资金逐笔监控异常！';

     --===========================
     -- 插入数据前，先清空表数据
     --===========================
     EXECUTE IMMEDIATE 'truncate table MonitorCurOneByOne';
     --===========================
     -- 插入比对不上的资金流水
     --===========================
     insert into MonitorCurOneByOne(ID,accountId,acctassettype,acctassetsubtype,stockinfoId,relatedstockinfoid,bizcategoryID,originalbusinessid,relatedbusinessid,businessflag,businessdate,querydate)
     select id,accountid,acctassettype,acctassetsubtype,stockinfoId,relatedstockinfoid,bizcategoryid,originalbusinessid,relatedbusinessid,businessflag,currentdate,bizdate
       from (select 10000000+rownum id,1 acctassettype,decode(a.accountassettype,'walletAccountAsset',1,2)acctassetsubtype,a.id relatedbusinessid,a.accountid,a.stockinfoId,a.originalbusinessid,a.businessflag,a.currentdate,a.orgamt,lag(a.lastamt) over(partition by a.accountid,a.stockinfoid order by a.currentdate)  prev_amt,
                    forzenorgamt , lag(a.forzenlastamt) over(partition by a.accountid,a.stockinfoid,a.accountassettype order by a.currentdate)  prev_forzenamt,b.bizcategoryid,b.relatedstockinfoid,b.bizdate
               from AccountFundCurrent a,monitoracctfundcur b
              where a.accountid=b.accountid
                and a.stockinfoid=b.stockinfoid
                and b.acctassettype =1
                and a.accountid <>199999999999
                and currentdate between b.bizdate and v_t_createDate
              union all
             select 20000000+rownum id,2 acctassettype,decode(a.accountassettype,'spotAccountAsset',1,2)acctassetsubtype,a.id relatedbusinessid,a.accountid,a.stockinfoId,a.originalbusinessid,a.businessflag,a.currentdate,a.orgamt,lag(a.lastamt) over(partition by a.accountid,a.stockinfoid,a.accountassettype order by a.currentdate)  prev_amt,
                    forzenorgamt , lag(a.forzenlastamt) over(partition by a.accountid,a.stockinfoid,a.accountassettype order by a.currentdate)  prev_forzenamt,b.bizcategoryid,b.relatedstockinfoid,b.bizdate
               from Accountfundcurrentspot a,monitoracctfundcur b
             where a.accountid=b.accountid
                and a.stockinfoid=b.stockinfoid
                and b.acctassettype =2
                and a.accountid <>199999999999
                and currentdate between b.bizdate and v_t_createDate
              union all
             select 30000000+rownum id,3 acctassettype,decode(a.accountassettype,'wealthAccountAsset',1,2)acctassetsubtype,a.id relatedbusinessid,a.accountid,a.stockinfoId,a.originalbusinessid,a.businessflag,a.currentdate,a.orgamt,lag(a.lastamt) over(partition by a.accountid,a.stockinfoid,a.accountassettype order by a.currentdate)  prev_amt,
                    forzenorgamt , lag(a.forzenlastamt) over(partition by a.accountid,a.stockinfoid,a.accountassettype order by a.currentdate)  prev_forzenamt,b.bizcategoryid,b.relatedstockinfoid,b.bizdate
               from accountWealthCurrent a,monitoracctfundcur b
             where a.accountid=b.accountid
               and a.stockinfoid=b.stockinfoid
               and currentdate between b.bizdate and v_t_createDate
               and b.acctassettype =3)
     where orgamt <>  prev_amt or   forzenorgamt <>  prev_forzenamt;
     commit;

     insert into MonitorDetail(id,accountId,stockinfoId,bizcategoryID,relatedstockinfoid,originalbusinessid,relatedbusinessid,businessflag,
                               businessdate,monitordesc,monitorDate,datasource)
     select 1800000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+rownum id,
            a.accountid,a.stockinfoId, a.bizcategoryid,a.relatedstockinfoid,a.originalbusinessid,
            a.relatedbusinessid,a.businessflag,a.businessdate,
            case
               when a.acctassettype = 1 and a.acctassetsubtype = 1 then
                 '[钱包账户:'||a.accountid||'  数字货币:'||a.stockinfoid||'] 在期间:'||to_char(a.querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上'
               when a.acctassettype = 2 and a.acctassetsubtype = 1 then
                   '[现货账户:'||a.accountid||' 数字货币:'||a.stockinfoid||'] 在期间:'||to_char(a.querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上'
               when a.acctassettype = 2 and a.acctassetsubtype = 2 then
                    '[现货账户:'||a.accountid||' 数字货币:'||a.stockinfoid||'] 在期间:'||to_char(a.querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 负债流水逐笔对不上'
               when a.acctassettype = 3 and a.acctassetsubtype = 1 then
                    '[理财账户:'||a.accountid||' 数字货币:'||a.stockinfoid||'] 在期间:'||to_char(a.querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上'
               when a.acctassettype = 3 and a.acctassetsubtype = 2 then
                     '[理财账户:'||a.accountid||' 数字货币:'||a.stockinfoid||'] 在期间:'||to_char(a.querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 负债流水逐笔对不上'
               else
                    '对不上，无理由，任性'
            end monitordesc,
            v_t_createDate,v_l_datasource
     from MonitorCurOneByOne a;

     insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                      select 1900000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+rownum id,
                             v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,-2,v_t_createDate,v_vc_TargetTable,
                             case
                                 when acctassettype = 1 and acctassetsubtype = 1 then
                                   '[钱包账户:'||accountid||'] 数字货币:'||stockinfoid||',在期间:'||to_char(querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上'
                                 when acctassettype = 2 and acctassetsubtype = 1 then
                                   '[现货账户:'||accountid||'] 数字货币:'||stockinfoid||',在期间:'||to_char(querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上'
                                 when acctassettype = 2 and acctassetsubtype = 2 then
                                  '[现货账户:'||accountid||'] 数字货币:'||stockinfoid||',在期间:'||to_char(querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 负债流水逐笔对不上'
                                 when acctassettype = 3 and acctassetsubtype = 1 then
                                  '[理财账户:'||accountid||'] 数字货币:'||stockinfoid||',在期间:'||to_char(querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上'
                                 when acctassettype = 3 and acctassetsubtype = 2 then
                                   '[理财账户:'||accountid||'] 数字货币:'||stockinfoid||',在期间:'||to_char(querydate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 负债流水逐笔对不上'
                                 else
                                   '对不上，无理由，任性'
                             end monitorlogdesc,
                             relatedstockinfoid,bizcategoryid,v_l_datasource
                      from (select a.accountid,a.acctassettype,a.acctassetsubtype,a.stockinfoid,a.relatedstockinfoid,a.bizcategoryid,querydate
                              from MonitorCurOneByOne a
                             group by a.accountid,a.acctassettype,a.acctassetsubtype,a.stockinfoid,a.relatedstockinfoid,a.bizcategoryid,a.querydate)b;

     --===============================
     -- 更新流水比对不上的
     --===============================
     update MonitorAcctFundCur a
        set (a.chkdate,a.chkresult,a.monitordesc) = (select v_t_createDate,-2,
                                                            case when acctassettype = 1 then
                                                                  '[钱包账户:'||a.accountid||'] 数字货币:'||a.stockinfoid||',在期间:'||to_char(a.bizdate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 流水逐笔对不上'||';'||a.monitordesc
                                                                 when acctassettype = 2 then
                                                                  '[现货账户:'||a.accountid||'] 数字货币:'||a.stockinfoid||',在期间:'||to_char(a.bizdate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 流水逐笔对不上'||';'||a.monitordesc
                                                                 when acctassettype = 3  then
                                                                  '[理财账户:'||a.accountid||'] 数字货币:'||a.stockinfoid||',在期间:'||to_char(a.bizdate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 流水逐笔对不上'||';'||a.monitordesc
                                                                 else
                                                                  '对不上，无理由，任性'||';'||a.monitordesc
                                                            end monitorlogdesc
                                                       from (select accountid,stockinfoid,acctassettype
                                                               from MonitorCurOneByOne
                                                              group by accountid, stockinfoid, acctassettype) c
                                                       where a.accountid= c.accountid
                                                         and a.stockinfoid = c.stockinfoid
                                                         and a.acctassettype = c.acctassettype)
     where exists(select 1 from MonitorCurOneByOne b where a.accountid= b.accountid and a.stockinfoid = b.stockinfoid and a.acctassettype = b.acctassettype);


     --===============================
     -- 更新流水对的上的监控记录，并更新bizdate,做为下次增量监控
     --===============================
     update MonitorAcctFundCur a
        set a.bizdate = v_t_createDate,
            a.chkdate = v_t_createDate
     where a.chkresult =1;
     commit;

     return_code :=1;
     return_str := '资金逐笔监控成功';
     exception when others then
      --系统自动异常捕捉
      if v_vc_ycbz = 'N' then
      return_code:=-1;
      return_str := '[PKG_MONITOR.sp_monitorCurOneByOne]报异常错误:'||chr(13)||sqlerrm;
      end if;
      --人为考虑系统异常
      if v_vc_ycbz = 'Y' then
          return_str := return_str;
      end if;
      --人为的制造了异常
      if v_vc_ycbz = 'H' then
      return_str := return_str;
      end if;
      rollback;
      sp_monitorRunLogs(v_vc_MonitorType,return_str);
  end sp_monitorCurOneByOne;

   --数字资产内外部总额监控
  procedure sp_monitorDigitalCoinBal(digitalCoin in varchar2,
                                     externalRBal in varchar2,
                                     externalWBal in varchar2,
                                     monitor_idx out int,
                                     return_code out int,
                                     monitor_result out int,
                                     monitor_data out resultcur,
                                     return_str out varchar2)
   is
    v_l_count                         number(8);
    v_vc_ycbz                         varchar2(1);                  --异常标志
    v_vc_MonitorType                  varchar2(32);
    v_vc_Monitorsubtype               varchar2(32);
    v_vc_Monitorname                  varchar2(200);
    v_vc_TargetTable                  varchar2(32);
    v_t_createDate                    timestamp;

    v_l_id                            number(20);
    v_l_Stockinfoid                   number(20);
    v_d_ExternalRBal                  number(20,8);
    v_d_ExternalWBal                  number(20,8);
    v_d_ExternalEBal                  number(20,8);
    v_d_Internalbal                   number(24,12);
    v_d_differenceBal                 number(24,12);
    
    v_vc_monitordesc                  varchar2(500);
		v_vc_logdesc                      varchar2(1500);
		v_l_idxlevel                      number(1);
    v_vc_stockname                    varchar2(50);
  begin
    v_vc_MonitorType := 'MONITORDIGITALCOIN';
    v_vc_Monitorsubtype :='DIGITALCOIN';
    v_vc_Monitorname := '数字资产内外部总额监控';
    v_vc_TargetTable := 'MonitorPlatBal';
    v_t_createDate := systimestamp;
    monitor_result := 1;
    v_vc_monitordesc :='';
    monitor_idx := 0;
    v_l_idxlevel := 0;
    v_vc_stockname := digitalCoin;
    --===================================
    -- 外部入参转化
    --===================================
     v_l_stockinfoid := to_number(digitalCoin);
     v_d_externalRBal := to_number(externalRBal)/100000000;
     v_d_externalWBal := to_number(externalWBal)/100000000;

     --===================================
     -- 获取外部存管钱包余额
     -- 注意： 这里的变动后余额为刨除费用后的余额
     --===================================
     v_d_ExternalEBal :=0;
     v_l_count :=0;
     select count(1) into v_l_count from  WalletTransferCurrent a where a.stockinfoid = v_l_stockinfoid;
     if v_l_count > 0 then
      select a.lastamt into v_d_ExternalEBal
        from  WalletTransferCurrent a
       where id = (select max(id) from WalletTransferCurrent  where a.stockinfoid = v_l_stockinfoid );
     end if;
 
     --===================================
     -- 获取系统内部数字资产总额 = 资产 - 负债 + 提现未划拨余额
     -- 提现未划拨余额 = 提现申请未划拨总额 - 网络费用
     -- 说明：
     --   划拨费用已统计在超级账户,
     --   提现时，发起未划付就从资产扣除所以需要加回来
     --===================================
     select nvl(sum(curamt),0) into v_d_Internalbal
    from (select (amount) curamt from accountSpotAsset  where  stockinfoid = v_l_stockinfoid
         union all
        select (amount+withdrawingtotal) curamt from accountwalletasset  where  stockinfoid = v_l_stockinfoid
         union all
        select (-debitamt) curamt from accountDebitAsset where stockinfoid = v_l_stockinfoid);
    
		select count(1) into v_l_count from stockinfo a where a.id = v_l_stockinfoid;
    if v_l_count > 0 then
       select a.stockname into v_vc_stockname from stockinfo a where a.id = v_l_stockinfoid;
    end if;
    
    v_vc_ycbz := 'N';
    return_str := '[PKG_MONITOR.sp_monitorDigitalCoinBal]数字资产内外部总额核对异常';
		for monitor_cur in (select rownum id,nvl(c.maxvalue,0) maxvalue,nvl(c.minvalue,0) minvalue,nvl(c.compdirect,1) compdirect,b.idxlevel,b.idxname,a.idxid
																		from (select idxid1 idxid from monitorconfig where  monitorcode='DIGITALCOIN' and active = 1 and idxid1>0
																							union all
																							select idxid2 idxid from monitorconfig where  monitorcode='DIGITALCOIN' and active = 1 and idxid2>0
																							union all
																							select idxid3 idxid from monitorconfig where  monitorcode='DIGITALCOIN' and active = 1 and idxid3>0
																							union all
																							select idxid4 idxid from monitorconfig where  monitorcode='DIGITALCOIN' and active = 1 and idxid4>0)a,
																							Monitorindex b,
																							(select * from monitorlimitparam  where  stockinfoid=v_l_stockinfoid) c
																		where a.idxid =b.id
																			 and  b.id = c.relatedid(+)
																		order by b.idxlevel desc ) loop
                
               if  monitor_cur.compdirect = 4 then      -- 内部-外部
                   v_d_differenceBal := v_d_Internalbal - (v_d_externalRBal + v_d_externalWBal + v_d_ExternalEBal) ;
                elsif monitor_cur.compdirect = 5 then  -- 外部-内部
                   v_d_differenceBal := (v_d_externalRBal + v_d_externalWBal + v_d_ExternalEBal) - v_d_Internalbal ;
               else  -- 其他处理成绝对值
                  v_d_differenceBal := abs(v_d_externalRBal + v_d_externalWBal + v_d_ExternalEBal - v_d_Internalbal);
              end if;
              
              v_vc_logdesc :='';
              if (v_d_differenceBal <>0 and v_d_differenceBal <monitor_cur.minvalue) or (v_d_differenceBal <>0 and v_d_differenceBal >monitor_cur.maxvalue) then
                  
                  -- 预警处理根据指标优先级来处理，同时触发普通级别和最高级别，则以最高级别预警方式处理，暂时不支持按币种区分优先级
                  if v_l_idxlevel = 0 then
                     v_l_idxlevel := monitor_cur.idxlevel; 
                     monitor_idx := monitor_cur.idxid;
                  elsif v_l_idxlevel < monitor_cur.idxlevel then
                     v_l_idxlevel := monitor_cur.idxlevel;
                     monitor_idx :=monitor_cur.idxid;
                  end if; 
                  
                  monitor_result := -1; 
                  v_vc_logdesc :='触发【监控：内外部总账监控，指标：'||monitor_cur.idxname||'，阈值['||monitor_cur.minvalue||'~'||monitor_cur.maxvalue||']】预警！['||v_vc_stockname||'差额为'||to_char(v_d_differenceBal,'fm999999999990.099999999999')||']提现钱包余额为'||to_char(v_d_externalWBal,'fm999999999990.099999999999')||'，充值钱包余额为'||to_char(v_d_externalRBal,'fm999999999990.099999999999')||'，冷储备钱包余额为'||to_char(v_d_ExternalEBal,'fm999999999990.099999999999')||',内部钱包余额为'||to_char(v_d_Internalbal,'fm999999999990.099999999999');
                  v_l_id := 2000000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+monitor_cur.id;
                  insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_vc_logdesc,0,0);
              end if;
              
              if length(v_vc_logdesc) > 0 then
                 v_vc_monitordesc := v_vc_monitordesc||v_vc_logdesc||'<br />';
              else
                 v_vc_monitordesc :=v_vc_logdesc;
              end if;
               
        end loop;

      merge into MonitorPlatBal a
        using (select v_l_stockinfoid stockinfoid from dual) b
           on (a.stockinfoid = b.stockinfoid)
        when matched then
              update set  ExternalRBal = v_d_externalRBal,
                          ExternalWBal = v_d_externalWBal,
                          ExternalEBal = v_d_ExternalEBal,
                          InternalBal = v_d_InternalBal, 
                          monitordesc = v_vc_monitordesc,
                          chkresult = monitor_result,
                          chkdate = v_t_createDate
        when not matched then
              insert (monitorType,monitorSubType,stockinfoid,ExternalRBal,ExternalWBal,ExternalEBal,InternalBal, 
                      monitordesc,chkresult,chkdate)
              values (v_vc_MonitorType,v_vc_Monitorsubtype,v_l_stockinfoid,v_d_externalRBal,v_d_externalWBal,v_d_ExternalEBal,v_d_InternalBal,
                      v_vc_monitordesc,monitor_result,v_t_createDate);
     commit;
     open monitor_data for
     select a.monitordesc,
            a.chkresult
       from MonitorPlatBal a
      where monitorType ='MONITORDIGITALCOIN'
        and a.stockinfoid = v_l_stockinfoid
        and chkResult <0;
    return_code :=1;
    return_str := '数字资产内外部总额监控成功';
    exception when others then
       --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
          return_code:=-1;
          return_str := '[PKG_MONITOR.sp_monitorDigitalCoinBal]报异常错误:'||chr(13)||sqlerrm;
    sp_monitorRunLogs(v_vc_MonitorType,return_str);
    rollback;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
          return_code:=-1;
          return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
          return_str := return_str;
        end if;
    end sp_monitorDigitalCoinBal;

   /**********************************************************
    名  称： 现金货币内外部总额监控
    功  能： 现金货币内外部总额监控

    出  参： return_code         返回代码   (1.核对执行成功; -1.核对执行失败)
                monitor_result      监控结果   (1.对账平衡; -1.对账不平)
                monitor_data        详细的监控结果
                return_str             返回信息
    创建者：jiangsc
    描  述：

    日  期：2017-11-20
  ***********************************************************/
  procedure sp_monitorCashCoinBal(cashCoins in varchar2,
                                  monitor_idx out int,
                                  return_code out int,
                                  monitor_result out int,
                                  monitor_data out resultcur,
                                  return_str out varchar2)
  is
    v_vc_ycbz                         varchar2(1);                  --异常标志
    v_vc_MonitorType            varchar2(32);
    v_vc_Monitorsubtype       varchar2(32);
    v_vc_Monitorname           varchar2(200);
    v_vc_TargetTable              varchar2(32);
    v_t_createDate                  timestamp;
    v_differencebal                  number(24,12);
    v_vc_monitordesc             varchar2(500);
    v_l_id                                number(20);
    v_vc_logdesc                      varchar2(1500);
		v_l_idxlevel                      number(1); 
  begin
   v_vc_MonitorType := 'MONITORCASHCOIN';
   v_vc_Monitorsubtype :='CASHCOIN';
   v_vc_Monitorname := '现金资产内外部总额监控';
   v_vc_TargetTable := 'MonitorPlatBal';
   v_t_createDate := systimestamp;
   monitor_result := 1;
   v_l_idxlevel := 0;
   monitor_idx := 0;

   -- 由于没有外部对接接口，所以欧元的内外部总额核对基于平台级现金总额的核对
     v_vc_ycbz := 'N';
     return_str := '[PKG_MONITOR.sp_chkCashCoinRecharge]现金资产内外部总额核对异常';
     For cur_total in (select rownum id,stockinfoid,stockname,outEurTotal,inEurTotal
                               from (select nvl(a.stockinfoid,b.stockinfoid)stockinfoid,nvl(a.lastamt,0)outEurTotal,nvl(b.curBal,0)inEurTotal
                                          from (select a.lastamt,a.stockinfoId
                                                     from WalletCashTransferCurrent a,
                                                              (select max(id)id from WalletCashTransferCurrent group by stockinfoid)b
                                                    where a.id = b.id
                                                        and a.stockinfoid in (select * from table(sf_strsplit(cashCoins))) )a
                                             full join
                                                   (select stockinfoid,nvl(sum(amount),0)+nvl(sum(withdrawingtotal),0) curBal
                                                     from accountwalletasset a3
                                                   where exists (select 1 from stockinfo where stocktype = 'cashCoin' and canrecharge = 'yes' and canwithdraw = 'yes' and id in (select * from table(sf_strsplit(cashCoins))) and id = a3.stockinfoid)
                                                   group by stockinfoid)b
                                               on a.stockinfoid = b.stockinfoid)a,
                                         (select id,stockname from stockinfo where stocktype = 'cashCoin' and canrecharge = 'yes' and canwithdraw = 'yes' and id in (select * from table(sf_strsplit(cashCoins))))b
                       where a.stockinfoid = b.id)
     Loop
       
        for monitor_cur in (select rownum id,nvl(c.maxvalue,0) maxvalue,nvl(c.minvalue,0) minvalue,nvl(c.compdirect,1) compdirect,b.idxlevel,b.idxname,a.idxid
                              from (select idxid1 idxid from monitorconfig where  monitorcode='CASHCOIN' and active = 1 and idxid1>0
                                            union all
                                            select idxid2 idxid from monitorconfig where  monitorcode='CASHCOIN' and active = 1 and idxid2>0
                                            union all
                                            select idxid3 idxid from monitorconfig where  monitorcode='CASHCOIN' and active = 1 and idxid3>0
                                            union all
                                            select idxid4 idxid from monitorconfig where  monitorcode='CASHCOIN' and active = 1 and idxid4>0)a,
                                            Monitorindex b,
                                            (select * from monitorlimitparam  where  stockinfoid=cur_total.stockinfoid) c
                                     where a.idxid =b.id
                                       and  b.id = c.relatedid(+)
                                     order by b.idxlevel desc) loop
                
               if  monitor_cur.compdirect = 4 then      -- 内部-外部
                   v_differencebal := cur_total.ineurtotal - cur_total.outeurtotal ;
               elsif monitor_cur.compdirect = 5 then  -- 外部-内部
                   v_differencebal := cur_total.outeurtotal-cur_total.ineurtotal ;
               else  -- 其他处理成绝对值
                   v_differencebal := abs(cur_total.outeurtotal-cur_total.ineurtotal);
               end if;
              
              v_vc_logdesc :='';
              if (v_differencebal <>0 and v_differencebal <monitor_cur.minvalue) or (v_differencebal <>0 and v_differencebal >monitor_cur.maxvalue) then
                  
                  -- 预警处理根据指标优先级来处理，同时触发普通级别和最高级别，则以最高级别预警方式处理，暂时不支持按币种区分优先级
                  if v_l_idxlevel = 0 then
                     v_l_idxlevel := monitor_cur.idxlevel; 
                     monitor_idx := monitor_cur.idxid;
                  elsif v_l_idxlevel < monitor_cur.idxlevel then
                     v_l_idxlevel := monitor_cur.idxlevel;
                     monitor_idx :=monitor_cur.idxid;
                  end if; 
                  
                  monitor_result := -1; 
                  v_vc_logdesc :='触发【监控:现金资产内外总额监控,指标:'||monitor_cur.idxname||',阈值['||monitor_cur.minvalue||'~'||monitor_cur.maxvalue||']】预警！['||cur_total.stockname||'差额为'||to_char(v_differencebal,'fm999999999990.099999999999')||'],外部总额：'||to_char(cur_total.outeurtotal,'fm999999999990.099999999999')||',内部总额：'||to_char(cur_total.ineurtotal,'fm999999999990.099999999999');
                  v_l_id := 2000000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+monitor_cur.id;
                  insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_vc_logdesc,0,0);
              end if;
              
              if length(v_vc_logdesc) > 0 then
                 v_vc_monitordesc := v_vc_monitordesc||v_vc_logdesc||'<br />';
              else
                 v_vc_monitordesc :=v_vc_logdesc;
              end if;
               
        end loop;
      

        merge into MonitorPlatBal a
        using (select cur_total.stockinfoid stockinfoid from dual) b
           on (a.stockinfoid = b.stockinfoid)
        when matched then
              update set  ExternalEBal = cur_total.outeurtotal,
                                InternalBal = cur_total.ineurtotal,
                                differenceBal = v_differencebal,
                                monitordesc = v_vc_monitordesc,
                                chkresult = monitor_result,
                                chkdate = v_t_createDate
        when not matched then
              insert (monitorType,monitorSubType,stockinfoid,ExternalEBal,InternalBal,
                        differenceBal,monitordesc,chkresult,chkdate)
              values (v_vc_MonitorType,v_vc_Monitorsubtype,cur_total.stockinfoid,cur_total.outeurtotal,cur_total.ineurtotal,
                         v_differencebal,v_vc_monitordesc,monitor_result,v_t_createDate);
     End Loop;
   commit;
   open monitor_data for
     select a.monitordesc,
            a.chkresult
       from MonitorPlatBal a
      where a.monitortype='MONITORCASHCOIN'
        and chkResult <0;
   return_code :=1;
   return_str := '现金资产内外部总额监控成功';
   exception when others then
       --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
          return_code:=-1;
          return_str := '[PKG_MONITOR.sp_monitorCashCoinBal]报异常错误:'||chr(13)||sqlerrm;
          sp_monitorRunLogs(v_vc_MonitorType,return_str);
          rollback;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
          return_code:=-1;
          return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
          return_str := return_str;
        end if;


  end sp_monitorCashCoinBal;

    /**********************************************************
    名  称： ERC20内外部总额监控
    功  能： ERC20内外部总额监控
    入 参：  digitalCoin
                 externalHBal         热钱包余额
                 externalCBal         冷钱包余额
                 externalFBal          费用余额
    出  参： return_code         返回代码   (1.核对执行成功; -1.核对执行失败)
                monitor_result      监控结果   (1.对账平衡; -1.对账不平)
                monitor_data        详细的监控结果
                return_str             返回信息
    创建者：jiangsc
    描  述：

    日  期：2017-11-20
  ***********************************************************/
   procedure sp_monitorErc20Bal(digitalCoin in varchar2,
                               externalHBal in varchar2,
                               externalCBal in varchar2, 
                               monitor_idx out int,
                               return_code out int,
                               monitor_result out int,
                               monitor_data out resultcur,
                               return_str out varchar2)
   is
     v_l_count                 number(8);
     v_vc_ycbz                 varchar2(1);                  --异常标志
     v_vc_MonitorType          varchar2(32);
     v_vc_Monitorsubtype       varchar2(32);
     v_vc_Monitorname          varchar2(200);
     v_vc_TargetTable          varchar2(32);
     v_t_CreateDate            timestamp;

     v_l_id                    number(20);
     v_l_Stockinfoid                  number(20);
     v_d_ExternalHBal                 number(20,8);
    v_d_ExternalCBal                  number(20,8);
    v_d_ExternalEBal                  number(20,8);
    v_d_Internalbal                   number(24,12);
    v_d_differenceBal                 number(24,12);
    v_vc_monitordesc                  varchar2(1500);
    v_vc_logdesc                      varchar2(1500);
		v_l_idxlevel                      number(1);
    v_vc_stockname                    varchar2(50);
   begin
     
    v_vc_MonitorType := 'MONITORERC20BAL'; 
    v_vc_Monitorname := 'ERC20内外部总额监控';
    v_vc_TargetTable := 'MonitorERC20BAL';
    v_t_createDate := systimestamp;
    monitor_result := 1;
    monitor_idx := 0;
		v_l_idxlevel := 0;
    v_vc_monitordesc := '';
    --===================================
    -- 外部入参转化
    --===================================
     v_l_stockinfoid := to_number(digitalCoin);
     v_d_ExternalHBal := to_number(externalHBal);
     v_d_ExternalCBal := to_number(externalCBal); 
     
     v_l_count :=0;
     select count(1) into v_l_count from stockinfo  where  id=v_l_stockinfoid ; 
     if v_l_count > 0 then
        select upper(stockname) into v_vc_Monitorsubtype from stockinfo  where  id=v_l_stockinfoid ; 
    else
        v_vc_ycbz := 'Y';
        return_str := '[PKG_MONITOR.sp_monitorErc20Bal] 找不到数字资产【'||v_l_stockinfoid||'】信息！';
        raise_application_error(v_vc_ycbz, return_str);
    end if;
     --===================================
     -- 获取外部存管钱包余额
     -- 注意： 这里的变动后余额为刨除费用后的余额
     --===================================
     v_d_ExternalEBal :=0;
     v_l_count :=0;
     select count(1) into v_l_count from  WalletTransferCurrent a where a.stockinfoid = v_l_stockinfoid;
     if v_l_count > 0 then
      select a.lastamt into v_d_ExternalEBal
        from  WalletTransferCurrent a
       where id = (select max(id) from WalletTransferCurrent  where a.stockinfoid = v_l_stockinfoid );
     end if;

    --===================================
    -- 获取预警和禁止阈值
    --===================================
    v_l_count :=0;
    select count(1) into v_l_count from monitorconfig where  monitorcode='ERC20BAL' and active = 1 and (idxid1>0 or idxid2>0 or idxid3>0 or idxid4>0);
    if v_l_count = 0 then 
       v_vc_ycbz := 'Y';
       return_str := '[PKG_MONITOR.sp_monitorErc20Bal] 找不到ERC20资产内外部总额监控服务配置或未配置监控指标！';
       raise_application_error(v_vc_ycbz, return_str);
    end if;

     
      

     --===================================
     -- 获取系统内部数字资产总额 = 资产 - 负债 + 提现未划拨余额
     -- 提现未划拨余额 = 提现申请未划拨总额 - 网络费用
     -- 说明：
     --   划拨费用已统计在超级账户,
     --   提现时，发起未划付就从资产扣除所以需要加回来
     --===================================
     select nvl(sum(curamt),0) into v_d_Internalbal
       from (select (amount) curamt from accountSpotAsset  where  stockinfoid = v_l_stockinfoid
              union all
             select (amount+withdrawingtotal) curamt from accountwalletasset  where  stockinfoid = v_l_stockinfoid
              union all
             select (-debitamt) curamt from accountDebitAsset where stockinfoid = v_l_stockinfoid);
    
    select count(1) into v_l_count from stockinfo a where a.id = v_l_stockinfoid;
    if v_l_count > 0 then
       select a.stockname into v_vc_stockname from stockinfo a where a.id = v_l_stockinfoid;
    end if;
    
    v_vc_ycbz := 'N';
    return_str := '[PKG_MONITOR.sp_monitorErc20Bal]ERC20内外部总额核对异常';
    for monitor_cur in (select rownum id,nvl(c.maxvalue,0) maxvalue,nvl(c.minvalue,0) minvalue,nvl(c.compdirect,1) compdirect,b.idxlevel,b.idxname,a.idxid
                                    from (select idxid1 idxid from monitorconfig where  monitorcode='ERC20BAL' and active = 1 and idxid1>0
                                              union all
                                              select idxid2 idxid from monitorconfig where  monitorcode='ERC20BAL' and active = 1 and idxid2>0
                                              union all
                                              select idxid3 idxid from monitorconfig where  monitorcode='ERC20BAL' and active = 1 and idxid3>0
                                              union all
                                              select idxid4 idxid from monitorconfig where  monitorcode='ERC20BAL' and active = 1 and idxid4>0)a,
                                              Monitorindex b,
                                              (select * from monitorlimitparam  where  stockinfoid=v_l_stockinfoid) c
                                    where a.idxid =b.id
                                       and  b.id = c.relatedid(+)
                                    order by b.idxlevel desc ) loop
                
               if  monitor_cur.compdirect = 4 then      -- 内部-外部
                   v_d_differenceBal := v_d_Internalbal - (v_d_ExternalHBal + v_d_ExternalCBal + v_d_ExternalEBal) ;
                elsif monitor_cur.compdirect = 5 then  -- 外部-内部
                   v_d_differenceBal := (v_d_ExternalHBal + v_d_ExternalCBal + v_d_ExternalEBal) - v_d_Internalbal ;
               else  -- 其他处理成绝对值
                  v_d_differenceBal := abs(v_d_ExternalHBal + v_d_ExternalCBal + v_d_ExternalEBal - v_d_Internalbal);
              end if;
              
              v_vc_logdesc :='';
              if (v_d_differenceBal <>0 and v_d_differenceBal <monitor_cur.minvalue) or (v_d_differenceBal <>0 and v_d_differenceBal >monitor_cur.maxvalue) then
                  
                  -- 预警处理根据指标优先级来处理，同时触发普通级别和最高级别，则以最高级别预警方式处理，暂时不支持按币种区分优先级
                  if v_l_idxlevel = 0 then
                     v_l_idxlevel := monitor_cur.idxlevel; 
                     monitor_idx := monitor_cur.idxid;
                  elsif v_l_idxlevel < monitor_cur.idxlevel then
                     v_l_idxlevel := monitor_cur.idxlevel;
                     monitor_idx :=monitor_cur.idxid;
                  end if; 
                  
                  monitor_result := -1; 
                  v_vc_logdesc :='触发【监控：ERC20内外部总额监控，指标：'||monitor_cur.idxname||'，阈值['||monitor_cur.minvalue||'~'||monitor_cur.maxvalue||']】预警！['||v_vc_stockname||'差额为'||to_char(v_d_differenceBal,'fm999999999990.099999999999')||']热钱包余额为'||to_char(v_d_ExternalHBal,'fm999999999990.099999999999')||'，冷钱包余额为'||to_char(v_d_ExternalCBal,'fm999999999990.099999999999')||'，冷储备钱包余额为'||to_char(v_d_ExternalEBal,'fm999999999990.099999999999')||',内部钱包余额为'||to_char(v_d_Internalbal,'fm999999999990.099999999999')||'。';
                  v_l_id := 2000000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+monitor_cur.id;
                  insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_vc_logdesc,0,0);
              end if;
              
              if length(v_vc_logdesc) > 0 then
                 v_vc_monitordesc := v_vc_monitordesc||v_vc_logdesc||'<br />';
              else
                 v_vc_monitordesc :=v_vc_logdesc;
              end if;
               
        end loop; 
      merge into MonitorERC20BAL a
        using (select v_l_stockinfoid stockinfoid from dual) b
           on (a.stockinfoid = b.stockinfoid)
        when matched then
              update set  ExternalHBal = v_d_ExternalHBal,
                          ExternalCBal = v_d_ExternalCBal, 
                          ExternalEBal = v_d_ExternalEBal,
                          InternalBal = v_d_InternalBal,
                          differenceBal = v_d_differenceBal,
                          monitordesc = v_vc_monitordesc,
                          chkresult = monitor_result,
                          chkdate = v_t_createDate
        when not matched then
              insert (monitorType,monitorSubType,stockinfoid,ExternalHBal,ExternalCBal,ExternalEBal,InternalBal,
                      differenceBal,monitordesc,chkresult,chkdate)
              values (v_vc_MonitorType,v_vc_Monitorsubtype,v_l_stockinfoid,v_d_externalHBal,v_d_externalCBal,v_d_ExternalEBal,v_d_InternalBal,
                      v_d_differenceBal,v_vc_monitordesc,monitor_result,v_t_createDate);
     commit;
     open monitor_data for
     select a.monitordesc,
            a.chkresult
       from MonitorERC20BAL a
      where monitorType ='MONITORERC20BAL'
         and a.monitorsubtype = v_vc_Monitorsubtype 
        and chkResult <0;
        
    return_code :=1;
    return_str := 'ERC20内外部总额监控成功';
    exception when others then
       --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
          return_code:=-1;
          return_str := '[PKG_MONITOR.sp_monitorErc20Bal]报异常错误:'||chr(13)||sqlerrm;
          sp_monitorRunLogs(v_vc_MonitorType,return_str);
          rollback;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
          return_code:=-1;
          return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
          return_str := return_str;
        end if;
   end sp_monitorErc20Bal;

  /**********************************************************
      名  称： 区块高度内外部监控
      功  能： 区块高度内外部监控
      入  参： inBlockNum        内部区块高度
                  outBlockNum      外部区块高度
                  blockResource     区块来源
      出  参： return_code         返回代码   (1.核对执行成功; -1.核对执行失败)
                  monitor_result      监控结果   (1.对账平衡; -1.对账不平)
                  monitor_data        详细的监控结果
                  return_str             返回信息
      创建者：jiangsc
      描  述：

      日  期：2017-11-20
    ***********************************************************/
   procedure sp_monitorBlockNum(inBlockNum in varchar2,
                               outBlockNum in varchar2,
                               blockResource in varchar2,
                               monitor_idx out int,
                               return_code out int,
                               monitor_result out int,
                               monitor_data out resultcur,
                               return_str out varchar2)
    is
      v_l_count                           number(8);
      v_vc_ycbz                           varchar2(1);                  --异常标志
      v_vc_MonitorType                    varchar2(32);
      v_vc_Monitorsubtype                 varchar2(32);
      v_vc_Monitorname                    varchar2(200);
      v_vc_TargetTable                    varchar2(32);
      v_t_createDate                      timestamp;

      v_l_id                              number(20);
      v_vc_monitordesc                    varchar2(1500);
      v_i_inBlockNum                      number(20);
      v_i_outBlockNum                     number(20);
      v_i_differenceNum                   number(20);
      v_vc_blockResource                 varchar2(256);
      v_d_maxValue                       number(20,8);
      v_d_minValue                       number(20,8); 
      
    begin
      v_vc_MonitorType := 'MONITORBLOCKNUM';
      v_vc_Monitorsubtype :='ETH';
      v_vc_Monitorname := '区块高度内外部监控';
      v_vc_TargetTable := 'MonitorBlockNum';
      v_t_createDate := systimestamp;
      v_vc_blockResource :=blockResource;
      monitor_result := 1;
      v_vc_monitordesc :='';
      monitor_idx := 0;
      v_d_maxValue := 0;
      v_d_minValue := 0;
      
     select count(1)into v_l_count from monitorconfig where  monitorcode='BLOCKNUM' and active = 1 and idxid1>0;
     if v_l_count > 0 then
        select idxid1 into monitor_idx from monitorconfig where  monitorcode='BLOCKNUM' and active = 1 and idxid1>0;
     else
        v_vc_ycbz := 'H';
        return_code:=-1;
        return_str :='区块高度内外部监控服务未配置或者监控指标未配置';
        raise_application_error(v_vc_ycbz, return_str);
     end if;
      
      --===================================
      -- 外部入参转化
      --=================================== 
       v_i_inBlockNum := to_number(inBlockNum);
       v_i_outBlockNum := to_number(outBlockNum); 
       v_i_differenceNum := abs(v_i_inBlockNum-v_i_outBlockNum);
       
       select count(1) into v_l_count from monitorlimitparam c where c.relatedid = monitor_idx; 
       if v_l_count > 0 then
          select c.minvalue,c.maxvalue into v_d_minValue,v_d_maxValue from monitorlimitparam c where c.relatedid = monitor_idx;  
        
          if v_i_differenceNum > 0 and (v_i_differenceNum < v_d_minValue or v_i_differenceNum > v_d_maxValue) then
             monitor_result := -1;
             v_vc_monitordesc := '触发【监控:区块高度内外部监控,指标:区块高度内外部预警指标,阈值:['||v_d_minValue||'~'||v_d_maxValue||']】预警！[差额为'||to_char(v_i_differenceNum,'fm999999999999')||']外部区块高度为'||to_char(v_i_outBlockNum,'fm999999999999')||'，内部区块高度为'||to_char(v_i_inBlockNum,'fm999999999999');
             v_l_id := 2100000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+1;
             insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_vc_monitordesc,0,0);
          end if;
        else
           if v_i_differenceNum > 0  then
               monitor_result := -1;
               v_vc_monitordesc := '触发【监控:区块高度内外部监控,指标:区块高度内外部预警指标,阈值:[0,0]】预警！[差额为'||to_char(v_i_differenceNum,'fm999999999999')||']外部区块高度为'||to_char(v_i_outBlockNum,'fm999999999999')||'，内部区块高度为'||to_char(v_i_inBlockNum,'fm999999999999');
               v_l_id := 2100000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+1;
               insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid)
                  values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_vc_monitordesc,0,0);
         
             end if;
         end if; 
      merge into MonitorBlockNum a
        using (select v_vc_blockResource blockResource from dual) b
           on (a.blockResource = b.blockResource)
        when matched then
              update set  inBlockNum = v_i_inBlockNum,
                          outBlockNum = v_i_outBlockNum,
                          differenceNum = v_i_differenceNum,  
                          monitordesc = v_vc_monitordesc,
                          chkresult = monitor_result,
                          chkdate = v_t_createDate
        when not matched then
              insert (monitorType,monitorSubType,inBlockNum,outBlockNum,differenceNum,blockResource,  
                      ExternalWarnValue,InternalWarnValue,monitordesc,chkresult,chkdate)
              values (v_vc_MonitorType,v_vc_Monitorsubtype,v_i_inBlockNum,v_i_outBlockNum,v_i_differenceNum,v_vc_blockResource,
                      v_d_maxValue,v_d_minValue,v_vc_monitordesc,monitor_result,v_t_createDate);
     commit;
     open monitor_data for
     select a.monitordesc,
            a.chkresult
       from MonitorBlockNum a
      where monitorType ='MONITORBLOCKNUM'
          and chkResult <0; 
       
      return_code :=1;
      return_str := '区块高度内外部监控成功';
    exception when others then
       --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
          return_code:=-1;
          return_str := '[PKG_MONITOR.sp_monitorBlockNum]报异常错误:'||chr(13)||sqlerrm;
          sp_monitorRunLogs(v_vc_MonitorType,return_str);
          rollback;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
          return_code:=-1;
          return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
          return_str := return_str;
        end if; 
    end sp_monitorBlockNum; 
  /**********************************************************
    名  称： 账户级别资金流水监控
    功  能： 监控平台账户级别资金流水是否对平
    入  参： bizids                业务品种ID
    出  参： return_code      返回代码   (1.核对执行成功; -1.核对执行失败)
             monitor_result   监控结果   (1.对账平衡; -1.对账不平)
             monitor_data     详细的监控结果
             return_str       返回信息
    创建者：jiangsc
    描  述：

    日  期：2017-11-20
  ***********************************************************/
  procedure sp_chkAccountFundCur(acctId in varchar2,stockinfoid in varchar2,return_code out int,monitor_result out int,monitor_data out resultcur,return_str out varchar2)
  is
     v_l_count                               number(8);
     v_vc_ycbz                               varchar2(1);                  --异常标志
     v_vc_action                             varchar2(10);
     v_l_stockinfoId                         number(20);
     v_l_acctId                              number(20);
  begin

   v_l_stockinfoId := to_number(stockinfoid);
   v_l_acctId := to_number(acctId);
   v_vc_action :='check';
     v_vc_ycbz := 'N';
     return_code := -1;
     return_str := '[PKG_MONITOR.sp_chkAccountFundCur] 单账户资金校验异常！';

     sp_chkWalletAcctAsset(acctId,stockinfoid,v_vc_action,return_code,monitor_result,return_str);
     sp_chkSpotWealthAcctAsset(acctId,stockinfoid,v_vc_action,return_code,monitor_result,return_str);
     sp_chkSpotAcctAsset(acctId,stockinfoid,v_vc_action,return_code,monitor_result,return_str);

   if v_l_stockinfoId > 0 then
      select count(1) into v_l_count
    from MonitorAcctFundCur a
   where a.accountid = v_l_acctId
         and a.stockinfoid = v_l_stockinfoId
     and chkResult in (-1,-2);
   else
      select count(1) into v_l_count
    from  MonitorAcctFundCur a
   where a.accountid = v_l_acctId
     and chkResult in (-1,-2);
   end if;


     if v_l_count > 0 then
       monitor_result := -1;
     else
       monitor_result :=1;
     end if;

   if v_l_stockinfoId > 0 then
      open monitor_data for
  select a.monitordesc,
       a.chkresult
   from  MonitorAcctFundCur a
  where a.accountid = v_l_acctId
        and a.stockinfoid = v_l_stockinfoId
      and chkResult in (-1,-2);
   else
      open monitor_data for
  select a.monitordesc,
       a.chkresult
   from MonitorAcctFundCur a
  where a.accountid = v_l_acctId
      and chkResult in (-1,-2);
   end if;

    return_code :=1;
    return_str := '单账户资金校验成功';
    exception when others then
       --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
          return_code:=-1;
          return_str := '[PKG_MONITOR.sp_chkAccountFundCur]报异常错误:'||chr(13)||sqlerrm;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
          return_str := return_str;
        end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
          return_str := return_str;
        end if;
        rollback;
  end sp_chkAccountFundCur;


  /*************************************************************************************
    名  称：用户提现时，校验账户资产
    功  能：用户提现时，校验账户资产
    入  参:   accountId        账户ID
    出  参：  return_code   返回代码   (1.核对执行成功; -1.核对执行失败)
              chek_result   返回结果   (1.对账平衡; -1.对账不平)
              return_str     返回信息
    创建者： jiangsc
    描  述： 期末 = 期初 + 当期
    日  期：2017-08-24
  */
  procedure sp_chkAcctAsset(acctId in varchar2,return_code out int,chek_result out int,return_str out varchar2)
  is
    v_vc_ycbz                           varchar2(1);             --异常标志
    v_l_count                           number(8);

    v_l_account                         number(20);
    v_vc_stockinfoid                    varchar2(20);
    v_vc_action                         varchar2(10);
  begin
    v_vc_ycbz := 'N';
    v_l_account := to_number(acctId);
    v_vc_action :='withdraw';
    return_code :=1;
    chek_result :=1;
    v_vc_stockinfoid :='0';
    --========================================================
    --检查提现账户状态是否正常
    --========================================================
    v_vc_ycbz := 'N';
    v_l_count := 0;
    select count(1) into v_l_count
     from account
    where status = 0
        and delflag = 0
        and id = v_l_account ;

    if v_l_count = 0 then
       v_vc_ycbz := 'H';
       return_str := '账户不存在或状态异常,请联系系统管理员';
       chek_result :=-1;
        raise_application_error(v_vc_ycbz, return_str);
    end if;

    v_vc_ycbz := 'H';
    return_str := '[PKG_MONITOR.SP_CHKACCTASSET] 资金校验不通过';
    -- 账户全流水比对
    sp_chkCurOneByOne(acctId,return_code,chek_result,return_str);

    -- 账户充值流水比对和充值总额核对
    if chek_result > 0 and return_code >0 then
       sp_chkDigitalCoinRecharge(acctId,return_code,chek_result,return_str);
    end if;

    if chek_result > 0 and return_code >0 then
       sp_chkCashCoinRecharge(acctId,return_code,chek_result,return_str);
    end if;
    -- 账户钱包资产总额与钱包流水核对
    if chek_result > 0 and return_code >0 then
       sp_chkWalletAcctAsset(acctId,v_vc_stockinfoid,v_vc_action,return_code,chek_result,return_str);
    end if;

    -- 账户理财资产余额与账户流水核对
    if chek_result > 0 and return_code >0 then
       sp_chkSpotWealthAcctAsset(acctId,v_vc_stockinfoid,v_vc_action,return_code,chek_result,return_str);
    end if;

    -- 账户现货资产余额与账户流水核对
    if chek_result > 0 and return_code >0 then
       sp_chkSpotAcctAsset(acctId,v_vc_stockinfoid,v_vc_action,return_code,chek_result,return_str);
    end if;

   if return_code < 0 then
      v_vc_ycbz := 'N';
      raise_application_error(v_vc_ycbz, return_str);
    end if;

    if chek_result < 0 then
      raise_application_error(v_vc_ycbz, return_str);
    end if;

    return_str := '账户资产校验通过';
    exception when others then
      --系统自动异常捕捉
      if v_vc_ycbz = 'N' then
        return_code:=-1;
        return_str := '[PKG_MONITOR.SP_CHKACCTASSET]报异常错误:'||chr(13)||sqlerrm;
      end if;
      --人为考虑系统异常
      if v_vc_ycbz = 'Y' then
        return_str := return_str;
      end if;
      --人为的制造了异常
      if v_vc_ycbz = 'H' then
        return_str := return_str;
      end if;
  end sp_chkAcctAsset;

  procedure sp_chkWalletAcctAsset(acctId in varchar2,stockinfoid in varchar2,action in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
  is
      v_l_count                             number(8);
      v_vc_ycbz                             varchar2(1);                              --异常标志
      v_vc_MonitorType                      varchar2(32);
      v_vc_Monitorsubtype                   varchar2(32);
      v_vc_Monitorname                      varchar2(200);
      v_vc_TargetTable                      varchar2(32);

      v_sql_monitor                         varchar2(3000);
      v_sql_Check                           varchar2(3000);
      v_sql_detail                          varchar2(3000);
      cur_monitor                           resultcur;
      v_cur_monitor                         MonitorAcctFundCur%rowtype;

      v_l_stockinfoid                       number(20);
      v_l_acctId                            number(20);
      v_l_id                                number(20);
      v_l_datasource                        number(1);
      v_t_initQueryTime                     timestamp;                               --查询起始化日期
      v_t_bizDate                           timestamp;
      v_t_queryDate                         timestamp;
      v_t_createDate                        timestamp;
      v_t_startDate                         timestamp;
      v_MonitorDesc                         varchar2(500);
      v_differenceassetbal                  number(24, 12);
      v_differencefrozenbal                 number(24, 12);
  begin
     monitor_result :=1;
     return_code :=1;
     v_l_acctId := to_number(acctId);
     v_l_stockinfoId := to_number(stockinfoid);
     v_vc_MonitorType := 'ACCTFUNDCUR';
     v_vc_Monitorsubtype :='ACCT';
     v_vc_Monitorname := '账户资金核对';
     v_vc_TargetTable := 'MonitorAcctFundCur';
     v_t_createDate :=  systimestamp;
     v_t_initQueryTime :=to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
     return_str := '钱包账户资产核对成功';
     --=======================================
     -- 增量监控，取上一个结算结束日期作为本次监控起始日期
     --=======================================
     select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 1 ;
     v_vc_ycbz := 'N';
     v_l_datasource :=2;
     v_sql_monitor := 'select rownum id,'''' monitorType,'''' monitorSubType,asset.accountid,1 acctassettype,asset.stockinfoid bizcategoryID,asset.stockinfoid,asset.stockinfoid relatedstockinfoid,asset.amount assetbal,asset.frozenamt assetfrozenbal,0 debetBal,
                              nvl(cur.curbal,0)+asset.beginbal curAssetBal ,nvl(cur.curfrozenbal,0)+asset.beginfrozenbal curfrozenbal ,0 curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                              '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                         from (select a.accountid,a.stockinfoid,a.amount,a.frozenamt,nvl(b.endbal-endfeebal,0) beginbal,nvl(b.endfrozenbal,0) beginfrozenbal
                                 from accountWalletAsset a,
                                      (select accountid,stockinfoid,endbal,endfrozenbal,endfeebal from monitorbalance where acctassettype = 1 and businessdate=:1)b
                                        where a.accountid = b.accountid(+)
                                          and a.stockinfoid = b.stockinfoid(+)
                                          and a.accountid= :2)asset,
                                      (select accountid,stockinfoid,sum((occuramt-fee) * decode(occurdirect,''increase'',1,-1))curbal,sum(occurforzenamt * decode(occurdirect,''frozen'',1,-1))curfrozenbal
                                         from accountFundCurrent
                                        where currentdate  >:3
                                        group by accountid,stockinfoid)cur
                         where asset.accountid = cur.accountid
                           and asset.stockinfoid = cur.stockinfoid';
     open cur_monitor for v_sql_monitor
     using  v_t_startDate,v_l_acctId,v_t_startDate;
     loop
     fetch cur_monitor into v_cur_monitor;
     exit when cur_monitor%notFound;

  -- 如果参数传过来具体的stockinfoid则只对指定stockinfoid 进行处理，否则全部处理
  if  v_l_stockinfoId > 0 and v_l_stockinfoId <> v_cur_monitor.stockinfoid then
    continue;
  end if;

        v_monitorDesc :='';
        v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;
        v_differencefrozenbal :=v_cur_monitor.assetfrozenbal - v_cur_monitor.curfrozenbal;
        if v_differenceassetbal = 0 and v_differencefrozenbal = 0 then
           monitor_result := 1;
        else
           monitor_result := -1;
           v_monitorDesc :='[钱包资产账户:'||v_cur_monitor.accountid||']数字货币:'||v_cur_monitor.stockinfoid||'，资产与资金流水对不上,资产差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999')||'，冻结余额差额:'||to_char(v_differencefrozenbal,'fm999999999990.099999999999');
        end  if;

        v_l_id := 2100000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;
        v_l_count :=0;
        select count(1) into v_l_count from MonitorAcctFundCur a
         where a.accountid =v_cur_monitor.accountid
           and a.stockinfoid = v_cur_monitor.stockinfoid
           and a.acctassettype = 1 ;
         -- 增量逐笔对账，起始时间取bizdate
        if v_l_count > 0 then
           select a.bizdate into v_t_bizDate from MonitorAcctFundCur a
            where a.accountid =v_cur_monitor.accountid
              and a.stockinfoid = v_cur_monitor.stockinfoid
              and a.acctassettype = 1;
           v_t_queryDate := v_t_bizDate- 2/24/60;
        else
           v_t_bizDate := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
        end if;

        if action = 'check' then
     v_l_count := 0;
           v_sql_Check :=  'select count(1)
                              from (select forzenorgamt,lag(a.forzenlastamt) over( order by currentdate asc) last_forzenorgamt,orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                      from (select currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt from AccountFundCurrent
                                             where  accountid=:1 and stockinfoid=:2 and currentdate between :3 and :4)a
                                      order by currentdate)
                                      where forzenorgamt != last_forzenorgamt or orgamt != last_amt';

           execute immediate  v_sql_Check
                        into  v_l_count
                       using  v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate;

           if v_l_count  > 0 then
               monitor_result := -2;
               v_MonitorDesc:= '[钱包资产账户:'||v_cur_monitor.accountid||'] 数字货币:'||v_cur_monitor.stockinfoid||',在期间:'||to_char(v_t_bizDate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上';
               v_sql_detail := 'insert into MonitorDetail(id,accountId,stockinfoId,bizcategoryID,relatedstockinfoid,originalbusinessid,relatedbusinessid,businessflag,businessdate,monitordesc,monitorDate,datasource)
                                                select 2200000000000000000+to_number(to_char(systimestamp, ''yymmddhh24miss''))*100000+rownum id,accountid,stockinfoId, :1 bizcategoryID,:2 relatedstockinfoid,originalbusinessid,id relatedbusinessid,businessflag,currentdate businessdate,:3,:4,:5
                                                 from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,forzenorgamt,lag(a.forzenlastamt) over( order by currentdate asc) last_forzenorgamt,orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                                            from ( select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt
                                                                       from AccountFundCurrent  where  accountid=:6 and stockinfoid=:7 and currentdate between :8 and :9)a order by currentdate)
                                                where forzenorgamt != last_forzenorgamt or orgamt != last_amt';
               execute immediate v_sql_detail
               using v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_MonitorDesc,v_cur_monitor.chkdate,v_l_datasource,
                     v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate;

               insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                                values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_MonitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
           end if;

           if monitor_result = 1  then
              v_t_bizDate := v_t_createDate;
           elsif  monitor_result = -1  then
              insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                               values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);

           end if;

           merge into MonitorAcctFundCur a
           using (select v_cur_monitor.accountid accountid,v_cur_monitor.stockinfoid stockinfoid,v_cur_monitor.acctassettype  acctassettype from dual) b
              on (a.accountid = b.accountid and a.stockinfoid = b.stockinfoid and a.acctassettype = b.acctassettype)
           when  matched then
                  update set assetbal = v_cur_monitor.assetbal,
                             assetfrozenbal = v_cur_monitor.assetfrozenbal,
                             curassetbal = v_cur_monitor.curassetbal,
                             curfrozenbal = v_cur_monitor.curfrozenbal,
                             differenceassetbal = v_differenceassetbal,
                             differencefrozenbal = v_differencefrozenbal,
                             monitordesc = v_monitorDesc,
                             chkresult = monitor_result,
                             bizDate = v_t_bizDate,
                             chkdate = v_cur_monitor.chkdate
           when not matched then
                  insert (id,monitorType,monitorSubType,accountId,bizcategoryid,relatedstockinfoid,stockinfoid,
                          assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                          differencedebetbal,differenceassetbal,differencefrozenbal,
                          monitordesc,chkresult,bizDate,chkdate)
                  values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,
                          v_cur_monitor.assetbal,v_cur_monitor.assetfrozenbal,v_cur_monitor.debetbal,v_cur_monitor.curassetbal,v_cur_monitor.curfrozenbal,v_cur_monitor.curdebetbal,
                          0,v_differenceassetbal,v_differencefrozenbal,
                          v_monitorDesc,monitor_result,v_cur_monitor.chkdate,v_cur_monitor.chkdate);
      end if;
     end loop;

    close cur_monitor;
    commit;
    return_code :=1;
    exception when others then
     --系统自动异常捕捉
     if v_vc_ycbz = 'N' then
   return_code:=-1;
   return_str := '[PKG_MONITOR.sp_chkWalletAcctAsset]报异常错误:'||chr(13)||sqlerrm;
     end if;
      --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
      --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
        rollback;
  sp_monitorRunLogs(v_vc_MonitorType,return_str);
  end sp_chkWalletAcctAsset;

  procedure sp_chkSpotWealthAcctAsset(acctId in varchar2,stockinfoid in varchar2,action in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
  is
     v_l_count                          number(8);
     v_vc_ycbz                          varchar2(1);                              --异常标志
     v_vc_MonitorType                   varchar2(32);
     v_vc_Monitorsubtype                varchar2(32);
     v_vc_Monitorname                   varchar2(200);
     v_vc_TargetTable                   varchar2(32);
     cur_monitor                        resultcur;
     v_cur_monitor                      MonitorAcctFundCur%rowtype;
     v_sql_assetMonitor                 varchar2(3000);
     v_sql_debitMonitor                 varchar2(3000);
     v_sql_Check                        varchar2(3000);
     v_sql_detail                       varchar2(3000);

     v_l_stockinfoid                    number(20);
     v_l_acctId                         number(20);
     v_l_id                             number(20);
     v_l_bizCategoryId                  number(20);                    --  专区品种ID
     v_l_relatedstockinfoid             number(20);                    --  币对品种
     v_l_datasource                     number(1);
     v_t_initQueryTime                  timestamp;
     v_t_bizDate                        timestamp;
     v_t_queryDate                      timestamp;
     v_t_createDate                     timestamp;
     v_t_startDate                      timestamp;
     v_MonitorDesc                      varchar2(500);
     v_differenceassetbal               number(20,8);
  begin
     monitor_result :=1;
     return_code :=1;
     v_l_acctId := to_number(acctId);
     v_l_stockinfoId := to_number(stockinfoid);
      v_vc_MonitorType := 'ACCTFUNDCUR';
      v_vc_Monitorsubtype :='ACCT';
      v_vc_Monitorname := '理财账户资产核对';
      v_vc_TargetTable := 'MonitorAcctFundCur';
      v_t_createDate :=  systimestamp;
      v_t_initQueryTime := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');

      --=======================================
      -- 增量监控，取上一个结算结束日期作为本次监控起始日期
      --=======================================

     return_str := '理财账户资产核对成功';
      select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 4 ;
      v_l_datasource :=2;
      v_sql_assetMonitor := 'select rownum id,'''' monitorType,'''' monitorSubType,asset.accountid,3 acctassettype,asset.stockinfoid bizcategoryID,asset.stockinfoid,asset.stockinfoid relatedstockinfoid,asset.amount assetbal,asset.frozenamt assetfrozenbal,0 debetBal,
                                    nvl(cur.curbal,0)+asset.beginbal curAssetBal ,nvl(cur.curfrozenbal,0)+asset.beginfrozenbal curfrozenbal ,0 curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                                    '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                               from (select a.wealthaccountid accountid,a.stockinfoid,a.wealthamt amount,0 frozenamt,nvl(b.endbal,0) beginbal,nvl(b.endfrozenbal,0) beginfrozenbal
                                       from accountwealthasset a,
                                            (select accountid,stockinfoid,endbal,endfrozenbal from monitorbalance where acctassettype = 4 and businessdate=:1)b
                                      where a.wealthaccountid = b.accountid(+)
                                        and a.stockinfoid = b.stockinfoid(+)
                                        and a.wealthaccountid= :2)asset,
                                    (select accountid,stockinfoid,sum(occuramt * decode(occurdirect,''increase'',1,-1))curbal,0 curfrozenbal
                                       from accountWealthCurrent
                                      where accountassettype=''wealthAccountAsset''
                                        and currentdate >:3
                                      group by accountid,stockinfoid)cur
                               where asset.accountid = cur.accountid
                                 and asset.stockinfoid = cur.stockinfoid';
      v_vc_ycbz := 'N';
      open cur_monitor for v_sql_assetMonitor
      using  v_t_startDate,v_l_acctId,v_t_startDate;
      loop
      fetch cur_monitor into v_cur_monitor;
      exit when cur_monitor%notFound;
          -- 如果参数传过来具体的stockinfoid则只对指定stockinfoid 进行处理，否则全部处理
          if  v_l_stockinfoId > 0 and v_l_stockinfoId <> v_cur_monitor.stockinfoid then
            continue;
          end if;
           v_l_bizCategoryId := v_cur_monitor.stockinfoid;
           v_l_relatedstockinfoid := v_cur_monitor.stockinfoid;
           v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;
           if  v_differenceassetbal = 0  then
               monitor_result := 1;
           else
               monitor_result := -1;
               v_monitorDesc :='[账户:'||v_cur_monitor.accountid||']理财资产的数字货币:'||v_cur_monitor.stockinfoid||'，资产与资金流水对不上,资产差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999');
           end  if;

             v_l_id := 2300000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;

          if action = 'check' then
             v_l_count :=0;
             select count(1) into v_l_count from MonitorAcctFundCur a
              where a.accountid =v_cur_monitor.accountid
                and a.stockinfoid = v_cur_monitor.stockinfoid
                and a.acctassettype = 3 ;
              -- 增量逐笔对账，起始时间取bizdate
             if v_l_count > 0 then
                select a.bizdate into v_t_bizDate from MonitorAcctFundCur a
                 where a.accountid =v_cur_monitor.accountid
                   and a.stockinfoid = v_cur_monitor.stockinfoid
                   and a.acctassettype = 3;
                v_t_queryDate := v_t_bizDate- 2/24/60;
             else
                v_t_bizDate := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
             end if;

             v_l_count := 0;
             v_sql_Check :=  'select count(1)
                                from (select orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                        from (select currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt from accountWealthCurrent
                                               where accountassettype=''wealthAccountAsset'' and accountid=:1 and stockinfoid=:2 and currentdate between :3 and :4)a
                                       order by currentdate)
                                where orgamt != last_amt';

             execute immediate  v_sql_Check
                          into  v_l_count
                         using  v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate;

             if v_l_count  > 0 then
                 monitor_result := -2;
                 v_MonitorDesc:= '[理财资产账户:'||v_cur_monitor.accountid||'] 数字货币:'||v_cur_monitor.stockinfoid||',在期间:'||to_char(v_t_bizDate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上';
                 v_sql_detail := 'insert into MonitorDetail(id,accountId,stockinfoId,bizcategoryID,relatedstockinfoid,originalbusinessid,relatedbusinessid,businessflag,businessdate,monitordesc,monitorDate,datasource)
                                                  select 2400000000000000000+to_number(to_char(systimestamp, ''yymmddhh24miss''))*100000++rownum id,accountid,stockinfoId, :1 bizcategoryID,:2 relatedstockinfoid,originalbusinessid,id relatedbusinessid,businessflag,currentdate businessdate,:3,:4,:5
                                                   from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                                              from ( select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt
                                                                         from accountWealthCurrent  where  accountid=:6 and stockinfoid=:7 and currentdate between :8 and :9)a order by currentdate)
                                                  where orgamt != last_amt';
                 execute immediate v_sql_detail
                 using v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_MonitorDesc,v_cur_monitor.chkdate,v_l_datasource,
                          v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate;

                 insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                                  values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_MonitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
             end if;

             if monitor_result = 1 then
                v_t_bizDate := v_cur_monitor.chkdate;
             elsif monitor_result = -1  then
                insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
             end if;

             merge into MonitorAcctFundCur a
             using (select v_cur_monitor.accountid accountid,v_cur_monitor.stockinfoid stockinfoid,v_cur_monitor.acctassettype  acctassettype from dual) b
                on (a.accountid = b.accountid and a.stockinfoid = b.stockinfoid and a.acctassettype = b.acctassettype)
                when matched then
                      update set assetbal = v_cur_monitor.assetbal,
                                 curassetbal = v_cur_monitor.curassetbal,
                                 differenceassetbal = v_differenceassetbal,
                                 monitordesc = v_monitorDesc,
                                 chkresult = monitor_result,
                                 bizDate = v_t_bizDate,
                                 chkdate = v_cur_monitor.chkdate
                when not matched then
                      insert (id,monitorType,monitorSubType,accountId,acctassettype,bizcategoryid,relatedstockinfoid,stockinfoid,
                              assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                              differencedebetbal,differenceassetbal,differencefrozenbal,
                              monitordesc,chkresult,bizDate,chkdate)
                      values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,v_cur_monitor.acctassettype,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,
                              v_cur_monitor.assetbal,0,0,v_cur_monitor.curassetbal,0,0,
                              0,v_differenceassetbal,0,
                              v_monitorDesc,monitor_result,v_cur_monitor.chkdate,v_cur_monitor.chkdate);
          end if;
      end loop;
      close cur_monitor;

       v_sql_debitMonitor := 'select rownum id,'''' monitorType,'''' monitorSubType,debit.accountid,3 acctassettype,debit.stockinfoid bizcategoryID,debit.stockinfoid,debit.stockinfoid relatedstockinfoid,debit.amount assetbal,debit.frozenamt assetfrozenbal,0 debetBal,
                                     nvl(cur.curbal,0)+debit.beginbal curAssetBal ,nvl(cur.curfrozenbal,0)+debit.beginfrozenbal curfrozenbal ,0 curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                                     '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                                from (select a.wealthaccountid accountid,a.stockinfoid,a.debitamt amount,0 frozenamt,nvl(b.endbal,0) beginbal,nvl(b.endfrozenbal,0) beginfrozenbal
                                        from accountwealthdebitasset a,
                                             (select accountid,stockinfoid,endbal,endfrozenbal from monitorbalance where acctassettype = 5 and businessdate=:1)b
                                        where a.wealthaccountid = b.accountid(+)
                                          and a.stockinfoid = b.stockinfoid(+))debit,
                                      (select accountid,stockinfoid,sum(nvl(occuramt,0) * decode(occurdirect,''increase'',1,-1))curbal,0 curfrozenbal
                                         from accountWealthCurrent
                                        where accountassettype=''wealthAccountDebit''
                                          and currentdate > :2
                                        group by accountid,stockinfoid)cur
                                where debit.accountid = cur.accountid
                                  and debit.stockinfoid = cur.stockinfoid';
       v_vc_ycbz := 'N';
       return_code := -1;
       return_str := '[PKG_MONITOR.sp_chkSpotWealthAcctAsset] 理财账户应付利息核对异常';
       open cur_monitor for v_sql_debitMonitor
       using  v_t_startDate,v_t_startDate;
       loop
       fetch cur_monitor into v_cur_monitor;
       exit when cur_monitor%notFound;
          -- 如果参数传过来具体的stockinfoid则只对指定stockinfoid 进行处理，否则全部处理
          if  v_l_stockinfoId > 0 and v_l_stockinfoId <> v_cur_monitor.stockinfoid then
            continue;
          end if;

          v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;

          if v_differenceassetbal = 0  then
             monitor_result := 1;
          else
             monitor_result := -1;
             v_monitorDesc :='[理财资产账户:'||v_cur_monitor.accountid||'] 数字货币为'||v_cur_monitor.stockinfoid||'的应付利息与资金流水对不上,差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999');
          end  if;

          v_l_id := 2500000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;
          if action = 'check' then
             v_l_count :=0;
             select count(1) into v_l_count from MonitorAcctFundCur a
              where a.accountid =v_cur_monitor.accountid
                and a.stockinfoid = v_cur_monitor.stockinfoid
                and a.acctassettype = 3 ;
              -- 增量逐笔对账，起始时间取bizdate
              if v_l_count > 0 then
                 select a.bizdate into v_t_bizDate from MonitorAcctFundCur a
                  where a.accountid =v_cur_monitor.accountid
                    and a.stockinfoid = v_cur_monitor.stockinfoid
                    and a.acctassettype = 3;
                  v_t_queryDate := v_t_bizDate- 2/24/60;
              else
                 v_t_bizDate := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
              end if;

             v_l_count := 0;
             v_sql_Check := 'select count(1)
                               from (select orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                        from (select currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt from accountWealthCurrent
                                              where accountassettype=''spotAccountWealth'' and accountid=:1 and stockinfoid=:2 and currentdate between :3 and :4)a
                                       order by currentdate)
                              where orgamt != last_amt';

             execute immediate v_sql_Check
                          into v_l_count
                         using v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_t_createDate;

             if v_l_count  > 0  then
                monitor_result := -2;
                v_MonitorDesc:= '[理财资产账户:'||v_cur_monitor.accountid||']  数字货币:'||v_cur_monitor.stockinfoid||',在期间:'||to_char(v_t_bizDate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上';
                v_sql_detail := 'insert into MonitorDetail(id,accountId,stockinfoId,bizcategoryID,relatedstockinfoid,originalbusinessid,relatedbusinessid,businessflag,businessdate,monitordesc,monitorDate,datasource)
                                 select 2600000000000000000+to_number(to_char(systimestamp, ''yymmddhh24miss''))*100000+rownum id,accountid,stockinfoId, :1 bizcategoryID,:2 relatedstockinfoid,originalbusinessid,id relatedbusinessid,businessflag,currentdate businessdate,:3,:4,:5
                                   from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                          from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt
                                                  from accountWealthCurrent  where  accountid=:6 and stockinfoid=:7 and currentdate between :8 and :9)a order by currentdate)
                                  where orgamt != last_amt';
                execute immediate v_sql_detail
                using v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_MonitorDesc,v_t_createDate,v_l_datasource,
                      v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_t_createDate;

                insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_MonitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
             end if;

             if monitor_result = 1  then
                v_t_bizDate := v_t_createDate;
             elsif monitor_result = -1 then
                insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,datasource)
                                 values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_t_createDate,v_vc_TargetTable,v_monitorDesc,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_l_datasource);
             end if;

             merge into MonitorAcctFundCur a
             using (select v_cur_monitor.accountid accountid,v_cur_monitor.stockinfoid stockinfoid,v_cur_monitor.acctassettype  acctassettype from dual) b
             on (a.accountid = b.accountid and a.stockinfoid = b.stockinfoid and a.acctassettype = b.acctassettype)
             when matched then
                   update set assetbal = v_cur_monitor.assetbal,
                              curassetbal = v_cur_monitor.curassetbal,
                              differenceassetbal = v_differenceassetbal,
                              monitordesc = v_monitorDesc,
                              chkresult = monitor_result,
                              bizDate = v_t_bizDate,
                              chkdate = v_t_createDate
             when not matched then
                   insert (id,monitorType,monitorSubType,accountId,acctassettype,bizcategoryid,relatedstockinfoid,stockinfoid,
                           assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                           differencedebetbal,differenceassetbal,differencefrozenbal,
                           monitordesc,chkresult,bizDate,chkdate)
                   values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,v_cur_monitor.acctassettype,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,v_cur_monitor.stockinfoid,
                           v_cur_monitor.assetbal,0,0,v_cur_monitor.curassetbal,0,0,
                           0,v_differenceassetbal,0,
                           v_monitorDesc,monitor_result,v_t_createDate,v_t_createDate);
          end if;

       end loop;
       close cur_monitor;
       commit;

     return_code :=1;
     exception when others then
     --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := '[PKG_MONITOR.sp_chkSpotWealthAcctAsset]报异常错误:'||chr(13)||sqlerrm;
           sp_monitorRunLogs(v_vc_MonitorType,return_str);
           rollback;
        end if;
      --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
      --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
  end  sp_chkSpotWealthAcctAsset;

  procedure sp_chkSpotAcctAsset(acctId in varchar2,stockinfoid in varchar2,action in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
  is
     v_l_count                               number(8);
     v_vc_ycbz                               varchar2(1);                  --异常标志
     v_vc_MonitorType                        varchar2(32);
     v_vc_Monitorsubtype                     varchar2(32);
     v_vc_Monitorname                        varchar2(200);
     v_vc_TargetTable                        varchar2(32);

     v_l_datasource                          number(1);
     v_l_stockinfoid                         number(20);
     v_l_acctId                              number(20);
     v_l_id                                  number(20);
     v_l_relatedstockinfoid                  number(20);
     v_t_createDate                          timestamp;
     v_t_bizDate                             timestamp;
     v_t_queryDate                           timestamp;
     v_l_bizcategoryid                       number(20);
     v_t_initQueryTime                       timestamp;                      --查询起始化日期
     v_t_startDate                           timestamp;
     v_differencedebetbal                    number(24, 12);
     v_differenceassetbal                    number(24, 12);
     v_differencefrozenbal                   number(24, 12);
     v_debitDesc                             varchar2(500);
     v_assetDesc                             varchar2(500);
     v_monitorDesc                           varchar2(500);
     v_sql_query                             varchar2(5000);               -- 标的总额监控SQL
     v_sql_AssetCheck                        varchar2(3000);
     v_sql_DebitCheck                        varchar2(3000);
     v_sql_detail                            varchar2(3000);
     cur_monitor                             resultcur;
     v_cur_monitor                           MonitorAcctFundCur%rowtype;

     cursor cur_stockinfo is
            select id,tableasset,tablerealdeal,tabledebitasset,tablefundcurrent,tradestockinfoid,capitalstockinfoid
              from stockinfo where stocktype = 'leveragedSpot';
     v_cur_stockinfo                         cur_stockinfo%rowtype;
  begin
     v_l_acctId := to_number(acctId);
     v_l_stockinfoId := to_number(stockinfoid);
     v_vc_MonitorType := 'ACCTFUNDCUR';
     v_vc_Monitorname := '账户资金监控';
     v_vc_TargetTable := 'MonitorAcctFundCur';

     return_code := 1;
     monitor_result :=1;


     v_t_createDate :=  systimestamp;

     v_l_datasource :=2;
     v_vc_ycbz := 'N';
     return_str := '现货账户资金监控成功';
     open cur_stockinfo;
     loop
       fetch cur_stockinfo into v_cur_stockinfo;
       exit when cur_stockinfo%notFound;
             --=======================================
             -- 增量监控，取上一个结算结束日期作为本次监控起始日期
             --=======================================
             select nvl(max(businessdate),v_t_initQueryTime) into v_t_startDate  from Monitorbalance a  where  a.acctassettype = 2 ;
             v_sql_query :='select rownum id,'''' monitorType,'''' monitorSubType,asset.accountid,2 acctassettype,0 bizcategoryID,asset.stockinfoid,0 relatedstockinfoid,asset.assetbal,asset.frozenassetbal assetfrozenbal,nvl(debet.debtBal,0) debetBal,
                                   nvl(cur.curbal,0)+nvl(asset.beginbal,0) curAssetBal ,nvl(cur.curfrozenbal,0)+nvl(asset.beginFrozenbal,0) curfrozenbal,nvl(cur.curDebt,0)+nvl(debet.beginDebitbal,0) curDebetBal,0 differenceDebetBal, 0 differenceAssetBal,0 differencefrozenbal,
                                   '''' monitordesc,1 chkResult,systimestamp bizDate,systimestamp chkDate
                              from (select a.accountid,a.stockinfoid,a.amount assetbal,a.frozenamt frozenassetbal,nvl(endbal,0)beginbal,nvl(endfrozenbal,0)beginFrozenbal
                                      from '||v_cur_stockinfo.tableasset||' a,
                                           (select accountid,stockinfoid, endbal, endfrozenbal from monitorbalance where acctassettype = 2 and businessdate = :1 )b
                                      where a.accountid=b.accountid(+) and a.stockinfoid = b.stockinfoid(+) and a.stockinfoid in (:2,:3) and a.accountid = :4)asset,
                                    (select a.borroweraccountid accountid,a.stockinfoid, a.debitamt debtBal,nvl(endbal,0)beginDebitbal
                                       from '||v_cur_stockinfo.tabledebitasset||' a,
                                            (select accountid,stockinfoid, endbal from monitorbalance where acctassettype = 3 and businessdate = :5 )b
                                      where a.borroweraccountid=b.accountid(+) and a.stockinfoid = b.stockinfoid(+) and a.stockinfoid in (:6,:7)  and a.relatedstockinfoid =:8 and a.borroweraccountid = :9 )debet,
                                    (select accountid,stockinfoid,sum(curbal) curbal,sum(curfrozenbal) curfrozenbal ,sum(curDebt) curDebt
                                       from (select accountid,stockinfoid,sum((b.occuramt - b.fee) * decode(b.occurdirect,''increase'',1,''decrease'',-1,''unfrozenDecrease'',-1)) curbal,
                                                    sum((b.occurforzenamt) * decode(b.occurdirect,''frozen'',1,''unfrozen'',-1,''unfrozenDecrease'',-1,0)) curfrozenbal,0 curDebt
                                               from '||v_cur_stockinfo.tablefundcurrent||' b
                                              where accountassettype = ''spotAccountAsset'' and accountid =:10 group by accountid, stockinfoid
                                              union all
                                             select b.accountid,b.stockinfoid,0 curbal,0 curfrozenbal,sum((b.occuramt)*decode(b.occurdirect,''increase'',1,''decrease'',-1,''unfrozenDecrease'',-1,0)) curDebt
                                               from '||v_cur_stockinfo.tablefundcurrent||' b
                                              where accountassettype=''spotAccountDebit'' and accountid =:11 group by b.accountid,b.stockinfoid )group by accountid,stockinfoid) cur
                              where asset.accountid = debet.accountid(+)
                                and asset.stockinfoid = debet.stockinfoid(+)
                                and asset.accountid = cur.accountid
                                and asset.stockinfoid = cur.stockinfoid';

               -- 循环账户-币对
                open cur_monitor for v_sql_query
                using  v_t_startDate,v_cur_stockinfo.tradestockinfoid,v_cur_stockinfo.capitalstockinfoid,v_l_acctId,
                          v_t_startDate,v_cur_stockinfo.tradestockinfoid,v_cur_stockinfo.capitalstockinfoid,v_cur_stockinfo.capitalstockinfoid,v_l_acctId,
                          v_l_acctId,v_l_acctId;
                 loop
                   fetch cur_monitor into v_cur_monitor;
                   exit when cur_monitor%notFound;
                   -- 如果参数传过来具体的stockinfoid则只对指定stockinfoid 进行处理，否则全部处理
                  if  v_l_stockinfoId > 0 and v_l_stockinfoId <> v_cur_monitor.stockinfoid then
                    continue;
                  end if;
                   v_debitDesc:='';
                   v_assetDesc:='';
                   v_monitorDesc:='';
                   v_differencedebetbal :=v_cur_monitor.debetbal - v_cur_monitor.curdebetbal;
                   v_differenceassetbal := v_cur_monitor.assetbal - v_cur_monitor.curassetbal;
                   v_differencefrozenbal :=v_cur_monitor.assetfrozenbal - v_cur_monitor.curfrozenbal;
                   -- ID 生成策略，时间戳+业务+序号
                   v_l_id :=2700000000000000000+to_number(to_char(systimestamp, 'yymmddhh24miss'))*100000+v_cur_monitor.id;
                   v_l_bizcategoryid := v_cur_stockinfo.capitalstockinfoid;
                   v_l_relatedstockinfoid := v_cur_stockinfo.id;
                   if v_cur_stockinfo.tradestockinfoid =v_cur_monitor.stockinfoid then
                       v_vc_Monitorsubtype :='TARGET';
                    else
                      v_vc_Monitorsubtype :='CAPITAL';
                    end if;

                   if v_differencedebetbal = 0 and  v_differenceassetbal = 0 and v_differencefrozenbal = 0 then
                      monitor_result := 1;
                  else
                      monitor_result := -1;
                      v_monitorDesc :='[现货钱包账户:'||v_cur_monitor.accountid||']品种代码:'||v_l_relatedstockinfoid||'，货币代码:'||v_cur_monitor.stockinfoid||'，资金流水对不上,资产差额:'||to_char(v_differenceassetbal,'fm999999999990.099999999999')||'，冻结余额差额:'||to_char(v_differencefrozenbal,'fm999999999990.099999999999')||'，负债差额:'||to_char(v_differencedebetbal,'fm999999999990.099999999999');
                   end  if;

                   if action = 'check' then
                          v_l_count :=0;
                         select count(1) into v_l_count from MonitorAcctFundCur a
                         where a.accountid =v_cur_monitor.accountid
                            and a.acctassettype = 2
                            and a.bizcategoryid = v_cur_monitor.bizcategoryid
                            and a.stockinfoid = v_cur_monitor.stockinfoid
                            and a.relatedstockinfoid = v_l_relatedstockinfoid;
                         -- 增量逐笔对账，起始时间取bizdate
                         if v_l_count > 0 then
                            select a.bizdate into v_t_bizDate from MonitorAcctFundCur a
                           where a.accountid =v_cur_monitor.accountid
                              and a.acctassettype = 2
                              and a.bizcategoryid = v_cur_monitor.bizcategoryid
                              and a.stockinfoid = v_cur_monitor.stockinfoid
                              and a.relatedstockinfoid = v_l_relatedstockinfoid;
                              v_t_queryDate := v_t_bizDate- 2/24/60;
                         else
                            v_t_bizDate := to_timestamp('20180101010000.000', 'yyyymmddhh24miss.ff3');
                         end if;

                         v_l_count := 0;
                      v_sql_AssetCheck :=  'select count(1)
                                                         from (select forzenorgamt,lag(a.forzenlastamt) over( order by currentdate asc) last_forzenorgamt,orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                                                    from (select currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt from '||v_cur_stockinfo.tablefundcurrent||'
                                                                             where accountid = :1 and  stockinfoid = :2 and accountassettype=''spotAccountAsset'' and currentdate between :3 and :4)a)
                                                                    where forzenorgamt != last_forzenorgamt or orgamt != last_amt';

                        execute immediate  v_sql_AssetCheck
                                               into  v_l_count
                                             using  v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate;

                        if v_l_count  > 0 then
                           monitor_result := -2;
                           v_assetDesc:= '[现货钱包账户:'||v_cur_monitor.accountid||']品种代码:'||v_l_relatedstockinfoid||',货币代码:'||v_cur_monitor.stockinfoid||',期间:'||to_char(v_t_bizDate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 资金流水逐笔对不上';
                           v_sql_detail := 'insert into MonitorDetail(id,accountId,stockinfoId,bizcategoryID,relatedstockinfoid,originalbusinessid,relatedbusinessid,businessflag,businessdate,monitordesc,monitorDate,Datasource)
                                                  select 2800000000000000000+to_number(to_char(systimestamp, ''yymmddhh24miss''))*100000+rownum id,accountid,stockinfoId, :1 bizcategoryID,:2 relatedstockinfoid,originalbusinessid,id relatedbusinessid,businessflag,currentdate businessdate,:3,:4,2
                                                   from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,forzenorgamt,lag(a.forzenlastamt) over( order by currentdate asc) last_forzenorgamt,orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                                              from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt
                                                                         from '||v_cur_stockinfo.tablefundcurrent||'
                                                                       where accountid = :5 and  stockinfoid = :6  and accountassettype=''spotAccountAsset'' and currentdate between :7 and :8)a order by currentdate)
                                                  where forzenorgamt != last_forzenorgamt or orgamt != last_amt';
                           execute immediate v_sql_detail
                           using v_cur_stockinfo.capitalstockinfoid,v_cur_stockinfo.id,v_assetDesc,v_cur_monitor.chkdate,
                                    v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate;

                           insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,Datasource)
                               values(v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_assetDesc,v_l_bizCategoryId,v_l_relatedstockinfoid,v_l_datasource);
                        end if;

                        v_l_count := 0;
                        v_sql_DebitCheck := 'select count(1)
                                                          from (select  a.forzenorgamt, lag(a.forzenlastamt) over( order by a.currentdate asc) last_forzenorgamt,
                                                                              a.orgamt,lag(a.lastamt) over( order by a.currentdate asc) last_amt
                                                                      from '||v_cur_stockinfo.tablefundcurrent||' a
                                                                    where  accountid = :1
                                                                        and  stockinfoid = :2
                                                                        and currentdate between :3 and :4
                                                                        and accountassettype=''spotAccountDebit''
                                                                      order  by a.currentdate asc)
                                                           where orgamt != last_amt ';
                        execute immediate  v_sql_DebitCheck
                                              into  v_l_count
                                            using  v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate ;

                        if v_l_count  > 0 then
                           monitor_result := -2;
                           v_debitDesc:= ' [现货钱包账户:'||v_cur_monitor.accountid||']品种代码:'||v_l_relatedstockinfoid||',货币代码:'||v_cur_monitor.stockinfoid||',期间:'||to_char(v_t_bizDate, 'yyyy-mm-dd hh24:mi:ss')||'~'||to_char(v_t_createDate, 'yyyy-mm-dd hh24:mi:ss')||' 负债流水逐笔对不上';

                           v_sql_detail := 'insert into MonitorDetail(id,accountId,stockinfoId,bizcategoryID,relatedstockinfoid,originalbusinessid,relatedbusinessid,businessflag,businessdate,monitordesc,monitorDate,Datasource)
                                                  select 2900000000000000000+to_number(to_char(systimestamp, ''yymmddhh24miss''))*100000+rownum id,accountid,stockinfoId, :1 bizcategoryID,:2 relatedstockinfoid,originalbusinessid,id relatedbusinessid,businessflag,currentdate businessdate,:3,:4,2
                                                   from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,forzenorgamt,lag(a.forzenlastamt) over( order by currentdate asc) last_forzenorgamt,orgamt,lag(a.lastamt) over( order by currentdate asc) last_amt
                                                              from (select id,accountid,stockinfoId,originalbusinessid,businessflag,currentdate,orgamt,lastamt,forzenorgamt ,forzenlastamt
                                                                         from '||v_cur_stockinfo.tablefundcurrent||'
                                                                       where accountid = :5 and  stockinfoid = :6  and accountassettype=''spotAccountDebit'' and currentdate between :7 and :8)a order by currentdate)
                                                  where forzenorgamt != last_forzenorgamt or orgamt != last_amt';
                           execute immediate v_sql_detail
                           using v_cur_stockinfo.capitalstockinfoid,v_cur_stockinfo.id,v_debitDesc,v_cur_monitor.chkdate,
                                    v_cur_monitor.accountid,v_cur_monitor.stockinfoid,v_t_bizDate,v_cur_monitor.chkdate;

                           insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,Datasource)
                               values(v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_debitDesc,v_l_bizCategoryId,v_l_relatedstockinfoid,v_l_datasource);
                        end if;

                         if length(v_monitorDesc) > 0 and length(v_assetDesc) > 0  then
                             v_monitorDesc := v_monitorDesc||', '||v_assetDesc;
                          elsif length(v_assetDesc) > 0 then
                             v_monitorDesc :=v_assetDesc;
                          end if;

                          if length(v_monitorDesc)> 0 and length(v_debitDesc) > 0 then
                               v_monitorDesc :=v_monitorDesc||', '||v_debitDesc;
                          elsif length(v_debitDesc) > 0 then
                             v_monitorDesc :=v_debitDesc;
                          end if;

                          if monitor_result = 1 then
                             v_t_bizDate := v_cur_monitor.chkdate;
                          elsif  monitor_result = -1 then
                               insert into MonitorLogs (id,Monitortype,Monitorsubtype,Monitorname,Monitorresult,Monitordate,Targettable,monitorlogdesc,bizcategoryid,relatedstockinfoid,Datasource)
                                 values(v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_vc_Monitorname,monitor_result,v_cur_monitor.chkdate,v_vc_TargetTable,v_monitorDesc,v_l_bizCategoryId,v_l_relatedstockinfoid,v_l_datasource);

                          end if;

                          merge into MonitorAcctFundCur a
                         using (select v_cur_monitor.accountid accountid, v_l_bizcategoryid bizcategoryid,v_cur_monitor.stockinfoid stockinfoid,v_l_relatedstockinfoid relatedstockinfoid,2 acctassettype from dual) b
                             on (a.accountid = b.accountid and a.bizcategoryID = b.bizcategoryid and a.stockinfoid = b.stockinfoid and a.relatedstockinfoid = b.relatedstockinfoid and a.acctassettype = b.acctassettype)
                         when matched then
                                     update
                                           set  assetbal = v_cur_monitor.assetbal,
                                                  assetfrozenbal = v_cur_monitor.assetfrozenbal,
                                                  debetbal = v_cur_monitor.debetbal,
                                                  curassetbal = v_cur_monitor.curassetbal,
                                                  curfrozenbal = v_cur_monitor.curfrozenbal,
                                                  curdebetbal = v_cur_monitor.curdebetbal,
                                                  differencedebetbal = v_differencedebetbal,
                                                  differenceassetbal = v_differenceassetbal,
                                                  differencefrozenbal = v_differencefrozenbal,
                                                  monitordesc = v_monitorDesc,
                                                  chkresult = monitor_result,
                                                  bizDate = v_t_bizDate,
                                                  chkdate = v_cur_monitor.chkdate
                         when not matched then
                                         insert (id,monitorType,monitorSubType,accountId,acctassettype,bizcategoryid,relatedstockinfoid,stockinfoid,
                                                    assetbal,assetfrozenbal,debetbal,curassetbal,curfrozenbal,curdebetbal,
                                                    differencedebetbal,differenceassetbal,differencefrozenbal,
                                                    monitordesc,chkresult,bizDate,chkdate)
                                         values (v_l_id,v_vc_MonitorType,v_vc_Monitorsubtype,v_cur_monitor.accountid,2,v_l_bizCategoryId,v_l_relatedstockinfoid,v_cur_monitor.stockinfoid,
                                                    v_cur_monitor.assetbal,v_cur_monitor.assetfrozenbal,v_cur_monitor.debetbal,v_cur_monitor.curassetbal,v_cur_monitor.curfrozenbal,v_cur_monitor.curdebetbal,
                                                    v_differencedebetbal,v_differenceassetbal,v_differencefrozenbal,
                                                    v_monitorDesc,monitor_result,v_cur_monitor.chkdate,v_cur_monitor.chkdate);
                   end if;
                end loop;
               close cur_monitor;
     end loop;
     close cur_stockinfo;
     commit;

     return_code :=1;
     exception when others then
        --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := '[PKG_MONITOR.sp_chkSpotAcctAsset]报异常错误:'||chr(13)||sqlerrm;
           sp_monitorRunLogs(v_vc_MonitorType,return_str);
           rollback;
        end if;
        --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
           end if;
        --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
  end sp_chkSpotAcctAsset;


  procedure sp_chkCurOneByOne(acctId in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
  is
    v_vc_ycbz                         varchar2(1);                  --异常标志
    v_l_count                         number(8);
    v_l_account                       number(20);
  begin
    v_l_account := to_number(acctId);
    monitor_result :=1;
    return_code :=1;

    v_vc_ycbz := 'N';
    return_str := '[PKG_MONITOR.sp_chkCurOneByOne] 逐笔流水对账异常！';
    select count(1) into v_l_count
      from (select forzenorgamt,lag(forzenlastamt) over(partition by accountassettype,stockinfoid order by currentdate) last_forzenorgamt,
                     orgamt,lag(lastamt) over(partition by accountassettype,stockinfoid order by currentdate) last_amt
             from (select a.accountassettype,a.currentdate,a.orgamt,a.lastamt,a.forzenorgamt,a.forzenlastamt,a.stockinfoid
                     from accountfundcurrent a
                    where accountid=v_l_account
                    union all
                   select a.accountassettype,a.currentdate,a.orgamt,a.lastamt,a.forzenorgamt,a.forzenlastamt,a.stockinfoid
                     from accountfundcurrenthis a
                    where accountid=v_l_account
                    union all
                   select b.accountassettype,b.currentdate,b.orgamt,b.lastamt,b.forzenorgamt,b.forzenlastamt,b.stockinfoid
                     from accountfundcurrentspot b
                    where accountid=v_l_account
                    union all
                   select b.accountassettype,b.currentdate,b.orgamt,b.lastamt,b.forzenorgamt,b.forzenlastamt,b.stockinfoid
                     from accountfundcurrentspothis b
                    where accountid=v_l_account
                    union all
                   select c.accountassettype,c.currentdate businessdate,c.orgamt,c.lastamt,c.forzenorgamt,c.forzenlastamt,c.stockinfoid
                     from accountwealthcurrent c
                    where accountid=v_l_account
                    union all
                   select c.accountassettype,c.currentdate businessdate,c.orgamt,c.lastamt,c.forzenorgamt,c.forzenlastamt,c.stockinfoid
                     from accountwealthcurrenthis c
                    where accountid=v_l_account))
     where forzenorgamt != last_forzenorgamt or orgamt != last_amt;

     if v_l_count > 0 then
        v_vc_ycbz := 'H';
        monitor_result :=-1;
        return_str := '逐笔流水对账，发现账务异常！';
        raise_application_error(v_vc_ycbz, return_str);
     end if;

     return_code :=1;
     return_str := '逐笔流水对账';
     exception when others then
      --系统自动异常捕捉
      if v_vc_ycbz = 'N' then
        return_code:=-1;
        return_str := '[PKG_MONITOR.sp_chkCurOneByOne]报异常错误:'||chr(13)||sqlerrm;
        sp_monitorRunLogs('chkCurOneByOne',return_str);
        rollback;
      end if;
      --人为考虑系统异常
      if v_vc_ycbz = 'Y' then
        return_str := return_str;
      end if;
      --人为的制造了异常
      if v_vc_ycbz = 'H' then
        return_str := return_str;
      end if;


  end sp_chkCurOneByOne;


  procedure sp_chkDigitalCoinRecharge(acctId in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
  is
    v_vc_ycbz                         varchar2(1);                  --异常标志
    v_l_count                         number(8);
    v_l_account                       number(20);
  begin
    v_l_account := to_number(acctId);
    monitor_result :=1;
    return_code :=1;

     v_vc_ycbz := 'N';
     -- 逐笔核对提现流水
     select count(1) into v_l_count
      from
              (select nvl(a.currentdate,b.currentdate)currentdate,nvl(a.stockinfoid,b.stockinfoid)stockinfoid,nvl(a.occuramt,0) occuramt,nvl(b.amount,0) amount
                from (select currentdate,stockinfoid,transid,occuramt
            from accountfundcurrent  a1
           where businessflag = 'walletRecharge'
             and accountid = v_l_account
       and exists(select 1 from stockinfo where  stocktype='digitalCoin' and canrecharge ='yes' and canwithdraw='yes' and id = a1.stockinfoid)  -- 数字货币
                         union all
                         select currentdate,stockinfoid,transid,occuramt
               from accountfundcurrenthis a2
              where businessflag = 'walletRecharge'
          and accountid = v_l_account
          and exists(select 1 from stockinfo where stocktype='digitalCoin' and canrecharge ='yes' and canwithdraw='yes' and id = a2.stockinfoid)  -- 数字货币
                            )a
                full join
                       (select c.createdate currentdate,d.stockinfoid,d.accountid,c.amount,c.transid
                          from blocktransconfirm c, systemwalletaddr d
                         where c.walletid = d.walletid
                           and c.walletaddr = d.walletaddr
                           and c.direct = 'collect'
                           and c.confirmside = 'bitgo'
                           and c.status = 'confirm'
                           and d.accountid = v_l_account)   b
                  on a.transid = b.transid)
     where occuramt <>  amount;

     if  v_l_count > 0 then
   v_vc_ycbz := 'H';
         monitor_result :=-1;
         return_str := '数字货币逐笔充值流水核对，发现有比对不上的异常充值流水！';
         raise_application_error(v_vc_ycbz, return_str);
     end if;

     -- 核对提现总额
     v_vc_ycbz := 'N';
     select count(1)  into v_l_count
     from   (select stockinfoid,sum(occuramt) occuramt,sum(received) received,sum(unconfirmedreceived) unconfirmedreceived
             from (select nvl(a.stockinfoid,b.stockinfoid) stockinfoid,nvl(occuramt,0) occuramt,nvl(received,0) received,nvl(unconfirmedreceived,0) unconfirmedreceived
                     from (select stockinfoid,sum(occuramt)occuramt
                             from (select stockinfoid,occuramt
                                       from accountfundcurrent  a1
                                     where businessflag = 'walletRecharge'
                                        and accountid = v_l_account
                                        and exists(select 1 from stockinfo where  stocktype='digitalCoin' and canrecharge ='yes' and canwithdraw='yes' and id = a1.stockinfoid)  -- 数字货币
                                    union all
                                   select stockinfoid,occuramt
                                    from accountfundcurrenthis   a2
                                  where businessflag = 'walletRecharge'
                                     and accountid = v_l_account
                                     and exists(select 1 from stockinfo where stocktype='digitalCoin' and canrecharge ='yes' and canwithdraw='yes' and id = a2.stockinfoid)  --  数字货币
                                     )
                            group by stockinfoid)a
                       full join
                            (select stockinfoid,sum(received) received,sum(unconfirmedreceived) unconfirmedreceived from  systemwalletaddr where accountid = v_l_account group by stockinfoid) b
                       on a.stockinfoid = b.stockinfoid)
             group by stockinfoid)
     where occuramt <> (received-unconfirmedreceived);

     if v_l_count > 0 then
  v_vc_ycbz := 'H';
        monitor_result :=-1;
        return_str := '【账户:'||v_l_account||'】数字货币充值总额核对不上，实际到账与区块确认存在时间差，可能BTC区块已确认，而内部充值资金仍未到账，请核查！';
        raise_application_error(v_vc_ycbz, return_str);
     end if;

     return_code :=1;
     return_str := '数字货币充值流水核对成功';
     exception when others then
     --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := '[PKG_MONITOR.sp_chkDigitalCoinRecharge]报异常错误:'||chr(13)||sqlerrm;
           sp_monitorRunLogs('sp_chkDigitalCoinRecharge',return_str);
            rollback;
        end if;
      --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
      --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
  end sp_chkDigitalCoinRecharge;

    -- 现金货币充值校验
  procedure sp_chkCashCoinRecharge(acctId in varchar2,return_code out int,monitor_result out int,return_str out varchar2)
  is
    v_vc_ycbz                        varchar2(1);                  --异常标志
    v_l_count                        number(8);
    v_l_account                      number(20);
    v_differencebal                  number(24, 12);
  begin
     v_l_account := to_number(acctId);
     monitor_result :=1;
     return_code :=1;

     -- 逐笔现金货币充值流水核对,通过transid核对账户级系统内部资金充值流水和外部充值流水
     v_vc_ycbz := 'N';
     return_str := '[PKG_MONITOR.sp_chkCashCoinRecharge]逐笔现金货币充值流水核对异常';
     select count(1)
       into v_l_count
       from (select nvl(a.currentdate, b.currentdate) currentdate,
        nvl(a.stockinfoid, b.stockinfoid) stockinfoid,
        nvl(a.occuramt, 0) occuramt,
        nvl(b.amount, 0) amount
               from (select currentdate,
          stockinfoid,
          transid,
          (occuramt) occuramt
                 from accountfundcurrent a1
          where businessflag = 'walletRecharge'
      and accountid = v_l_account
      and exists (select 1 from stockinfo where stocktype = 'cashCoin' and canrecharge ='yes' and canwithdraw='yes' and id = a1.stockinfoid) -- 现金货币
                      union all
                     select currentdate, stockinfoid, transid, occuramt
                       from accountfundcurrenthis a2
                      where businessflag = 'walletRecharge'
                        and accountid = v_l_account
                        and exists (select 1 from stockinfo where stocktype = 'cashCoin' and canrecharge ='yes' and canwithdraw='yes' and id = a2.stockinfoid) -- 现金货币
                     ) a
              full join (select createdate currentdate,
        stockinfoid,
        amount,
        transId
                           from BankRecharge
                           where accountid = v_l_account
                           and status = 'checkThrough') b
               on a.transid = b.transid)
      where occuramt <> amount;

      if v_l_count > 0 then
       v_vc_ycbz := 'H';
         monitor_result :=-1;
         return_str := '现金货币逐笔核对异常！';
         raise_application_error(v_vc_ycbz, return_str);
      end if;

     -- 由于没有外部对接接口，所以欧元的内外部总额核对基于平台级现金总额的核对
     v_vc_ycbz := 'N';
     return_str := '[PKG_MONITOR.sp_chkCashCoinRecharge]现金货币内外部总额核对异常';
     For cur_total in (select nvl(a.lastamt,0)outEurTotal,nvl(b.curBal,0)inEurTotal
                         from (select a1.lastamt,a1.stockinfoId
                                   from WalletCashTransferCurrent a1
                                  where exists (select 1 from (select max(id) id from WalletCashTransferCurrent a2
                                                                where exists (select id from stockinfo where stocktype = 'cashCoin' and canrecharge = 'yes' and canwithdraw = 'yes' and a2.stockinfoid = id)
                                                                group by stockinfoid)
                                                      where a1.id = id ))a
                          full join
                              (select stockinfoid,nvl(sum(amount),0)+nvl(sum(withdrawingtotal),0) curBal
                                from accountwalletasset a3
                              where exists (select 1 from stockinfo where stocktype = 'cashCoin' and canrecharge = 'yes' and canwithdraw = 'yes' and id = a3.stockinfoid)
                              group by stockinfoid)b
                         on a.stockinfoid = b.stockinfoid)
     Loop
     v_differencebal := abs(cur_total.outeurtotal-cur_total.ineurtotal);
       if v_differencebal > 0 then
       v_vc_ycbz := 'H';
       monitor_result :=-1;
       return_str := '欧元内外部总额不一致，差额：'||to_char(v_differencebal,'fm999999999990.099999999999')||',外部总额：'||to_char(cur_total.outeurtotal,'fm999999999990.099999999999')||',内部总额：'||to_char(cur_total.ineurtotal,'fm999999999990.099999999999');
       raise_application_error(v_vc_ycbz, return_str);
     end if;
     End Loop;

     return_code :=1;
     return_str := '现金货币充值流水核对成功';
     exception when others then
     --系统自动异常捕捉
        if v_vc_ycbz = 'N' then
           return_code:=-1;
           return_str := return_str||chr(13)||sqlerrm;
       sp_monitorRunLogs('sp_chkCashCoinRecharge',return_str);
       rollback;
        end if;
      --人为考虑系统异常
        if v_vc_ycbz = 'Y' then
           return_str := return_str;
        end if;
      --人为的制造了异常
        if v_vc_ycbz = 'H' then
           return_str := return_str;
        end if;
  end sp_chkCashCoinRecharge;

  procedure sp_monitorRunLogs(monitorCode in varchar2,return_str in varchar2)
  is
  begin
    insert into MonitorRunLogs(monitorCode,Logdesc) values(monitorCode,return_str);
    /*update  monitorconfig a
          set  a.active =0
     where a.monitorcode=monitorCode;*/
     commit;
     exception when others then
        rollback;
  end sp_monitorRunLogs;

end PKG_MONITOR;
/

