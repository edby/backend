CREATE function sf_formattime(in_number NUMBER) 
return VARCHAR2 is
begin
 
  return (to_char(to_date( '19700101080000', 'YYYYMMDDHH24MISS ') 
  	+ in_number/(24 * 3600 * 1000),'yyyy-MM-dd HH24:mi:ss'));
	
end sf_formattime;
/

