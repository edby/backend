CREATE package PKG_MONITOR as
 /*===========================================================
    名  称：监控模块
    功  能：监控平台资金、交易数据的准确性
    创建者：jiangsc
    描  述：
    日  期：2017-08-24
  ============================================================*/
  type resultcur IS REF CURSOR;

  -- 保证金监控
  procedure sp_monitorMargin(bizids in varchar2,
                             monitor_idx out int,
                             return_code out int,
                             monitor_result out int,
                             monitor_data out resultcur,
                             return_str out varchar2);

  -- 杠杆现货资金总账监控
  procedure sp_monitorInternalPlatFundCur(bizids in varchar2,
                                          monitor_idx out int,
                                          return_code out int,
                                          monitor_result out int,
                                          monitor_data out resultcur,
                                          return_str out varchar2);

  -- 钱包资产总账监控
  procedure sp_monitorWalletAsset(return_code out int,
                                  monitor_result out int,
                                  return_str out varchar2);

  --杠杆现货总账监控
  procedure sp_monitorSpotAsset(bizids in varchar2,
                                return_code out int,
                                monitor_result out int,
                                return_str out varchar2);


  --杠杆现货账户资产监控
  procedure sp_monitorSpotAcctAsset(bizids in varchar2,
                                    return_code out int,
                                    monitor_result out int,
                                    return_str out varchar2);



  --账户级别资金流水监控
  procedure sp_monitorAccountFundCur(bizids in varchar2,
                                     monitor_idx out int,
                                     return_code out int,
                                     monitor_result out int,
                                     monitor_data out resultcur,
                                     return_str out varchar2);

  -- 钱包账户资产监控
  procedure sp_monitorWalletAcctAsset(return_code out int,
                                      monitor_result out int,
                                      return_str out varchar2);



  -- 理财资产账户监控
  procedure sp_monitorSpotWealthAcctAsset(return_code out int,
                                          monitor_result out int,
                                          return_str out varchar2);



  -- 逐笔资金流水监控
  procedure sp_monitorCurOneByOne(return_code out int,
                                  monitor_result out int,
                                  return_str out varchar2);


   --数字资产内外部总额监控
  procedure sp_monitorDigitalCoinBal(digitalCoin in varchar2,
								   externalRBal in varchar2,
								   externalWBal in varchar2,
								   monitor_idx out int,
								   return_code out int,
								   monitor_result out int,
								   monitor_data out resultcur,
								   return_str out varchar2);

  --现金资产内外部总额监控
  procedure sp_monitorCashCoinBal(cashCoins in varchar2,
								  monitor_idx out int,
								  return_code out int,
								  monitor_result out int,
								  monitor_data out resultcur,
								  return_str out varchar2);

  
  -- ERC20内外部总额监控
  procedure sp_monitorErc20Bal(digitalCoin in varchar2,
                               externalHBal in varchar2,
                               externalCBal in varchar2, 
                               monitor_idx out int,
                               return_code out int,
                               monitor_result out int,
                               monitor_data out resultcur,
                               return_str out varchar2);
  
  --区块高度内外部的监控 
  procedure sp_monitorBlockNum(inBlockNum in varchar2,
                               outBlockNum in varchar2,
                               blockResource in varchar2,
                               monitor_idx out int,
                               return_code out int,
                               monitor_result out int,
                               monitor_data out resultcur,
                               return_str out varchar2);
                                                     
  -- 钱包账户资产检查
  procedure sp_chkWalletAcctAsset(acctId in varchar2,
                                  stockinfoid in varchar2,
                                  action in varchar2,
                                  return_code out int,
                                  monitor_result out int,
                                  return_str out varchar2);

  --单账户资金流水核对
  procedure sp_chkAccountFundCur(acctId in varchar2,
                                 stockinfoid in varchar2,
                                 return_code out int,
                                 monitor_result out int,
                                 monitor_data out resultcur,
                                 return_str out varchar2);

  --账户提现时，检查账户资产
  procedure sp_chkAcctAsset(acctId in varchar2,
                            return_code out int,
                            chek_result out int,
                            return_str out varchar2);

  -- 杠杆现货账户资产检查
  procedure sp_chkSpotAcctAsset(acctId in varchar2,
                                stockinfoid in varchar2,
                                action in varchar2,
                                return_code out int,
                                monitor_result out int,
                                return_str out varchar2);

  -- 理财资产账户资产检查
  procedure sp_chkSpotWealthAcctAsset(acctId in varchar2,
                                      stockinfoid in varchar2,
                                      action in varchar2,
                                      return_code out int,
                                      monitor_result out int,
                                      return_str out varchar2);

  -- 逐笔资金流水校验
  procedure sp_chkCurOneByOne(acctId in varchar2,
                              return_code out int,
							  monitor_result out int,
							  return_str out varchar2);

  -- 数字货币充值流水校验
  procedure sp_chkDigitalCoinRecharge(acctId in varchar2,
                                      return_code out int,
                                      monitor_result out int,
                                      return_str out varchar2);
  -- 现金货币充值校验
  procedure sp_chkCashCoinRecharge(acctId in varchar2,
								   return_code out int,
								   monitor_result out int,
								   return_str out varchar2);
  -- 监控运行日志
  procedure sp_monitorRunLogs(monitorCode in varchar2,
                              return_str in varchar2);

end   PKG_MONITOR;
/

